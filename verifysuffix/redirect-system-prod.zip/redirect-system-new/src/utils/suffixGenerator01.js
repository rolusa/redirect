/**
 * ============================================
 * URL后缀生成器 (Suffix Generator)
 * ============================================
 * 功能：
 * 1. 管理URL后缀列表（共92个后缀）
 * 2. 随机选择后缀，日本域名后缀权重更高
 * 3. 用于生成伪装链接，增强反检测能力
 * 
 * 使用示例：
 *   const { getRandomSuffix } = require('./suffixGenerator');
 *   const suffix = getRandomSuffix();
 *   const url = `https://domain.com/${token}${suffix}`;
 * ============================================
 */

/**
 * 后缀列表配置
 */
const SUFFIX_LIST = {
  /**
   * 网页文件后缀 (15个)
   * 伪装成各种Web页面文件
   */
  webFiles: [
    '.html',    // HTML页面
    '.htm',     // HTML页面（短格式）
    '.php',     // PHP页面
    '.asp',     // ASP页面
    '.aspx',    // ASP.NET页面
    '.jsp',     // Java Server Pages
    '.do',      // Java Struts
    '.action',  // Java Struts2
    '.cgi',     // CGI脚本
    '.pl',      // Perl脚本
    '.cfm',     // ColdFusion
    '.shtml',   // SSI页面
    '.xhtml',   // XHTML页面
    '.jspx',    // JSP XML
    '.jspa'     // Atlassian风格
  ],

  /**
   * 常用顶级域名后缀 (20个)
   * 伪装成域名风格
   */
  topDomains: [
    '.com',     // 商业
    '.net',     // 网络
    '.org',     // 组织
    '.info',    // 信息
    '.biz',     // 商务
    '.io',      // 科技公司常用
    '.co',      // 公司
    '.me',      // 个人
    '.cc',      // 科科斯群岛
    '.tv',      // 图瓦卢
    '.fm',      // 密克罗尼西亚
    '.am',      // 亚美尼亚
    '.cloud',   // 云服务
    '.app',     // 应用
    '.dev',     // 开发者
    '.tech',    // 科技
    '.site',    // 网站
    '.online',  // 在线
    '.link',    // 链接
    '.click'    // 点击
  ],

  /**
   * 日本域名后缀 (10个) - 权重更高
   * 针对日本市场的专用后缀
   */
  japanDomains: [
    '.jp',      // 日本国家域名
    '.co.jp',   // 日本公司
    '.or.jp',   // 日本组织
    '.ne.jp',   // 日本网络服务
    '.ac.jp',   // 日本学术机构
    '.go.jp',   // 日本政府
    '.gr.jp',   // 日本团体
    '.ed.jp',   // 日本教育
    '.ad.jp',   // 日本网络管理
    '.lg.jp'    // 日本地方政府
  ],

  /**
   * 日本地区域名后缀 (47个)
   * 日本47个都道府县的地区域名
   */
  japanRegions: [
    '.tokyo.jp',      // 东京都
    '.osaka.jp',      // 大阪府
    '.kyoto.jp',      // 京都府
    '.hokkaido.jp',   // 北海道
    '.fukuoka.jp',    // 福冈县
    '.aichi.jp',      // 爱知县
    '.kanagawa.jp',   // 神奈川县
    '.saitama.jp',    // 埼玉县
    '.chiba.jp',      // 千叶县
    '.hyogo.jp',      // �的库县
    '.hiroshima.jp',  // 广岛县
    '.miyagi.jp',     // 宫城县
    '.shizuoka.jp',   // 静冈县
    '.niigata.jp',    // 新潟县
    '.nagano.jp',     // 长野县
    '.okinawa.jp',    // 冲绳县
    '.nara.jp',       // 奈良县
    '.nagasaki.jp',   // 长崎县
    '.kumamoto.jp',   // 熊本县
    '.okayama.jp',    // 冈山县
    '.kagoshima.jp',  // 鹿儿岛县
    '.mie.jp',        // 三重县
    '.gifu.jp',       // 岐阜县
    '.gunma.jp',      // 群马县
    '.tochigi.jp',    // 栃木县
    '.ibaraki.jp',    // 茨城县
    '.fukushima.jp',  // 福岛县
    '.yamaguchi.jp',  // 山口县
    '.ishikawa.jp',   // 石川县
    '.toyama.jp',     // 富山县
    '.wakayama.jp',   // 和歌山县
    '.ehime.jp',      // 爱媛县
    '.kagawa.jp',     // 香川县
    '.tokushima.jp',  // 德岛县
    '.kochi.jp',      // 高知县
    '.saga.jp',       // 佐贺县
    '.oita.jp',       // 大分县
    '.miyazaki.jp',   // 宫崎县
    '.yamanashi.jp',  // 山梨县
    '.fukui.jp',      // 福井县
    '.yamagata.jp',   // 山形县
    '.akita.jp',      // 秋田县
    '.iwate.jp',      // 岩手县
    '.aomori.jp',     // 青森县
    '.shiga.jp',      // 滋贺县
    '.tottori.jp',    // �的取县
    '.shimane.jp'     // 岛根县
  ]
};

/**
 * 获取随机后缀
 * 
 * 权重分配：
 * - 日本域名后缀（10个）: 40% 概率
 * - 其他三类（82个）: 60% 概率，平均分配
 * 
 * @returns {string} 随机后缀，如 ".jp"、".html"、".tokyo.jp"
 */
function getRandomSuffix() {
  const random = Math.random();
  
  // 40% 概率选择日本域名后缀（权重更高）
  if (random < 0.4) {
    const list = SUFFIX_LIST.japanDomains;
    const index = Math.floor(Math.random() * list.length);
    return list[index];
  }
  
  // 60% 概率从其他三类中平均随机选择
  const otherLists = [
    ...SUFFIX_LIST.webFiles,      // 15个
    ...SUFFIX_LIST.topDomains,    // 20个
    ...SUFFIX_LIST.japanRegions   // 47个
  ];
  // 总共 82 个
  const index = Math.floor(Math.random() * otherLists.length);
  return otherLists[index];
}

/**
 * 获取所有后缀列表
 * @returns {string[]} 所有后缀的数组
 */
function getAllSuffixes() {
  return [
    ...SUFFIX_LIST.webFiles,
    ...SUFFIX_LIST.topDomains,
    ...SUFFIX_LIST.japanDomains,
    ...SUFFIX_LIST.japanRegions
  ];
}

/**
 * 获取后缀总数
 * @returns {number} 后缀总数
 */
function getSuffixCount() {
  return SUFFIX_LIST.webFiles.length +
         SUFFIX_LIST.topDomains.length +
         SUFFIX_LIST.japanDomains.length +
         SUFFIX_LIST.japanRegions.length;
}

/**
 * 获取后缀统计信息
 * @returns {Object} 各类后缀的数量统计
 */
function getSuffixStats() {
  return {
    webFiles: SUFFIX_LIST.webFiles.length,
    topDomains: SUFFIX_LIST.topDomains.length,
    japanDomains: SUFFIX_LIST.japanDomains.length,
    japanRegions: SUFFIX_LIST.japanRegions.length,
    total: getSuffixCount()
  };
}

module.exports = {
  SUFFIX_LIST,
  getRandomSuffix,
  getAllSuffixes,
  getSuffixCount,
  getSuffixStats
};
