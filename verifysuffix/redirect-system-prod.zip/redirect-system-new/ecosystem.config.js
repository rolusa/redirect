/**
 * ============================================
 * PM2 配置文件
 * ============================================
 * 用于生产环境的进程管理
 * 
 * 使用方法：
 * pm2 start ecosystem.config.js --env production   # 启动所有应用
 * pm2 restart all                                   # 重启所有应用
 * pm2 stop all                                      # 停止所有应用
 * pm2 logs                                          # 查看所有日志
 * pm2 logs redirect-system                          # 查看主服务日志
 * pm2 logs redirect-admin                           # 查看管理后台日志
 * ============================================
 */

module.exports = {
  apps: [
    // ============================================
    // 应用1：主重定向系统（端口3000）
    // ============================================
    {
      // 应用名称
      name: 'redirect-system',

      // 入口文件
      script: './src/index.js',

      // 实例数量（'max'表示使用所有CPU核心）
      instances: 'max',

      // 执行模式（cluster模式支持负载均衡）
      exec_mode: 'cluster',

      // 是否监听文件变化（生产环境建议关闭）
      watch: false,

      // 监听的文件/目录（如果watch为true）
      watch_options: {
        followSymlinks: false,
        usePolling: false,
      },

      // 内存超限自动重启
      max_memory_restart: '600M',

      // 环境变量（生产环境）
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },

      // 环境变量（开发环境）
      env_development: {
        NODE_ENV: 'development',
        PORT: 3000,
      },

      // 日志配置
      error_file: './logs/pm2-error.log',
      out_file: './logs/pm2-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,

      // 自动重启配置
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',

      // 启动延迟
      listen_timeout: 3000,
      kill_timeout: 5000,

      // 优雅重载
      wait_ready: false,

      // Cron重启（可选，每天凌晨4点重启）
      // cron_restart: '0 4 * * *',

      // 错误日志限制
      error_file_max_size: '10M',
      error_file_count: 10,

      // 输出日志限制
      out_file_max_size: '10M',
      out_file_count: 10,

      // 忽略的监听文件/目录
      ignore_watch: [
        'node_modules',
        'logs',
        '.git',
        '*.log',
      ],

      // 实例间的负载均衡
      instance_var: 'INSTANCE_ID',

      // 增量ID（用于识别不同实例）
      increment_var: 'PORT',
    },

    // ============================================
    // 应用2：管理后台服务（端口3001）
    // ============================================
    {
      // 应用名称
      name: 'redirect-admin',

      // 入口文件（管理后台服务器）
      script: './src/admin/server.js',

      // 实例数量（管理后台只需要1个实例）
      instances: 1,

      // 执行模式（fork模式，单实例运行）
      exec_mode: 'fork',

      // 是否监听文件变化（生产环境建议关闭）
      watch: false,

      // 监听的文件/目录（如果watch为true）
      watch_options: {
        followSymlinks: false,
        usePolling: false,
      },

      // 内存超限自动重启（管理后台内存需求较小）
      max_memory_restart: '300M',

      // 环境变量（生产环境）
      env_production: {
        NODE_ENV: 'production',
        ADMIN_PORT: 3001,
      },

      // 环境变量（开发环境）
      env_development: {
        NODE_ENV: 'development',
        ADMIN_PORT: 3001,
      },

      // 日志配置（与主服务分开存储）
      error_file: './logs/admin-error.log',
      out_file: './logs/admin-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,

      // 自动重启配置
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',

      // 启动延迟
      listen_timeout: 3000,
      kill_timeout: 5000,

      // 优雅重载
      wait_ready: false,

      // Cron重启（可选，每天凌晨4点重启）
      // cron_restart: '0 4 * * *',

      // 错误日志限制
      error_file_max_size: '10M',
      error_file_count: 10,

      // 输出日志限制
      out_file_max_size: '10M',
      out_file_count: 10,

      // 忽略的监听文件/目录
      ignore_watch: [
        'node_modules',
        'logs',
        '.git',
        '*.log',
      ],
    },
  ],
};
