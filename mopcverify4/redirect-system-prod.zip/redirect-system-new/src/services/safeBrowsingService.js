/**
 * ============================================
 * Google Safe Browsing URL安全监控服务 v2
 * ============================================
 * 修复清单：
 * 1. LAST_CHECK_TIME 在检查开始时立即更新
 * 2. 存储 LAST_CHECK_RESULT / LAST_CHECK_ERROR
 * 3. API Key 失败后自动轮换重试
 * 4. getStatus 返回诊断信息供前端显示
 * 5. 连续失败上限改为5次 + 醒目告警标记
 * 6. API超时改为20秒
 * 7. 每次检查后存储URL安全状态快照
 * ============================================
 */

const axios = require('axios');
const Database = require('../database/mysql');
const logger = require('../utils/logger');

const CATEGORY = 'safety_monitor';
const API_URL = 'https://safebrowsing.googleapis.com/v4/threatMatches:find';

class SafeBrowsingService {
  static timer = null;
  static isChecking = false;
  static consecutiveFailures = 0;
  static MAX_CONSECUTIVE_FAILURES = 5; // ← 问题5：改为5次

  // ============================================
  // 配置读写
  // ============================================

  static async getConfig(key, defaultValue = '') {
    try {
      const row = await Database.queryOne(
        'SELECT value FROM config_items WHERE category = ? AND key_name = ? AND is_active = 1',
        [CATEGORY, key]
      );
      return row ? row.value : defaultValue;
    } catch (e) {
      logger.error('SafeBrowsing: 读取配置失败', { key, error: e.message });
      return defaultValue;
    }
  }

  static async setConfig(key, value, description = '', dataType = 'string') {
    try {
      const existing = await Database.queryOne(
        'SELECT id FROM config_items WHERE category = ? AND key_name = ?',
        [CATEGORY, key]
      );
      if (existing) {
        await Database.update('config_items',
          { value: String(value), updated_by: 'system', updated_at: new Date() },
          { id: existing.id }
        );
      } else {
        await Database.insert('config_items', {
          category: CATEGORY,
          key_name: key,
          value: String(value),
          data_type: dataType,
          description: description,
          is_sensitive: false,
          is_active: true,
          updated_by: 'system'
        });
      }
    } catch (e) {
      logger.error('SafeBrowsing: 写入配置失败', { key, error: e.message });
    }
  }

  static async getAllConfig() {
    const enabled = await this.getConfig('ENABLED', 'false');
    const checkInterval = parseInt(await this.getConfig('CHECK_INTERVAL_MINUTES', '5')) || 5;
    const activeUrlCount = parseInt(await this.getConfig('ACTIVE_URL_COUNT', '1')) || 1;
    const maxUrlAgeHours = parseInt(await this.getConfig('MAX_URL_AGE_HOURS', '0')) || 0;
    const poolUrls = (await this.getConfig('POOL_URLS', '')).split('\n').map(u => u.trim()).filter(u => u.startsWith('http'));
    const apiKeys = (await this.getConfig('API_KEYS', '')).split('\n').map(k => k.trim()).filter(k => k.length > 0);
    const lastCheckTime = await this.getConfig('LAST_CHECK_TIME', '');
    const lastCheckResult = await this.getConfig('LAST_CHECK_RESULT', '');
    const lastCheckError = await this.getConfig('LAST_CHECK_ERROR', '');
    const urlActivatedAt = this._parseJSON(await this.getConfig('URL_ACTIVATED_AT', '{}'), {});
    const retiredUrls = this._parseJSON(await this.getConfig('RETIRED_URLS', '[]'), []);
    const urlSafetySnapshot = this._parseJSON(await this.getConfig('URL_SAFETY_SNAPSHOT', '{}'), {});

    // 从domains.TARGET_URL读取当前生效的URL（B输入框）
    let activeUrls = [];
    try {
      const targetConfig = await Database.queryOne(
        'SELECT value FROM config_items WHERE key_name = ? AND category = ?',
        ['TARGET_URL', 'domains']
      );
      if (targetConfig && targetConfig.value) {
        activeUrls = targetConfig.value.split('\n').map(u => u.trim()).filter(u => u.startsWith('http'));
      }
    } catch (e) {
      logger.error('SafeBrowsing: 读取TARGET_URL失败', { error: e.message });
    }

    return {
      enabled: enabled === 'true',
      checkInterval,
      activeUrlCount,
      maxUrlAgeHours,
      poolUrls,
      activeUrls,
      apiKeys,
      lastCheckTime,
      lastCheckResult,
      lastCheckError,
      urlActivatedAt,
      retiredUrls,
      urlSafetySnapshot
    };
  }

  // ============================================
  // 定时器管理
  // ============================================

  static async init() {
    try {
      const config = await this.getAllConfig();
      if (config.enabled && config.apiKeys.length > 0) {
        this.startTimer(config.checkInterval);
        logger.info('SafeBrowsing: 安全监控已自动启动', { interval: config.checkInterval });
      } else {
        logger.info('SafeBrowsing: 安全监控未启用或缺少API Key');
      }
    } catch (e) {
      logger.error('SafeBrowsing: 初始化失败', { error: e.message });
    }
  }

  static startTimer(intervalMinutes) {
    this.stopTimer();
    const ms = Math.max(1, intervalMinutes) * 60 * 1000;
    this.timer = setInterval(() => this.checkNow(), ms);
    logger.info('SafeBrowsing: 定时器已启动', { intervalMinutes });
  }

  static stopTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      logger.info('SafeBrowsing: 定时器已停止');
    }
  }

  static async start() {
    const config = await this.getAllConfig();
    if (config.apiKeys.length === 0) {
      throw new Error('请先配置至少一个Google Safe Browsing API Key');
    }
    await this.setConfig('ENABLED', 'true');
    this.consecutiveFailures = 0;
    // 清除之前的错误状态
    await this.setConfig('LAST_CHECK_RESULT', '');
    await this.setConfig('LAST_CHECK_ERROR', '');
    this.startTimer(config.checkInterval);
    return { success: true, message: '监控已启动' };
  }

  static async stop() {
    this.stopTimer();
    await this.setConfig('ENABLED', 'false');
    return { success: true, message: '监控已停止' };
  }

  // ============================================
  // 核心检查逻辑
  // ============================================

  /**
   * 执行一次检查（主流程）
   * 修复1：进入后立即更新 LAST_CHECK_TIME
   * 修复2：存储检查结果和错误信息
   */
  static async checkNow() {
    if (this.isChecking) {
      logger.warn('SafeBrowsing: 上一次检查尚未完成，跳过本次');
      return { skipped: true, reason: '上一次检查尚未完成' };
    }

    this.isChecking = true;
    const startTime = Date.now();

    try {
      // ★ 修复1：立即更新检查时间（不管后续成功失败）
      await this.setConfig('LAST_CHECK_TIME', new Date().toISOString());

      const config = await this.getAllConfig();

      if (config.apiKeys.length === 0) {
        await this._saveCheckResult('error', '未配置API Key');
        return { success: false, error: '未配置API Key' };
      }

      if (config.activeUrls.length === 0) {
        await this._saveCheckResult('success', 'B输入框为空，无需检查');
        return { success: true, message: 'B输入框为空，无需检查' };
      }

      logger.info('SafeBrowsing: 开始安全检查', {
        activeUrls: config.activeUrls.length,
        poolUrls: config.poolUrls.length
      });

      // 1. 检查URL安全性（★ 修复3：带轮换重试）
      const unsafeResults = await this.checkURLsSafetyWithRetry(config.activeUrls, config.apiKeys);

      // 2. 检查URL年龄（自动轮换）
      let ageExpiredUrls = [];
      if (config.maxUrlAgeHours > 0) {
        ageExpiredUrls = this._getAgeExpiredUrls(config.activeUrls, config.urlActivatedAt, config.maxUrlAgeHours);
      }

      // 3. ★ 修复7：存储URL安全状态快照
      const snapshot = {};
      for (const url of config.activeUrls) {
        const unsafeItem = unsafeResults.find(r => r.url === url);
        snapshot[url] = unsafeItem
          ? { safe: false, threatType: unsafeItem.threatType, checkedAt: new Date().toISOString() }
          : { safe: true, threatType: null, checkedAt: new Date().toISOString() };
      }
      await this.setConfig('URL_SAFETY_SNAPSHOT', JSON.stringify(snapshot));

      // 4. 合并需要替换的URL列表（去重）
      const unsafeUrlSet = new Set(unsafeResults.map(r => r.url));
      const ageExpiredSet = new Set(ageExpiredUrls);
      const toReplaceUrls = [...new Set([...unsafeUrlSet, ...ageExpiredSet])];

      if (toReplaceUrls.length === 0) {
        this.consecutiveFailures = 0;
        const elapsed = Date.now() - startTime;
        // ★ 修复2：存储成功结果
        await this._saveCheckResult('success', '所有URL安全 (' + elapsed + 'ms)');
        logger.info('SafeBrowsing: 所有URL安全', { elapsed: elapsed + 'ms' });
        return {
          success: true,
          allSafe: true,
          checkedCount: config.activeUrls.length,
          elapsed
        };
      }

      // 5. 执行替换
      logger.warn('SafeBrowsing: 发现需要替换的URL', {
        unsafe: unsafeResults.length,
        ageExpired: ageExpiredUrls.length,
        totalReplace: toReplaceUrls.length
      });

      const replaceResult = await this.replaceURLs(
        toReplaceUrls,
        config.activeUrls,
        config.poolUrls,
        config.apiKeys,
        config.urlActivatedAt,
        config.retiredUrls,
        unsafeResults
      );

      this.consecutiveFailures = 0;
      const elapsed = Date.now() - startTime;

      // ★ 修复2：存储成功结果
      await this._saveCheckResult('success',
        '替换了' + replaceResult.replacedCount + '个URL (' + elapsed + 'ms)');

      return {
        success: true,
        allSafe: false,
        checkedCount: config.activeUrls.length,
        replacedCount: replaceResult.replacedCount,
        elapsed,
        details: replaceResult
      };

    } catch (error) {
      this.consecutiveFailures++;
      logger.error('SafeBrowsing: 检查失败', {
        error: error.message,
        consecutiveFailures: this.consecutiveFailures
      });

      // ★ 修复2：存储失败结果和错误信息
      await this._saveCheckResult('error', error.message);

      // ★ 修复5：连续失败5次后暂停
      if (this.consecutiveFailures >= this.MAX_CONSECUTIVE_FAILURES) {
        logger.error('SafeBrowsing: 连续失败已达' + this.MAX_CONSECUTIVE_FAILURES + '次，暂停监控');
        this.stopTimer();
        await this.setConfig('ENABLED', 'false');
      }

      return { success: false, error: error.message };
    } finally {
      this.isChecking = false;
    }
  }

  /**
   * ★ 修复2：保存检查结果
   */
  static async _saveCheckResult(result, message) {
    try {
      await this.setConfig('LAST_CHECK_RESULT', result);
      await this.setConfig('LAST_CHECK_ERROR', result === 'error' ? message : '');
      await this.setConfig('LAST_CHECK_MESSAGE', message || '');
    } catch (e) {
      logger.error('SafeBrowsing: 保存检查结果失败', { error: e.message });
    }
  }

  /**
   * ★ 修复3：带API Key轮换重试的URL安全检查
   * 一个Key失败后自动换下一个Key重试，全部失败才报错
   * @param {string[]} urls - URL列表
   * @param {string[]} apiKeys - 全部API Key列表
   * @returns {Array} 不安全URL列表
   */
  static async checkURLsSafetyWithRetry(urls, apiKeys) {
    if (!urls || urls.length === 0) return [];
    if (!apiKeys || apiKeys.length === 0) throw new Error('未配置API Key');

    // 随机打乱Key顺序，确保负载均衡
    const shuffledKeys = [...apiKeys].sort(() => Math.random() - 0.5);
    const errors = [];

    for (let i = 0; i < shuffledKeys.length; i++) {
      const apiKey = shuffledKeys[i];
      try {
        const result = await this._callSafeBrowsingAPI(urls, apiKey);
        // 成功，如果之前有失败的Key，记录日志
        if (errors.length > 0) {
          logger.info('SafeBrowsing: 第' + (i + 1) + '个Key成功（前' + errors.length + '个Key失败）');
        }
        return result;
      } catch (e) {
        errors.push({ keyIndex: i + 1, keyPrefix: apiKey.substring(0, 15), error: e.message });
        logger.warn('SafeBrowsing: 第' + (i + 1) + '个Key失败，' +
          (i < shuffledKeys.length - 1 ? '尝试下一个...' : '全部Key已用完'), {
          keyPrefix: apiKey.substring(0, 15) + '...',
          error: e.message
        });
      }
    }

    // 全部Key都失败了
    const summary = errors.map(e => 'Key' + e.keyIndex + '(' + e.keyPrefix + '...): ' + e.error).join('; ');
    throw new Error('所有API Key均失败: ' + summary);
  }

  /**
   * 调用Google Safe Browsing API（单次，不重试）
   * ★ 修复6：超时改为20秒
   */
  static async _callSafeBrowsingAPI(urls, apiKey) {
    try {
      const response = await axios.post(
        API_URL + '?key=' + apiKey,
        {
          client: {
            clientId: 'redirect-system-safety-monitor',
            clientVersion: '2.0.0'
          },
          threatInfo: {
            threatTypes: [
              'MALWARE',
              'SOCIAL_ENGINEERING',
              'UNWANTED_SOFTWARE',
              'POTENTIALLY_HARMFUL_APPLICATION'
            ],
            platformTypes: ['ANY_PLATFORM'],
            threatEntryTypes: ['URL'],
            threatEntries: urls.map(url => ({ url: url }))
          }
        },
        { timeout: 20000 } // ★ 修复6：20秒超时
      );

      const matches = response.data.matches || [];
      return matches.map(match => ({
        url: match.threat.url,
        threatType: match.threatType,
        platformType: match.platformType
      }));

    } catch (error) {
      if (error.response) {
        const status = error.response.status;
        const msg = error.response.data?.error?.message || '';

        if (status === 400 && msg.includes('API key not valid')) {
          throw new Error('API Key无效');
        }
        if (status === 429) {
          throw new Error('配额耗尽(429)');
        }
        if (status === 403) {
          throw new Error('访问被拒绝(403)');
        }
        throw new Error('HTTP ' + status + ': ' + (msg || 'Unknown'));
      }
      if (error.code === 'ECONNABORTED') {
        throw new Error('请求超时(20s)');
      }
      if (error.code === 'ENOTFOUND' || error.code === 'EAI_AGAIN') {
        throw new Error('DNS解析失败，检查网络连接');
      }
      throw new Error(error.message);
    }
  }

  /**
   * 替换不安全URL的完整流程
   */
  static async replaceURLs(toReplaceUrls, currentActiveUrls, currentPoolUrls, apiKeys, urlActivatedAt, retiredUrls, unsafeDetails) {
    let newActiveUrls = [...currentActiveUrls];
    let newPoolUrls = [...currentPoolUrls];
    let newActivatedAt = { ...urlActivatedAt };
    let newRetiredUrls = [...retiredUrls];
    let replacedCount = 0;
    const logEntries = [];

    for (const badUrl of toReplaceUrls) {
      const idx = newActiveUrls.indexOf(badUrl);
      if (idx === -1) continue;

      const unsafeDetail = unsafeDetails.find(d => d.url === badUrl);
      const reason = unsafeDetail
        ? '不安全(' + unsafeDetail.threatType + ')'
        : 'URL使用时长超限';

      // 从池中取一个安全URL（带预检）
      let replacementUrl = null;
      let preCheckAttempts = 0;
      const maxPreCheckAttempts = Math.min(newPoolUrls.length, 10); // 最多预检10个

      while (newPoolUrls.length > 0 && preCheckAttempts < maxPreCheckAttempts) {
        preCheckAttempts++;
        const candidate = newPoolUrls.shift();

        try {
          const checkResult = await this.checkURLsSafetyWithRetry([candidate], apiKeys);
          if (checkResult.length === 0) {
            replacementUrl = candidate;
            break;
          } else {
            logger.warn('SafeBrowsing: 备用URL预检不安全，丢弃', {
              url: candidate, threat: checkResult[0].threatType
            });
            newRetiredUrls.push({
              url: candidate,
              reason: '预检不安全(' + checkResult[0].threatType + ')',
              retiredAt: new Date().toISOString()
            });
          }
        } catch (e) {
          // 预检API调用失败，放回池尾
          logger.warn('SafeBrowsing: 备用URL预检失败，放回池尾', {
            url: candidate, error: e.message
          });
          newPoolUrls.push(candidate);
          break;
        }
      }

      if (replacementUrl) {
        newActiveUrls[idx] = replacementUrl;
        newActivatedAt[replacementUrl] = new Date().toISOString();
        delete newActivatedAt[badUrl];
        replacedCount++;

        newRetiredUrls.push({
          url: badUrl,
          reason: reason,
          replacedBy: replacementUrl,
          retiredAt: new Date().toISOString()
        });

        logEntries.push({ oldUrl: badUrl, newUrl: replacementUrl, reason: reason });

        logger.warn('SafeBrowsing: URL已替换', {
          old: badUrl.substring(0, 50),
          new: replacementUrl.substring(0, 50),
          reason
        });
      } else {
        logger.error('SafeBrowsing: 备用URL池已耗尽或预检全部失败，无法替换', { badUrl });
        logEntries.push({
          oldUrl: badUrl, newUrl: null,
          reason: reason + ' (无可用替换URL)'
        });
      }
    }

    // 保存所有更新
    if (replacedCount > 0) {
      const targetValue = newActiveUrls.join('\n');
      const targetConfig = await Database.queryOne(
        'SELECT id FROM config_items WHERE key_name = ? AND category = ?',
        ['TARGET_URL', 'domains']
      );
      if (targetConfig) {
        await Database.update('config_items',
          { value: targetValue, updated_by: 'safety_monitor', updated_at: new Date() },
          { id: targetConfig.id }
        );
      }
    }

    await this.setConfig('POOL_URLS', newPoolUrls.join('\n'));
    await this.setConfig('URL_ACTIVATED_AT', JSON.stringify(newActivatedAt));

    if (newRetiredUrls.length > 200) {
      newRetiredUrls = newRetiredUrls.slice(-200);
    }
    await this.setConfig('RETIRED_URLS', JSON.stringify(newRetiredUrls));

    for (const entry of logEntries) {
      try {
        await Database.insert('url_safety_logs', {
          action: 'replace',
          old_url: entry.oldUrl,
          new_url: entry.newUrl,
          reason: entry.reason,
          created_by: 'safety_monitor'
        });
      } catch (e) {
        logger.error('SafeBrowsing: 写入日志失败', { error: e.message });
      }
    }

    return { replacedCount, logEntries, remainingPool: newPoolUrls.length };
  }

  // ============================================
  // 获取监控状态（★ 修复4：增加诊断信息）
  // ============================================

  static async getStatus() {
    const config = await this.getAllConfig();

    let nextCheckTime = null;
    if (config.enabled && config.lastCheckTime) {
      const lastCheck = new Date(config.lastCheckTime);
      nextCheckTime = new Date(lastCheck.getTime() + config.checkInterval * 60 * 1000).toISOString();
    }

    // 统计今日数据
    let todayChecks = 0;
    let todayReplaces = 0;
    try {
      const replacesResult = await Database.queryOne(
        "SELECT COUNT(*) as cnt FROM url_safety_logs WHERE action = 'replace' AND DATE(created_at) = CURDATE()"
      );
      todayReplaces = replacesResult?.cnt || 0;
    } catch (e) { /* 表可能不存在 */ }

    // ★ 修复7：用快照数据构建URL状态
    const urlStatuses = config.activeUrls.map(url => {
      const snap = config.urlSafetySnapshot[url];
      return {
        url,
        safe: snap ? snap.safe : null,
        threatType: snap ? snap.threatType : null,
        checkedAt: snap ? snap.checkedAt : null,
        activatedAt: config.urlActivatedAt[url] || null
      };
    });

    return {
      enabled: config.enabled,
      timerRunning: this.timer !== null,
      isChecking: this.isChecking,
      checkInterval: config.checkInterval,
      activeUrlCount: config.activeUrlCount,
      maxUrlAgeHours: config.maxUrlAgeHours,
      lastCheckTime: config.lastCheckTime || null,
      nextCheckTime,
      // ★ 修复2+4：诊断信息
      lastCheckResult: config.lastCheckResult || null,
      lastCheckError: config.lastCheckError || null,
      lastCheckMessage: await this.getConfig('LAST_CHECK_MESSAGE', ''),
      consecutiveFailures: this.consecutiveFailures,
      maxConsecutiveFailures: this.MAX_CONSECUTIVE_FAILURES,
      // 池和URL
      poolUrlsCount: config.poolUrls.length,
      activeUrls: config.activeUrls,
      poolUrls: config.poolUrls,
      apiKeysCount: config.apiKeys.length,
      apiKeys: config.apiKeys,
      urlStatuses,
      todayReplaces,
      retiredUrls: config.retiredUrls.slice(-50),
      // 告警
      poolWarning: config.poolUrls.length <= 5 && config.poolUrls.length > 0
        ? '备用URL池仅剩' + config.poolUrls.length + '个'
        : null,
      poolEmpty: config.poolUrls.length === 0
    };
  }

  // ============================================
  // 工具方法
  // ============================================

  static _getRandomItem(arr) {
    if (!arr || arr.length === 0) return null;
    return arr[Math.floor(Math.random() * arr.length)];
  }

  static _parseJSON(str, defaultVal) {
    try { return JSON.parse(str); }
    catch { return defaultVal; }
  }

  static _getAgeExpiredUrls(activeUrls, activatedAt, maxHours) {
    const now = Date.now();
    const maxMs = maxHours * 60 * 60 * 1000;
    const expired = [];
    for (const url of activeUrls) {
      const activatedTime = activatedAt[url];
      if (activatedTime) {
        const elapsed = now - new Date(activatedTime).getTime();
        if (elapsed > maxMs) {
          expired.push(url);
        }
      }
    }
    return expired;
  }
}

module.exports = SafeBrowsingService;
