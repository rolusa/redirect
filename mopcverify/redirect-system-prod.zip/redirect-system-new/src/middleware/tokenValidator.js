/**
 * ============================================
 * Token验证中间件（短Token版本）
 * ============================================
 * 功能：
 * 1. 验证10位短Token的有效性
 * 2. 从Redis获取Token数据
 * 3. 检查Token是否过期
 * 4. 检查Token使用次数
 * 5. 将Token数据附加到请求对象
 * 
 * ⚠️ URL格式：https://domain.com/xxxxxxxxxx（10位Token作为路径参数）
 * ============================================
 */

const TokenGenerator = require('../utils/tokenGenerator');
const Database = require('../database/mysql');
const logger = require('../utils/logger');
const { config } = require('../config');
const crypto = require('crypto');

/**
 * 生成友好的404错误页面
 * @returns {string} HTML页面
 */
function generate404Page() {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
      <meta name="format-detection" content="telephone=no, email=no, address=no">
    </head>
    <body>
      <div style="font-weight: bold;">404 Not Found</div>
      <div>The page never existed on the site.</div>
    </body>
    </html>
  `;
}

/**
 * Token验证中间件
 */
async function tokenValidator(req, res, next) {
  // ✅ 从路径参数获取完整路径（URL格式：/xxxxxxxxxx.suffix）
  // Token固定为10位，后面的都是伪装后缀（如 .jp, .html, .tokyo.jp 等）
  const fullPath = req.params.token;

  try {
    // 1. 检查路径参数是否存在
    if (!fullPath) {
      logger.warn('缺少Token参数', {
        ip: req.ip,
        url: req.url,
      });

      // ✅ 返回友好的404页面
      return res.status(404).send(generate404Page());
    }

    // 2. 提取前10位作为Token（Token固定为10位，其余是后缀）
    // 例如：Xml9PhV9wo.tokyo.jp → Token = Xml9PhV9wo
    if (fullPath.length < 10) {
      logger.warn('Token格式错误：长度不足', {
        ip: req.ip,
        pathLength: fullPath.length,
        expectedMinLength: 10
      });

      // ✅ 返回友好的404页面
      return res.status(404).send(generate404Page());
    }

    // 提取前10位作为真正的Token
    const token = fullPath.substring(0, 10);

    // 3. 验证Token（从Redis获取数据）
    const verifyResult = await TokenGenerator.verify(token);

    if (!verifyResult.valid) {
      logger.warn('Token验证失败', {
        ip: req.ip,
        reason: verifyResult.reason,
        token: token.substring(0, 4) + '****',
      });

      // ✅ 所有Token验证失败都返回友好的404页面
      return res.status(404).send(generate404Page());
    }

    // 4. 获取Token数据
    const tokenData = verifyResult.data;

    // 5. 生成Token哈希（用于数据库记录）
    const tokenHash = crypto
      .createHash('sha256')
      .update(token)
      .digest('hex')
      .substring(0, 16); // 哈希值取前16位，与Token长度无关

    // 6. 检查Token使用次数
    const usageCheck = await checkTokenUsage(tokenHash, tokenData);

    if (!usageCheck.allowed) {
      logger.warn('Token使用次数超限', {
        ip: req.ip,
        emailId: tokenData.eid,
        useCount: usageCheck.useCount,
        maxUses: usageCheck.maxUses,
      });

      // ✅ Token使用超限也返回友好的404页面
      return res.status(404).send(generate404Page());
    }

    // 7. Token验证通过，附加数据到请求对象
    req.tokenData = tokenData;
    req.tokenHash = tokenHash;
    req.shortToken = token;

    logger.debug('Token验证通过', {
      ip: req.ip,
      emailId: tokenData.eid,
    });

    next();

  } catch (error) {
    logger.error('Token验证过程出错', {
      ip: req.ip,
      error: error.message,
      stack: error.stack
    });

    // ✅ 服务器错误也返回友好的404页面
    return res.status(404).send(generate404Page());
  }
}

/**
 * 检查Token使用次数
 * @param {string} tokenHash - Token哈希
 * @param {Object} tokenData - Token数据
 * @returns {Promise<Object>} - 检查结果
 */
async function checkTokenUsage(tokenHash, tokenData) {
  try {
    // 查询Token使用记录
    const usage = await Database.getTokenUsage(tokenHash);

    if (!usage) {
      // Token首次使用，允许通过
      return {
        allowed: true,
        useCount: 0,
        maxUses: config.token.maxUses || 999999,
      };
    }

    // 检查是否超过最大使用次数
    const maxUses = usage.max_uses || config.token.maxUses || 999999;
    const allowed = usage.use_count < maxUses;

    return {
      allowed,
      useCount: usage.use_count,
      maxUses,
    };
  } catch (error) {
    logger.error('查询Token使用失败', {
      error: error.message,
      tokenHash: tokenHash.substring(0, 8) + '...',
    });

    // 出错时允许通过（保守策略）
    return {
      allowed: true,
      useCount: 0,
      maxUses: config.token.maxUses || 999999,
      error: error.message,
    };
  }
}

/**
 * 记录Token使用（在请求处理完成后调用）
 * @param {string} tokenHash - Token哈希
 * @param {Object} tokenData - Token数据
 * @param {string} ip - IP地址
 * @returns {Promise<void>}
 */
async function recordTokenUsage(tokenHash, tokenData, ip) {
  try {
    const expiresAt = new Date(tokenData.exp);
    await Database.recordTokenUsage(
      tokenHash,
      tokenData.eid,
      config.token.maxUses || 999999,
      expiresAt
    );
    
    logger.debug('Token使用已记录', {
      tokenHash: tokenHash.substring(0, 8) + '...',
      emailId: tokenData.eid,
      ip: ip
    });
  } catch (error) {
    logger.error('记录Token使用失败', {
      error: error.message,
      emailId: tokenData.eid,
    });
  }
}

module.exports = {
  tokenValidator,
  checkTokenUsage,
  recordTokenUsage,
};
