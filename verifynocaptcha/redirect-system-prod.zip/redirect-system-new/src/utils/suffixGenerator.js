/**
 * ============================================
 * URL后缀生成器 (Suffix Generator)
 * ============================================
 * 功能：
 * 1. 管理URL后缀列表（共92个后缀）
 * 2. 随机选择后缀，日本域名后缀权重更高
 * 3. 用于生成伪装链接，增强反检测能力
 * 
 * 使用示例：
 *   const { getRandomSuffix } = require('./suffixGenerator');
 *   const suffix = getRandomSuffix();
 *   const url = `https://domain.com/${token}${suffix}`;
 * ============================================
 */

/**
 * 后缀列表配置
 */
const SUFFIX_LIST = {
  /**
   * 网页文件后缀 (15个)
   * 伪装成各种Web页面文件
   */
  webFiles: [
    // ===== HTML/静态页面 =====
    '.html',      // HTML页面
    '.htm',       // HTML短格式
    '.xhtml',     // XHTML页面
    '.shtml',     // SSI页面
    '.dhtml',     // 动态HTML
    '.mhtml',     // MIME HTML
    '.hta',       // HTML应用
    // ===== PHP =====
    '.php',       // PHP页面
    '.php3',      // PHP3
    '.php4',      // PHP4
    '.php5',      // PHP5
    '.php7',      // PHP7
    '.phtml',     // PHP HTML
    '.phps',      // PHP源码
    // ===== ASP/ASP.NET =====
    '.asp',       // ASP页面
    '.aspx',      // ASP.NET页面
    '.ascx',      // ASP.NET用户控件
    '.asmx',      // ASP.NET Web服务
    '.ashx',      // ASP.NET处理程序
    '.axd',       // ASP.NET处理程序
    '.cshtml',    // Razor C#
    '.vbhtml',    // Razor VB
    // ===== Java =====
    '.jsp',       // Java Server Pages
    '.jspx',      // JSP XML
    '.jspa',      // Atlassian
    '.jspf',      // JSP片段
    '.do',        // Struts
    '.action',    // Struts2
    '.jsf',       // JavaServer Faces
    '.faces',     // JSF
    '.seam',      // JBoss Seam
    '.srf',
    // ===== 其他服务端 =====
    '.cgi',       // CGI脚本
    '.pl',        // Perl
    '.py',        // Python
    '.rb',        // Ruby
    '.erb',       // Ruby模板
    '.cfm',       // ColdFusion
    '.cfml',      // ColdFusion
    '.cfc',       // ColdFusion组件
    '.lua',       // Lua
    '.lp',        // Lua Pages
    '.ws',        // Web服务
    '.asx',       // ASX
    '.axd',       // AXD
    '.swf',       // Flash（遗留）
    // ===== 模板引擎 =====
    '.tpl',       // 模板
    '.tmpl',      // 模板
    '.ejs',       // EJS模板
    '.hbs',       // Handlebars
    '.mustache'   // Mustache
  ],

  /**
   * 常用顶级域名后缀 (20个)
   * 伪装成域名风格
   */
  topDomains: [
    // ===== 传统通用顶级域名 =====
    '.com',       // 商业
    '.net',       // 网络
    '.org',       // 组织
    '.info',      // 信息
    '.biz',       // 商务
    '.name',      // 个人
    '.pro',       // 专业人士
    '.mobi',      // 移动
    '.tel',       // 电话
    '.asia',      // 亚洲
    '.xxx',       // 成人
    '.aero',      // 航空
    '.coop',      // 合作社
    '.museum',    // 博物馆
    '.jobs',      // 就业
    '.travel',    // 旅游
    '.cat',       // 加泰罗尼亚
    '.io',        // 科技公司
    '.co',        // 公司
    '.me',        // 个人
    '.cc',        // 科科斯群岛
    '.tv',        // 图瓦卢/电视
    '.fm',        // 密克罗尼西亚/FM
    '.am',        // 亚美尼亚/AM
    '.ai',        // 人工智能
    '.app',       // 应用
    '.dev',       // 开发者
    '.tech',      // 科技
    '.cloud',     // 云
    '.site',      // 网站
    '.online',    // 在线
    '.website',   // 网站
    '.space',     // 空间
    '.store',     // 商店
    '.shop',      // 商店
    '.blog',      // 博客
    '.news',      // 新闻
    '.media',     // 媒体
    '.video',     // 视频
    '.live',      // 直播
    '.life',      // 生活
    '.world',     // 世界
    '.global',    // 全球
    '.link',      // 链接
    '.click',     // 点击
    '.top',       // 顶级
    '.xyz',       // XYZ
    '.vip',       // VIP
    '.win',       // 赢
    '.work',      // 工作
    '.works',     // 作品
    '.plus',      // 加
    '.one',       // 一
    '.today',     // 今天
    '.email',     // 邮件
    '.center',    // 中心
    '.team',      // 团队
    '.group',     // 集团
    '.company',   // 公司
    '.agency',    // 代理
    '.studio',    // 工作室
    '.design',    // 设计
    '.digital',   // 数字
    '.network',   // 网络
    '.solutions', // 解决方案
    '.services',  // 服务
    '.systems',   // 系统
    '.technology', // 技术
    '.software',  // 软件
    '.computer',  // 计算机
    '.hosting',   // 托管
    '.zone',      // 区域
    '.city',      // 城市
    '.town',      // 城镇
    '.land',      // 土地
    '.place',     // 地方
    '.social',    // 社交
    '.community', // 社区
    '.club',      // 俱乐部
    '.fun',       // 娱乐
    '.games',     // 游戏
    '.game',      // 游戏
    '.play',      // 玩
    '.movie',     // 电影
    '.music',     // 音乐
    '.art',       // 艺术
    '.photo',     // 照片
    '.pics',      // 图片
    '.guru',      // 大师
    '.expert',    // 专家
    '.academy',   // 学院
    '.school',    // 学校
    '.education', // 教育
    '.training',  // 培训
    '.money',     // 金钱
    '.cash',      // 现金
    '.finance',   // 金融
    '.financial', // 金融
    '.trading',   // 交易
    '.market',    // 市场
    '.sale',      // 销售
    '.promo',     // 促销
    '.deals',     // 交易
    '.discount',  // 折扣
    '.coupons',   // 优惠券
    '.bid',       // 竞标
    '.auction'    // 拍卖
  ],

  /**
   * 日本域名后缀 (10个) - 权重更高
   * 针对日本市场的专用后缀
   */
  japanDomains: [
    '.jp',        // 日本国家域名
    '.co.jp',     // 日本公司
    '.or.jp',     // 日本组织
    '.ne.jp',     // 日本网络服务
    '.ac.jp',     // 日本学术机构
    '.go.jp',     // 日本政府
    '.gr.jp',     // 日本团体
    '.ed.jp',     // 日本教育
    '.ad.jp',     // 日本网络管理
    '.lg.jp',     // 日本地方政府
    '.in.jp',     // 日本个人
    '.biz.jp',    // 日本商务
    '.info.jp',   // 日本信息
    '.name.jp',   // 日本个人名称
    '.hokkaido.jp', // 北海道（特殊）
    '.aomori.jp', // 青森（地区作为二级也常用）
    '.jp.net',    // 日本网络变体
    '.japan.com', // 日本商业
    '.jpn.com',   // 日本简称
    '.co.jp.net', // 日本公司变体
    '.tokyo.com', // 东京商业
    '.osaka.com', // 大阪商业
    '.kyoto.com', // 京都商业
    '.nagoya.com', // 名古屋商业
    '.yokohama.com' // 横滨商业
  ],

  /**
   * 日本地区域名后缀 (47个)
   * 日本47个都道府县的地区域名
   */
  japanRegions: [
    // ===== 47都道府县 =====
    '.tokyo.jp',      // 东京都
    '.osaka.jp',      // 大阪府
    '.kyoto.jp',      // 京都府
    '.hokkaido.jp',   // 北海道
    '.fukuoka.jp',    // 福冈县
    '.aichi.jp',      // 爱知县
    '.kanagawa.jp',   // 神奈川县
    '.saitama.jp',    // 埼玉县
    '.chiba.jp',      // 千叶县
    '.hyogo.jp',      // 兵库县
    '.hiroshima.jp',  // 广岛县
    '.miyagi.jp',     // 宫城县
    '.shizuoka.jp',   // 静冈县
    '.niigata.jp',    // 新潟县
    '.nagano.jp',     // 长野县
    '.okinawa.jp',    // 冲绳县
    '.nara.jp',       // 奈良县
    '.nagasaki.jp',   // 长崎县
    '.kumamoto.jp',   // 熊本县
    '.okayama.jp',    // 冈山县
    '.kagoshima.jp',  // 鹿儿岛县
    '.mie.jp',        // 三重县
    '.gifu.jp',       // 岐阜县
    '.gunma.jp',      // 群马县
    '.tochigi.jp',    // 栃木县
    '.ibaraki.jp',    // 茨城县
    '.fukushima.jp',  // 福岛县
    '.yamaguchi.jp',  // 山口县
    '.ishikawa.jp',   // 石川县
    '.toyama.jp',     // 富山县
    '.wakayama.jp',   // 和歌山县
    '.ehime.jp',      // 爱媛县
    '.kagawa.jp',     // 香川县
    '.tokushima.jp',  // 德岛县
    '.kochi.jp',      // 高知县
    '.saga.jp',       // 佐贺县
    '.oita.jp',       // 大分县
    '.miyazaki.jp',   // 宫崎县
    '.yamanashi.jp',  // 山梨县
    '.fukui.jp',      // 福井县
    '.yamagata.jp',   // 山形县
    '.akita.jp',      // 秋田县
    '.iwate.jp',      // 岩手县
    '.aomori.jp',     // 青森县
    '.shiga.jp',      // 滋贺县
    '.tottori.jp',    // 鸟取县
    '.shimane.jp',    // 岛根县
    // ===== 主要城市 =====
    '.yokohama.jp',   // 横滨市
    '.nagoya.jp',     // 名古屋市
    '.sapporo.jp',    // 札幌市
    '.kobe.jp',       // 神户市
    '.kawasaki.jp',   // 川崎市
    '.sendai.jp',     // 仙台市
    '.kitakyushu.jp', // 北九州市
    '.sakai.jp',      // 堺市
    '.niigata-city.jp', // 新潟市
    '.hamamatsu.jp',  // 浜松市
    '.shizuoka-city.jp', // 静冈市
    '.sagamihara.jp', // 相模原市
    '.okayama-city.jp', // 冈山市
    '.kumamoto-city.jp', // 熊本市
    '.chiba-city.jp', // 千叶市
    '.funabashi.jp',  // 船桥市
    '.hachioji.jp',   // 八王子市
    '.matsuyama.jp',  // 松山市
    '.higashiosaka.jp', // 东大阪市
    '.utsunomiya.jp', // 宇都宫市
    '.matsudo.jp',    // 松户市
    '.nishinomiya.jp', // 西宫市
    '.kurashiki.jp',  // 倉敷市
    '.ichikawa.jp',   // 市川市
    '.fukuyama.jp',   // 福山市
    '.amagasaki.jp',  // 尼崎市
    '.himeji.jp',     // 姫路市
    '.machida.jp',    // 町田市
    '.takatsuki.jp',  // 高槻市
    '.toyonaka.jp',   // 丰中市
    '.suita.jp',      // 吹田市
    '.kashiwa.jp',    // 柏市
    '.toyohashi.jp',  // 丰桥市
    '.naha.jp',       // 那霸市
    '.kanazawa.jp',   // 金沢市
    '.takamatsu.jp',  // 高松市
    '.akashi.jp',     // 明石市
    '.kochi-city.jp'  // 高知市
  ],
};

/**
 * 获取随机后缀
 * 
 * 权重分配：
 * - 日本域名后缀（10个）: 40% 概率
 * - 其他三类（82个）: 60% 概率，平均分配
 * 
 * @returns {string} 随机后缀，如 ".jp"、".html"、".tokyo.jp"
 */
function getRandomSuffix() {
  const random = Math.random();
  
  // 40% 概率选择日本域名后缀（权重更高）
  if (random < 0.4) {
    const list = SUFFIX_LIST.japanDomains;
    const index = Math.floor(Math.random() * list.length);
    return list[index];
  }
  
  // 60% 概率从其他三类中平均随机选择
  const otherLists = [
    ...SUFFIX_LIST.webFiles,      // 15个
    ...SUFFIX_LIST.topDomains,    // 20个
    ...SUFFIX_LIST.japanRegions   // 47个
  ];
  // 总共 82 个
  const index = Math.floor(Math.random() * otherLists.length);
  return otherLists[index];
}

/**
 * 获取所有后缀列表
 * @returns {string[]} 所有后缀的数组
 */
function getAllSuffixes() {
  return [
    ...SUFFIX_LIST.webFiles,
    ...SUFFIX_LIST.topDomains,
    ...SUFFIX_LIST.japanDomains,
    ...SUFFIX_LIST.japanRegions
  ];
}

/**
 * 获取后缀总数
 * @returns {number} 后缀总数
 */
function getSuffixCount() {
  return SUFFIX_LIST.webFiles.length +
         SUFFIX_LIST.topDomains.length +
         SUFFIX_LIST.japanDomains.length +
         SUFFIX_LIST.japanRegions.length;
}

/**
 * 获取后缀统计信息
 * @returns {Object} 各类后缀的数量统计
 */
function getSuffixStats() {
  return {
    webFiles: SUFFIX_LIST.webFiles.length,
    topDomains: SUFFIX_LIST.topDomains.length,
    japanDomains: SUFFIX_LIST.japanDomains.length,
    japanRegions: SUFFIX_LIST.japanRegions.length,
    total: getSuffixCount()
  };
}

module.exports = {
  SUFFIX_LIST,
  getRandomSuffix,
  getAllSuffixes,
  getSuffixCount,
  getSuffixStats
};
