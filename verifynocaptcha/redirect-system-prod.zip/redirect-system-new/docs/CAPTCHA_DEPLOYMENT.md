# 🔐 人机验证功能部署指南

## 📋 功能概述

本次更新为反检测重定向系统新增了**人机验证层**，在访问者通过7层过滤器后，需要完成图片点击验证才能跳转到目标URL。

### 验证流程图
```
用户点击链接 https://域名/Xkx35KTkGx
                    ↓
            ┌───────────────┐
            │  Token验证     │
            └───────┬───────┘
                    ↓
            ┌───────────────┐
            │  7层过滤器     │
            │  安全/地理/    │
            │  语言/设备...  │
            └───────┬───────┘
                    ↓
              过滤结果？
             ↙        ↘
          拒绝         通过
           ↓            ↓
      伪装URL    ┌───────────────┐
                │ ENABLE_CAPTCHA │ ← 后台开关
                │    启用？       │
                └───────┬───────┘
                        ↓
                  启用？
                 ↙     ↘
               否       是
               ↓        ↓
          目标URL   ┌───────────────┐
                   │  验证页面      │
                   │  ○ ● ○ ● ○   │
                   │  点击绿色盾牌  │
                   └───────┬───────┘
                           ↓
                     验证结果？
                    ↙        ↘
                 失败         成功
                  ↓            ↓
            3次失败？      目标URL
            ↙      ↘
           否       是
           ↓        ↓
        重试     封IP 30分钟
```

### 功能特性
- ✅ 随机生成1-5个绿盾牌图标
- ✅ 位置随机分布
- ✅ 3次失败后封禁IP 30分钟
- ✅ 验证超时5分钟
- ✅ 管理后台可开关（ENABLE_CAPTCHA配置项）
- ✅ 响应式设计（支持电脑和手机）
- ✅ 日文界面

---

## 📁 文件变更清单

### 新增文件（4个）
| 文件路径 | 说明 |
|---------|------|
| `src/services/captchaService.js` | 人机验证服务（生成、验证、封禁） |
| `src/routes/captcha.js` | 人机验证路由（/captcha/verify, /captcha/go/:token） |
| `src/public/captcha.html` | 验证页面模板（日文界面） |
| `src/public/images/security.png` | 绿盾牌图标 |
| `src/public/images/captcha-decoy.png` | 灰色圆形图标 |

### 修改文件（3个）
| 文件路径 | 修改内容 |
|---------|---------|
| `src/index.js` | +path模块、+captchaRoutes、+静态文件服务 |
| `src/routes/redirect.js` | 在过滤通过后添加人机验证逻辑 |
| `production_database.sql` | 添加ENABLE_CAPTCHA配置项（id=63） |

---

## 🚀 部署步骤

### 方式一：全新部署（使用完整SQL文件）

如果是全新服务器部署，直接使用 `production_database.sql` 即可，已包含ENABLE_CAPTCHA配置项。

```bash
# 1. 创建数据库
mysql -u root -p
CREATE DATABASE redirect_system_prod CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'redirect_user'@'localhost' IDENTIFIED BY 'Hell0@MaiDong';
GRANT ALL PRIVILEGES ON redirect_system_prod.* TO 'redirect_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# 2. 导入数据库
mysql -u redirect_user -p redirect_system_prod < production_database.sql

# 3. 安装依赖
cd /var/www/redirect-system
npm install

# 4. 启动服务
pm2 start ecosystem.config.js --env production
pm2 save
```

### 方式二：增量更新（现有服务器）

如果是现有服务器更新，请按以下步骤操作：

```bash
# 1. SSH登录服务器
ssh root@你的服务器IP

# 2. 备份当前代码
cd /var/www
cp -r redirect-system redirect-system-backup-$(date +%Y%m%d)

# 3. 上传新代码（或解压zip包）
# 将 redirect-system-new.zip 上传到服务器并解压覆盖

# 4. 添加人机验证配置项到数据库
mysql -u redirect_user -p redirect_system_prod -e "
INSERT INTO config_items (id, category, key_name, value, data_type, description, is_sensitive, is_active, updated_by, updated_at, created_at)
VALUES (63, 'filter_settings', 'ENABLE_CAPTCHA', 'true', 'boolean', '人机验证（通过7层过滤器后显示验证页面）', 0, 1, 'admin', NOW(), NOW())
ON DUPLICATE KEY UPDATE value = VALUES(value), description = VALUES(description), updated_at = NOW();
"

# 5. 确认配置项已添加
mysql -u redirect_user -p redirect_system_prod -e "SELECT * FROM config_items WHERE key_name = 'ENABLE_CAPTCHA';"

# 6. 安装依赖（如有新增）
cd /var/www/redirect-system
npm install

# 7. 重启服务
pm2 restart all

# 8. 保存PM2配置
pm2 save

# 9. 检查服务状态
pm2 status
netstat -tlnp | grep -E '3000|3001'
```

---

## ⚙️ 配置说明

### 管理后台配置项
登录管理后台后，在配置管理 -> 过滤器设置 中可以看到：

| 配置项 | 键名 | 默认值 | 说明 |
|--------|------|-------|------|
| 人机验证 | ENABLE_CAPTCHA | true | 启用/禁用人机验证 |

**设置为 `true`**：通过7层过滤器后显示验证页面
**设置为 `false`**：通过7层过滤器后直接跳转到目标URL

### 代码内置配置
以下配置在 `src/services/captchaService.js` 中定义，如需修改请编辑源代码：

```javascript
static CONFIG = {
  TOTAL_IMAGES: 5,           // 总图片数量（固定5个）
  MIN_SECURITY: 1,           // 最少绿盾牌数量
  MAX_SECURITY: 5,           // 最多绿盾牌数量
  CAPTCHA_TTL: 300,          // 验证有效期（秒）= 5分钟
  MAX_ATTEMPTS: 3,           // 最大尝试次数
  BAN_DURATION: 1800,        // 封禁时长（秒）= 30分钟
  REDIRECT_TOKEN_TTL: 60,    // 跳转Token有效期（秒）= 1分钟
};
```

---

## 🔍 测试方法

### 1. 生成测试Token
```bash
curl "http://你的域名/generate-token?email=test@example.com"
```

### 2. 访问测试链接
在浏览器中打开返回的链接，例如：
```
https://你的域名/Xkx35KTkGx
```

### 3. 预期行为
| 场景 | 预期结果 |
|------|---------|
| 过滤器通过 + 人机验证启用 | 显示验证页面 |
| 点击正确的绿盾牌 | 跳转到目标URL |
| 点击错误 | 显示错误提示，剩余2次机会 |
| 3次失败 | IP被封禁30分钟，跳转到伪装URL |
| 过滤器通过 + 人机验证禁用 | 直接跳转到目标URL |
| 过滤器拒绝 | 跳转到伪装URL |

### 4. 测试封禁功能
```bash
# 查看Redis中的封禁记录
redis-cli
> KEYS captcha_ban:*
> GET captcha_ban:你的IP
> TTL captcha_ban:你的IP
```

---

## 📊 日志说明

### 成功验证日志
```
info: 生成人机验证 {"captchaId":"abc12345...","securityCount":3,"positions":[0,2,4],"ip":"x.x.x.x"}
info: 人机验证成功 {"captchaId":"abc12345...","ip":"x.x.x.x"}
info: 执行验证后跳转 {"token":"def67890...","targetURL":"https://..."}
```

### 失败验证日志
```
warn: 人机验证失败 {"captchaId":"abc12345...","ip":"x.x.x.x","attempts":1,"correct":[0,2,4],"user":[0,1,4]}
warn: IP已被封禁 {"ip":"x.x.x.x","duration":1800}
```

---

## 🛠️ 故障排除

### 问题1：验证页面图片不显示
```bash
# 检查图片文件是否存在
ls -la /var/www/redirect-system/src/public/images/

# 检查文件权限
chmod 644 /var/www/redirect-system/src/public/images/*.png

# 检查静态文件路由是否生效
curl -I http://127.0.0.1:3000/images/security.png
```

### 问题2：验证提交后无响应
```bash
# 检查路由是否正确加载
pm2 logs redirect-system --lines 100 | grep -i captcha

# 检查Redis是否正常
redis-cli ping
```

### 问题3：数据库配置项不存在
```sql
-- 手动插入配置项
INSERT INTO config_items (category, key_name, value, data_type, description, is_active)
VALUES ('filter_settings', 'ENABLE_CAPTCHA', 'true', 'boolean', '人机验证', 1);
```

### 问题4：人机验证不生效
```bash
# 检查配置项状态
mysql -u redirect_user -p redirect_system_prod -e "
SELECT * FROM config_items WHERE key_name = 'ENABLE_CAPTCHA';
"

# 确保value为'true'且is_active为1
```

---

## 🔄 回滚方案

如果部署后出现问题，可以快速回滚：

### 方法1：禁用人机验证（推荐）
```sql
-- 在数据库中禁用
UPDATE config_items SET value = 'false' WHERE key_name = 'ENABLE_CAPTCHA';
```
立即生效，无需重启服务。

### 方法2：恢复备份代码
```bash
# 恢复备份
cd /var/www
rm -rf redirect-system
mv redirect-system-backup-YYYYMMDD redirect-system

# 重启服务
pm2 restart all
```

---

## ✅ 部署检查清单

- [ ] 备份现有代码
- [ ] 上传/解压新代码
- [ ] 检查 `src/public/images/` 目录存在且包含图片
- [ ] 执行数据库迁移（添加ENABLE_CAPTCHA配置项）
- [ ] 安装依赖 `npm install`
- [ ] 重启PM2服务
- [ ] 验证健康检查接口 `curl http://127.0.0.1:3000/health`
- [ ] 测试图片静态资源 `curl -I http://127.0.0.1:3000/images/security.png`
- [ ] 测试完整验证流程（生成Token -> 访问 -> 验证）
- [ ] 确认日志正常
- [ ] 保存PM2配置 `pm2 save`

---

## 📝 版本信息

- **更新日期**: 2025年12月
- **版本**: v1.1.0
- **更新内容**: 新增人机验证功能
