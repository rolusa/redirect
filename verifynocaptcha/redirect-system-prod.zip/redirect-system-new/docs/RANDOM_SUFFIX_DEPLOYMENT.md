# 🔗 URL随机后缀功能部署文档

## 📋 功能概述

为反检测重定向系统新增URL随机后缀功能，使生成的链接更具多样性，增强反检测能力。

### 功能效果对比

| 修改前 | 修改后 |
|--------|--------|
| `https://8voo.com/Xml9PhV9wo` | `https://8voo.com/Xml9PhV9wo.jp` |
| `https://8voo.com/Kp3mNx7Rqw` | `https://8voo.com/Kp3mNx7Rqw.tokyo.jp` |
| `https://8voo.com/Yt8sLm2Dfg` | `https://8voo.com/Yt8sLm2Dfg.html` |
| `https://8voo.com/Qw5vBn9Hjk` | `https://8voo.com/Qw5vBn9Hjk.co.jp` |

---

## 📁 修改文件清单

| 文件路径 | 操作类型 | 说明 |
|---------|---------|------|
| `src/utils/suffixGenerator.js` | **新增** | 后缀生成工具（92种后缀） |
| `src/middleware/tokenValidator.js` | **修改** | 从URL提取前10位作为Token |
| `src/admin/routes/tokens.js` | **修改** | 批量生成时添加随机后缀 |
| `src/routes/redirect.js` | **修改** | 测试链接添加随机后缀 |

---

## 🎯 后缀列表（共92个）

### 1. 网页文件后缀（15个）
```
.html, .htm, .php, .asp, .aspx, .jsp, .do, .action,
.cgi, .pl, .cfm, .shtml, .xhtml, .jspx, .jspa
```

### 2. 常用顶级域名后缀（20个）
```
.com, .net, .org, .info, .biz, .io, .co, .me, .cc, .tv,
.fm, .am, .cloud, .app, .dev, .tech, .site, .online, .link, .click
```

### 3. 日本域名后缀（10个）⭐ 权重更高
```
.jp, .co.jp, .or.jp, .ne.jp, .ac.jp,
.go.jp, .gr.jp, .ed.jp, .ad.jp, .lg.jp
```

### 4. 日本地区域名后缀（47个）
```
.tokyo.jp, .osaka.jp, .kyoto.jp, .hokkaido.jp, .fukuoka.jp,
.aichi.jp, .kanagawa.jp, .saitama.jp, .chiba.jp, .hyogo.jp,
.hiroshima.jp, .miyagi.jp, .shizuoka.jp, .niigata.jp, .nagano.jp,
.okinawa.jp, .nara.jp, .nagasaki.jp, .kumamoto.jp, .okayama.jp,
.kagoshima.jp, .mie.jp, .gifu.jp, .gunma.jp, .tochigi.jp,
.ibaraki.jp, .fukushima.jp, .yamaguchi.jp, .ishikawa.jp, .toyama.jp,
.wakayama.jp, .ehime.jp, .kagawa.jp, .tokushima.jp, .kochi.jp,
.saga.jp, .oita.jp, .miyazaki.jp, .yamanashi.jp, .fukui.jp,
.yamagata.jp, .akita.jp, .iwate.jp, .aomori.jp, .shiga.jp,
.tottori.jp, .shimane.jp
```

---

## ⚖️ 权重分配

| 后缀类别 | 数量 | 出现概率 |
|---------|------|---------|
| 日本域名后缀 | 10个 | **40%** |
| 网页文件后缀 | 15个 | 20%（60%÷3） |
| 顶级域名后缀 | 20个 | 20%（60%÷3） |
| 日本地区后缀 | 47个 | 20%（60%÷3） |

> 日本域名后缀权重更高，更适合针对日本市场的邮件营销

---

## 🔄 工作原理

### 生成链接时
```
Token: Xml9PhV9wo
     ↓ 随机选择后缀
后缀: .tokyo.jp
     ↓ 拼接
URL: https://8voo.com/Xml9PhV9wo.tokyo.jp
```

### 验证链接时
```
请求: https://8voo.com/Xml9PhV9wo.tokyo.jp
     ↓ Express路由匹配 /:token
参数: Xml9PhV9wo.tokyo.jp
     ↓ 提取前10位
Token: Xml9PhV9wo
     ↓ Redis验证
验证通过 → 继续过滤流程
```

---

## 🚀 部署步骤

### 方法一：全新部署

```bash
# 1. 上传完整项目到服务器
scp redirect-system-prod.zip root@43.153.178.165:/var/www/

# 2. SSH连接服务器
ssh root@43.153.178.165

# 3. 解压并部署
cd /var/www
unzip redirect-system-prod.zip
mv redirect-system-new redirect-system

# 4. 安装依赖
cd /var/www/redirect-system
npm install

# 5. 重启服务
pm2 restart all
pm2 save
```

### 方法二：增量更新（只更新修改的文件）

```bash
# 1. 备份现有文件
cd /var/www/redirect-system
cp src/utils/suffixGenerator.js src/utils/suffixGenerator.js.bak 2>/dev/null
cp src/middleware/tokenValidator.js src/middleware/tokenValidator.js.bak
cp src/admin/routes/tokens.js src/admin/routes/tokens.js.bak
cp src/routes/redirect.js src/routes/redirect.js.bak

# 2. 上传新文件（从本地）
# 使用scp或其他方式上传以下文件：
# - src/utils/suffixGenerator.js（新文件）
# - src/middleware/tokenValidator.js
# - src/admin/routes/tokens.js
# - src/routes/redirect.js

# 3. 重启服务
pm2 restart all
pm2 save

# 4. 验证服务状态
pm2 status
```

---

## ✅ 验证测试

### 1. 语法检查
```bash
cd /var/www/redirect-system
node --check src/utils/suffixGenerator.js
node --check src/middleware/tokenValidator.js
node --check src/admin/routes/tokens.js
node --check src/routes/redirect.js
```

### 2. 后缀生成测试
```bash
cd /var/www/redirect-system
node -e "
const { getRandomSuffix, getSuffixStats } = require('./src/utils/suffixGenerator');
console.log('后缀统计:', getSuffixStats());
console.log('随机后缀示例:');
for (let i = 0; i < 5; i++) {
  console.log('  Xml9PhV9wo' + getRandomSuffix());
}
"
```

### 3. 服务启动测试
```bash
pm2 restart redirect-main
pm2 logs redirect-main --lines 20
```

### 4. 链接生成测试
在管理后台批量生成Token，检查生成的链接是否包含随机后缀。

### 5. 链接访问测试
使用浏览器或curl访问带后缀的链接：
```bash
# 测试各种后缀格式
curl -I "https://8voo.com/Xml9PhV9wo.jp"
curl -I "https://8voo.com/Xml9PhV9wo.tokyo.jp"
curl -I "https://8voo.com/Xml9PhV9wo.html"
curl -I "https://8voo.com/Xml9PhV9wo.co.jp"
```

---

## 🔧 故障排除

### 问题1：链接访问返回404
**原因**：Token无效或已过期
**解决**：检查Token是否在Redis中存在

### 问题2：后缀没有添加到链接
**原因**：tokens.js未正确引用suffixGenerator
**解决**：检查文件引用是否正确

### 问题3：验证时报Token格式错误
**原因**：tokenValidator.js修改不正确
**解决**：确保从URL提取前10位作为Token

---

## ↩️ 回滚方案

如需回滚到修改前的版本：

```bash
cd /var/www/redirect-system

# 恢复备份文件
cp src/middleware/tokenValidator.js.bak src/middleware/tokenValidator.js
cp src/admin/routes/tokens.js.bak src/admin/routes/tokens.js
cp src/routes/redirect.js.bak src/routes/redirect.js

# 删除新增文件
rm src/utils/suffixGenerator.js

# 重启服务
pm2 restart all
```

---

## 📊 代码变更详情

### 1. 新增文件：`src/utils/suffixGenerator.js`

完整的后缀生成工具，包含：
- `SUFFIX_LIST` - 所有后缀列表（92个）
- `getRandomSuffix()` - 获取随机后缀（带权重）
- `getAllSuffixes()` - 获取所有后缀数组
- `getSuffixCount()` - 获取后缀总数
- `getSuffixStats()` - 获取后缀统计信息

### 2. 修改文件：`src/middleware/tokenValidator.js`

**修改点**：从URL路径参数中提取前10位作为Token

```javascript
// 修改前
const token = req.params.token;
if (token.length !== 10) { ... }

// 修改后
const fullPath = req.params.token;
if (fullPath.length < 10) { ... }
const token = fullPath.substring(0, 10);
```

### 3. 修改文件：`src/admin/routes/tokens.js`

**修改点**：
1. 添加 `SuffixGenerator` 引用
2. 生成链接时添加随机后缀

```javascript
// 添加引用
const SuffixGenerator = require('../../utils/suffixGenerator');

// 生成链接时添加后缀
const randomSuffix = SuffixGenerator.getRandomSuffix();
const trackingLink = `https://${selectedDomain}/${tokenResult.token}${randomSuffix}`;
```

### 4. 修改文件：`src/routes/redirect.js`

**修改点**：
1. 添加 `SuffixGenerator` 引用
2. 测试链接添加随机后缀

```javascript
// 添加引用
const SuffixGenerator = require('../utils/suffixGenerator');

// 测试链接添加后缀
const randomSuffix = SuffixGenerator.getRandomSuffix();
testURL: `${req.protocol}://${req.get('host')}/${token}${randomSuffix}`,
```

---

## 📝 注意事项

1. **兼容性**：修改后的系统同时支持带后缀和不带后缀的链接
2. **数据库**：无需修改数据库结构
3. **已生成链接**：之前生成的不带后缀的链接仍然有效
4. **权重调整**：如需调整后缀权重，修改 `suffixGenerator.js` 中的 `0.4` 值

---

**文档版本**：1.0  
**更新日期**：2025-12-24  
**作者**：Claude AI
