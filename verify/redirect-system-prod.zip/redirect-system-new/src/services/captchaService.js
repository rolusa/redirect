/**
 * ============================================
 * 人机验证服务 (Captcha Service)
 * ============================================
 * 功能：
 * 1. 生成随机验证图片位置
 * 2. 存储验证信息到Redis
 * 3. 验证用户点击结果
 * 4. IP封禁管理
 * ============================================
 */

const crypto = require('crypto');
const Redis = require('../database/redis');
const Database = require('../database/mysql');
const logger = require('../utils/logger');

/**
 * 人机验证服务类
 */
class CaptchaService {
  // 配置常量
  static CONFIG = {
    TOTAL_IMAGES: 5,           // 总图片数量
    MIN_SECURITY: 1,           // 最少绿盾牌数量
    MAX_SECURITY: 5,           // 最多绿盾牌数量
    CAPTCHA_TTL: 300,          // 验证有效期（秒）= 5分钟
    MAX_ATTEMPTS: 3,           // 最大尝试次数
    BAN_DURATION: 1800,        // 封禁时长（秒）= 30分钟
    REDIRECT_TOKEN_TTL: 60,    // 跳转Token有效期（秒）= 1分钟
  };

  // Redis Key前缀
  static KEYS = {
    CAPTCHA: 'captcha:',           // 验证信息
    CAPTCHA_FAIL: 'captcha_fail:', // 失败记录
    CAPTCHA_BAN: 'captcha_ban:',   // IP封禁
    REDIRECT: 'redirect_token:',   // 跳转Token
  };

  /**
   * 检查人机验证是否启用
   * @returns {Promise<boolean>}
   */
  static async isEnabled() {
    try {
      const config = await Database.queryOne(
        'SELECT value FROM config_items WHERE category = ? AND key_name = ? AND is_active = 1',
        ['filter_settings', 'ENABLE_CAPTCHA']
      );
      
      if (config && config.value) {
        return config.value === 'true' || config.value === true;
      }
      
      // 默认启用
      return true;
    } catch (error) {
      logger.error('检查人机验证配置失败', { error: error.message });
      // 出错时默认启用，保守策略
      return true;
    }
  }

  /**
   * 检查IP是否被封禁
   * @param {string} ip - IP地址
   * @returns {Promise<Object>} { banned: boolean, remainingTime: number }
   */
  static async checkIPBan(ip) {
    try {
      const banKey = this.KEYS.CAPTCHA_BAN + ip;
      const banData = await Redis.get(banKey);
      
      if (banData) {
        const ttl = await Redis.ttl(banKey);
        return {
          banned: true,
          remainingTime: ttl > 0 ? ttl : 0
        };
      }
      
      return { banned: false, remainingTime: 0 };
    } catch (error) {
      logger.error('检查IP封禁状态失败', { error: error.message, ip });
      return { banned: false, remainingTime: 0 };
    }
  }

  /**
   * 生成验证数据
   * @param {string} token - 原始Token
   * @param {Object} tokenData - Token数据
   * @param {string} targetURL - 目标URL
   * @param {string} ip - 访问者IP
   * @returns {Promise<Object>} { captchaId, positions, imageData, securityCount }
   */
  static async generate(token, tokenData, targetURL, ip) {
    try {
      // 1. 生成唯一的验证ID
      const captchaId = crypto.randomBytes(16).toString('hex');
      
      // 2. 随机生成绿盾牌数量（1-5个）
      const securityCount = Math.floor(Math.random() * this.CONFIG.MAX_SECURITY) + this.CONFIG.MIN_SECURITY;
      
      // 3. 随机选择哪些位置放绿盾牌
      const allPositions = [0, 1, 2, 3, 4];
      const shuffled = this._shuffleArray([...allPositions]);
      const securityPositions = shuffled.slice(0, securityCount).sort((a, b) => a - b);
      
      // 4. 生成图片数据（用于前端显示）
      const imageData = [];
      for (let i = 0; i < this.CONFIG.TOTAL_IMAGES; i++) {
        const isSecurity = securityPositions.includes(i);
        imageData.push({
          index: i,
          type: isSecurity ? 'security' : 'decoy',
          // 不暴露具体类型给前端，只给随机ID
          imageId: crypto.randomBytes(4).toString('hex')
        });
      }
      
      // 5. 存储验证信息到Redis
      const captchaData = {
        positions: securityPositions,  // 正确答案（绿盾牌位置）
        token: token,
        tokenData: tokenData,
        targetURL: targetURL,
        ip: ip,
        attempts: 0,
        createdAt: Date.now()
      };
      
      const redisKey = this.KEYS.CAPTCHA + captchaId;
      await Redis.setWithExpiry(
        redisKey,
        JSON.stringify(captchaData),
        this.CONFIG.CAPTCHA_TTL
      );
      
      logger.info('生成人机验证', {
        captchaId: captchaId.substring(0, 8) + '...',
        securityCount,
        positions: securityPositions,
        ip
      });
      
      return {
        captchaId,
        positions: securityPositions,  // 仅用于后端，不传给前端
        imageData,
        securityCount
      };
      
    } catch (error) {
      logger.error('生成人机验证失败', { error: error.message, ip });
      throw error;
    }
  }

  /**
   * 验证用户点击
   * @param {string} captchaId - 验证ID
   * @param {number[]} clickedPositions - 用户点击的位置数组
   * @param {string} ip - 访问者IP
   * @returns {Promise<Object>} { success, redirectToken, error, remainingAttempts }
   */
  static async verify(captchaId, clickedPositions, ip) {
    try {
      // 1. 检查IP是否被封禁
      const banStatus = await this.checkIPBan(ip);
      if (banStatus.banned) {
        return {
          success: false,
          error: 'IP_BANNED',
          remainingTime: banStatus.remainingTime
        };
      }
      
      // 2. 获取验证数据
      const redisKey = this.KEYS.CAPTCHA + captchaId;
      const captchaDataStr = await Redis.get(redisKey);
      
      if (!captchaDataStr) {
        return {
          success: false,
          error: 'CAPTCHA_EXPIRED'
        };
      }
      
      const captchaData = JSON.parse(captchaDataStr);
      
      // 3. 验证IP匹配（防止验证ID被盗用）
      if (captchaData.ip !== ip) {
        logger.warn('验证IP不匹配', {
          captchaId: captchaId.substring(0, 8) + '...',
          originalIP: captchaData.ip,
          currentIP: ip
        });
        return {
          success: false,
          error: 'IP_MISMATCH'
        };
      }
      
      // 4. 检查尝试次数
      if (captchaData.attempts >= this.CONFIG.MAX_ATTEMPTS) {
        await this._banIP(ip);
        await Redis.del(redisKey);
        return {
          success: false,
          error: 'MAX_ATTEMPTS_EXCEEDED'
        };
      }
      
      // 5. 验证点击位置
      const correctPositions = captchaData.positions.sort((a, b) => a - b);
      const userPositions = [...clickedPositions].sort((a, b) => a - b);
      
      const isCorrect = 
        correctPositions.length === userPositions.length &&
        correctPositions.every((pos, idx) => pos === userPositions[idx]);
      
      if (isCorrect) {
        // 验证成功
        logger.info('人机验证成功', {
          captchaId: captchaId.substring(0, 8) + '...',
          ip
        });
        
        // 生成一次性跳转Token
        const redirectToken = await this._generateRedirectToken(captchaData.targetURL);
        
        // 删除验证数据
        await Redis.del(redisKey);
        
        // 清除失败记录
        await Redis.del(this.KEYS.CAPTCHA_FAIL + ip);
        
        return {
          success: true,
          redirectToken
        };
        
      } else {
        // 验证失败
        captchaData.attempts += 1;
        const remainingAttempts = this.CONFIG.MAX_ATTEMPTS - captchaData.attempts;
        
        logger.warn('人机验证失败', {
          captchaId: captchaId.substring(0, 8) + '...',
          ip,
          attempts: captchaData.attempts,
          correct: correctPositions,
          user: userPositions
        });
        
        if (captchaData.attempts >= this.CONFIG.MAX_ATTEMPTS) {
          // 达到最大尝试次数，封禁IP
          await this._banIP(ip);
          await Redis.del(redisKey);
          return {
            success: false,
            error: 'MAX_ATTEMPTS_EXCEEDED',
            remainingAttempts: 0
          };
        }
        
        // 更新尝试次数
        await Redis.setWithExpiry(
          redisKey,
          JSON.stringify(captchaData),
          this.CONFIG.CAPTCHA_TTL
        );
        
        return {
          success: false,
          error: 'INCORRECT',
          remainingAttempts
        };
      }
      
    } catch (error) {
      logger.error('验证人机验证失败', { error: error.message, captchaId });
      return {
        success: false,
        error: 'VERIFICATION_ERROR'
      };
    }
  }

  /**
   * 获取跳转目标URL
   * @param {string} redirectToken - 跳转Token
   * @returns {Promise<string|null>} 目标URL或null
   */
  static async getRedirectURL(redirectToken) {
    try {
      const redisKey = this.KEYS.REDIRECT + redirectToken;
      const targetURL = await Redis.get(redisKey);
      
      if (targetURL) {
        // 一次性使用，删除Token
        await Redis.del(redisKey);
        return targetURL;
      }
      
      return null;
    } catch (error) {
      logger.error('获取跳转URL失败', { error: error.message });
      return null;
    }
  }

  /**
   * 生成一次性跳转Token
   * @param {string} targetURL - 目标URL
   * @returns {Promise<string>} 跳转Token
   * @private
   */
  static async _generateRedirectToken(targetURL) {
    const redirectToken = crypto.randomBytes(16).toString('hex');
    const redisKey = this.KEYS.REDIRECT + redirectToken;
    
    await Redis.setWithExpiry(
      redisKey,
      targetURL,
      this.CONFIG.REDIRECT_TOKEN_TTL
    );
    
    return redirectToken;
  }

  /**
   * 封禁IP
   * @param {string} ip - IP地址
   * @private
   */
  static async _banIP(ip) {
    try {
      const banKey = this.KEYS.CAPTCHA_BAN + ip;
      await Redis.setWithExpiry(
        banKey,
        JSON.stringify({ bannedAt: Date.now() }),
        this.CONFIG.BAN_DURATION
      );
      
      logger.warn('IP已被封禁', { ip, duration: this.CONFIG.BAN_DURATION });
    } catch (error) {
      logger.error('封禁IP失败', { error: error.message, ip });
    }
  }

  /**
   * 数组随机打乱（Fisher-Yates算法）
   * @param {Array} array - 原数组
   * @returns {Array} 打乱后的数组
   * @private
   */
  static _shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
}

module.exports = CaptchaService;
