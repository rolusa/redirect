/**
 * ============================================
 * 人机验证路由 (Captcha Routes)
 * ============================================
 * 功能：
 * 1. POST /captcha/verify - 验证用户点击
 * 2. GET /captcha/go/:redirectToken - 跳转到目标URL
 * ============================================
 */

const express = require('express');
const router = express.Router();
const CaptchaService = require('../services/captchaService');
const logger = require('../utils/logger');
const { config } = require('../config');

/**
 * 生成友好的验证失败页面
 * @param {string} message - 错误信息
 * @param {number} remainingTime - 剩余封禁时间（秒）
 * @returns {string} HTML页面
 */
function generateErrorPage(message, remainingTime = 0) {
  const minutes = Math.ceil(remainingTime / 60);
  const timeMessage = remainingTime > 0 
    ? `<p class="time-info">約${minutes}分後に再試行してください。</p>` 
    : '';
  
  return `
    <!DOCTYPE html>
    <html lang="ja">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>セキュリティ確認 - エラー</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Hiragino Sans", "Hiragino Kaku Gothic ProN", "Yu Gothic", Meiryo, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 20px;
          padding: 50px 40px;
          max-width: 500px;
          width: 100%;
          text-align: center;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        .icon { font-size: 60px; margin-bottom: 20px; }
        h1 { font-size: 24px; color: #e74c3c; margin-bottom: 15px; }
        p { font-size: 16px; color: #666; line-height: 1.6; margin-bottom: 10px; }
        .time-info { font-size: 14px; color: #999; margin-top: 20px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="icon">⚠️</div>
        <h1>確認に失敗しました</h1>
        <p>${message}</p>
        ${timeMessage}
      </div>
    </body>
    </html>
  `;
}

/**
 * 验证用户点击
 * POST /captcha/verify
 * Body: { captchaId, clickedPositions }
 */
router.post('/verify', async (req, res) => {
  const ip = req.ip || req.connection.remoteAddress;
  
  try {
    const { captchaId, clickedPositions } = req.body;
    
    // 1. 参数验证
    if (!captchaId || !Array.isArray(clickedPositions)) {
      return res.status(400).json({
        success: false,
        error: 'INVALID_PARAMS',
        message: '無効なリクエストです'
      });
    }
    
    // 2. 验证点击位置格式
    const validPositions = clickedPositions.every(
      pos => Number.isInteger(pos) && pos >= 0 && pos <= 4
    );
    
    if (!validPositions) {
      return res.status(400).json({
        success: false,
        error: 'INVALID_POSITIONS',
        message: '無効な選択です'
      });
    }
    
    // 3. 执行验证
    const result = await CaptchaService.verify(captchaId, clickedPositions, ip);
    
    // 4. 返回结果
    if (result.success) {
      return res.json({
        success: true,
        redirectToken: result.redirectToken
      });
    }
    
    // 处理各种错误情况
    let message = '確認に失敗しました。もう一度お試しください。';
    let statusCode = 200;
    
    switch (result.error) {
      case 'IP_BANNED':
        message = 'アクセスが一時的に制限されています。';
        statusCode = 403;
        break;
      case 'CAPTCHA_EXPIRED':
        message = '確認の有効期限が切れました。ページを更新してください。';
        break;
      case 'IP_MISMATCH':
        message = 'セキュリティエラーが発生しました。';
        statusCode = 403;
        break;
      case 'MAX_ATTEMPTS_EXCEEDED':
        message = '試行回数の上限に達しました。しばらくしてから再試行してください。';
        statusCode = 403;
        break;
      case 'INCORRECT':
        message = `選択が正しくありません。残り${result.remainingAttempts}回試行できます。`;
        break;
    }
    
    return res.status(statusCode).json({
      success: false,
      error: result.error,
      message,
      remainingAttempts: result.remainingAttempts,
      remainingTime: result.remainingTime
    });
    
  } catch (error) {
    logger.error('验证接口错误', { error: error.message, ip });
    return res.status(500).json({
      success: false,
      error: 'SERVER_ERROR',
      message: 'サーバーエラーが発生しました'
    });
  }
});

/**
 * 跳转到目标URL
 * GET /captcha/go/:redirectToken
 */
router.get('/go/:redirectToken', async (req, res) => {
  const { redirectToken } = req.params;
  
  try {
    // 1. 验证Token格式（32位十六进制）
    if (!redirectToken || !/^[a-f0-9]{32}$/.test(redirectToken)) {
      logger.warn('无效的跳转Token格式', { token: redirectToken?.substring(0, 8) });
      return res.status(404).send(generateErrorPage('無効なリンクです。'));
    }
    
    // 2. 获取目标URL
    const targetURL = await CaptchaService.getRedirectURL(redirectToken);
    
    if (!targetURL) {
      logger.warn('跳转Token不存在或已过期', { token: redirectToken.substring(0, 8) });
      return res.status(404).send(generateErrorPage('リンクの有効期限が切れました。'));
    }
    
    // 3. 执行重定向
    logger.info('执行验证后跳转', {
      token: redirectToken.substring(0, 8) + '...',
      targetURL: targetURL.substring(0, 50) + '...'
    });
    
    return res.redirect(302, targetURL);
    
  } catch (error) {
    logger.error('跳转处理错误', { error: error.message });
    return res.status(500).send(generateErrorPage('サーバーエラーが発生しました。'));
  }
});

module.exports = router;
