/**
 * ============================================
 * Token批量生成 - API路由
 * ============================================
 * 功能：
 * 1. 批量生成Token链接
 * 2. 查询历史批次列表
 * 3. 查询批次详情
 * 4. 获取批次中的所有Token链接
 * 
 * ⚠️ 修改说明：
 * - 新URL格式：https://domain.com/B4G4FJDBYyLvP4Mj
 * - 旧URL格式：https://domain.com/?token=B4G4FJDBYyLvP4Mj（不再使用）
 * ============================================
 */

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const Database = require('../../database/mysql');
const TokenGenerator = require('../../utils/tokenGenerator');
const logger = require('../../utils/logger');
const { config } = require('../../config');

/**
 * 批量生成Token
 * POST /api/tokens/batch-generate
 * Body: {
 *   count: 100,           // 生成数量
 *   expiryHours: 720      // 有效期小时数
 * }
 */
router.post('/batch-generate', async (req, res) => {
  try {
    const { count, expiryHours, selectedDomains } = req.body; // ← 添加selectedDomains参数
    const username = req.user?.username || 'admin';

    logger.info('收到批量生成请求', { count, expiryHours, selectedDomains, username });

    // 1. 参数验证
    if (!count || count < 1) {
      logger.warn('参数验证失败：数量无效', { count });
      return res.status(400).json({
        success: false,
        error: 'Invalid count',
        message: '生成数量必须大于0'
      });
    }

    if (count > 10000) {
      logger.warn('参数验证失败：数量超限', { count });
      return res.status(400).json({
        success: false,
        error: 'Count exceeds limit',
        message: '单次生成数量不能超过10000条'
      });
    }

    if (!expiryHours || expiryHours < 1) {
      logger.warn('参数验证失败：有效期无效', { expiryHours });
      return res.status(400).json({
        success: false,
        error: 'Invalid expiry hours',
        message: '有效期必须大于0小时'
      });
    }

    // ✅ 新增：验证域名参数
    if (!selectedDomains || !Array.isArray(selectedDomains) || selectedDomains.length === 0) {
      logger.warn('参数验证失败：未选择域名', { selectedDomains });
      return res.status(400).json({
        success: false,
        error: 'No domains selected',
        message: '请至少选择一个域名用于生成链接'
      });
    }
    
    logger.info('使用的域名列表', { 
      domains: selectedDomains, 
      count: selectedDomains.length 
    });

    // 2. 检查今日生成数量限制
    let todayCount;
    try {
      todayCount = await Database.queryOne(
        `SELECT COALESCE(SUM(token_count), 0) as total 
         FROM token_batches 
         WHERE DATE(created_at) = CURDATE() AND created_by = ?`,
        [username]
      );
      logger.info('今日已生成数量', { total: todayCount.total, username });
    } catch (error) {
      logger.error('查询今日生成数量失败', { error: error.message });
      // 如果查询失败，继续执行（可能是表不存在）
      todayCount = { total: 0 };
    }

    // ✅ 确保类型转换为数字
    const currentTotal = parseInt(todayCount.total) || 0;
    const requestCount = parseInt(count) || 0;
    
    logger.info('限额检查', { 
      currentTotal, 
      requestCount, 
      sum: currentTotal + requestCount,
      limit: 5000000,
      willExceed: (currentTotal + requestCount) > 5000000
    });

    if (currentTotal + requestCount > 5000000) {
      return res.status(400).json({
        success: false,
        error: 'Daily limit exceeded',
        message: `今日生成数量已达限制(${currentTotal}/5000000)，无法再生成${requestCount}条`
      });
    }

    // 3. 生成批次ID
    const batchId = `batch-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
    logger.info('生成批次ID', { batchId });

    // 4. 准备域名列表用于轮换
    const domainsList = selectedDomains; // 前端传来的选中域名列表
    logger.info('使用域名列表生成链接', { 
      domainCount: domainsList.length,
      domains: domainsList
    });

    // 5. 计算过期时间
    const expiresAt = new Date(Date.now() + expiryHours * 60 * 60 * 1000);

    logger.info('开始批量生成Token', {
      batchId,
      count,
      expiryHours,
      domainCount: domainsList.length,
      expiresAt: expiresAt.toISOString()
    });

    // 6. 批量生成Token
    const tokens = [];
    const errors = [];
    const batchSize = 50; // 减小批次大小，更容易调试
    
    for (let i = 0; i < count; i += batchSize) {
      const currentBatch = Math.min(batchSize, count - i);
      const batchPromises = [];

      for (let j = 0; j < currentBatch; j++) {
        const promise = (async () => {
          try {
            // 生成Token
            const emailId = `batch-${batchId}-${i + j + 1}`;
            
            logger.debug('生成Token', { emailId, index: i + j + 1 });
            
            const tokenResult = await TokenGenerator.generate({
              emailId: emailId,
              recipientEmail: null
            });

            if (!tokenResult || !tokenResult.token) {
              throw new Error('TokenGenerator返回了空结果');
            }

            // ✅ 使用域名轮换生成链接
            // 计算当前Token应该使用哪个域名（轮换算法）
            const domainIndex = (i + j) % domainsList.length;
            const selectedDomain = domainsList[domainIndex];
            
            // ✅ 修改：新URL格式 - 使用路径参数而非查询参数
            // 旧格式: https://domain.com/?token=B4G4FJDBYyLvP4Mj
            // 新格式: https://domain.com/B4G4FJDBYyLvP4Mj
            const trackingLink = `https://${selectedDomain}/${tokenResult.token}`;

            // 计算Token哈希
            const tokenHash = crypto
              .createHash('sha256')
              .update(tokenResult.token)
              .digest('hex')
              .substring(0, 16);

            logger.debug('Token生成成功', { 
              emailId, 
              token: tokenResult.token.substring(0, 4) + '****',
              link: trackingLink,
              domain: selectedDomain,
              domainIndex
            });

            return {
              token: tokenResult.token,
              tokenHash: tokenHash,
              trackingLink: trackingLink,
              emailId: emailId,
              expiresAt: tokenResult.expiresAt
            };
          } catch (error) {
            logger.error('生成单个Token失败', {
              index: i + j + 1,
              error: error.message,
              stack: error.stack
            });
            errors.push({
              index: i + j + 1,
              error: error.message
            });
            return null;
          }
        })();

        batchPromises.push(promise);
      }

      // 等待当前批次完成
      const results = await Promise.all(batchPromises);
      const successResults = results.filter(t => t !== null);
      tokens.push(...successResults);

      // 记录进度
      logger.info('批量生成进度', {
        batchId,
        progress: `${tokens.length}/${count}`,
        currentBatchSuccess: successResults.length,
        currentBatchTotal: currentBatch
      });
    }

    logger.info('批量生成完成', {
      batchId,
      requested: count,
      success: tokens.length,
      failed: count - tokens.length,
      errorCount: errors.length
    });

    // 如果一个都没生成成功，返回详细错误
    if (tokens.length === 0) {
      logger.error('批量生成全部失败', { errors });
      return res.status(500).json({
        success: false,
        error: 'All tokens failed to generate',
        message: '所有Token生成失败，请检查Redis是否运行',
        details: errors.slice(0, 5), // 只返回前5个错误
        total: count,
        generated: 0,
        failed: count
      });
    }

    // 7. 保存批次信息到数据库
    try {
      // 将使用的域名列表保存为逗号分隔的字符串
      const domainsString = domainsList.join(',');
      
      await Database.query(
        `INSERT INTO token_batches 
         (batch_id, token_count, base_url, expiry_hours, expires_at, created_by) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [batchId, tokens.length, domainsString, expiryHours, expiresAt, username]
      );
      logger.info('批次信息已保存到数据库', { batchId, domains: domainsString });
    } catch (error) {
      logger.error('保存批次信息失败', { error: error.message, batchId });
      // 继续执行，不阻断流程
    }

    // 8. 批量保存Token明细
    if (tokens.length > 0) {
      try {
        const values = tokens.map(t => [
          batchId,
          t.token,
          t.tokenHash,
          t.trackingLink,
          t.emailId,
          expiresAt
        ]);

        // 构建批量插入SQL
        const placeholders = values.map(() => '(?, ?, ?, ?, ?, ?)').join(',');
        const flatValues = values.flat();

        await Database.query(
          `INSERT INTO token_batch_items 
           (batch_id, token, token_hash, tracking_link, email_id, expires_at) 
           VALUES ${placeholders}`,
          flatValues
        );
        logger.info('Token明细已保存到数据库', { count: tokens.length });
      } catch (error) {
        logger.error('保存Token明细失败', { error: error.message });
        // 继续执行，不阻断流程
      }
    }

    // 9. 返回结果
    res.json({
      success: true,
      batchId: batchId,
      total: count,
      generated: tokens.length,
      failed: count - tokens.length,
      links: tokens.map(t => t.trackingLink),
      expiresAt: expiresAt.toISOString(),
      createdAt: new Date().toISOString()
    });

  } catch (error) {
    logger.error('批量生成Token失败（顶层异常）', {
      error: error.message,
      stack: error.stack
    });

    res.status(500).json({
      success: false,
      error: 'Generation failed',
      message: error.message
    });
  }
});

/**
 * 获取批次列表
 * GET /api/tokens/batches?page=1&limit=10
 */
router.get('/batches', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const username = req.user?.username || 'admin';

    // 查询总数
    const countResult = await Database.queryOne(
      'SELECT COUNT(*) as total FROM token_batches WHERE created_by = ?',
      [username]
    );

    // 查询批次列表
    const batches = await Database.query(
      `SELECT 
        batch_id,
        token_count,
        base_url,
        expiry_hours,
        expires_at,
        created_at,
        created_by
       FROM token_batches 
       WHERE created_by = ?
       ORDER BY created_at DESC 
       LIMIT ? OFFSET ?`,
      [username, limit, offset]
    );

    res.json({
      success: true,
      data: batches,
      pagination: {
        page: page,
        limit: limit,
        total: countResult.total,
        totalPages: Math.ceil(countResult.total / limit)
      }
    });

  } catch (error) {
    logger.error('查询批次列表失败', { error: error.message });
    res.status(500).json({
      success: false,
      error: 'Query failed',
      message: error.message
    });
  }
});

/**
 * 获取批次详情（包含所有Token）
 * GET /api/tokens/batches/:batchId
 */
router.get('/batches/:batchId', async (req, res) => {
  try {
    const { batchId } = req.params;
    const username = req.user?.username || 'admin';

    // 查询批次信息
    const batch = await Database.queryOne(
      `SELECT * FROM token_batches 
       WHERE batch_id = ? AND created_by = ?`,
      [batchId, username]
    );

    if (!batch) {
      return res.status(404).json({
        success: false,
        error: 'Batch not found',
        message: '批次不存在'
      });
    }

    // 查询该批次的所有Token
    const tokens = await Database.query(
      `SELECT 
        token,
        tracking_link,
        email_id,
        created_at,
        expires_at,
        is_used,
        use_count
       FROM token_batch_items 
       WHERE batch_id = ?
       ORDER BY id ASC`,
      [batchId]
    );

    res.json({
      success: true,
      batch: batch,
      tokens: tokens,
      links: tokens.map(t => t.tracking_link)
    });

  } catch (error) {
    logger.error('查询批次详情失败', { error: error.message });
    res.status(500).json({
      success: false,
      error: 'Query failed',
      message: error.message
    });
  }
});

/**
 * 删除批次
 * DELETE /api/tokens/batches/:batchId
 */
router.delete('/batches/:batchId', async (req, res) => {
  try {
    const { batchId } = req.params;
    const username = req.user?.username || 'admin';

    // 检查批次是否存在
    const batch = await Database.queryOne(
      'SELECT * FROM token_batches WHERE batch_id = ? AND created_by = ?',
      [batchId, username]
    );

    if (!batch) {
      return res.status(404).json({
        success: false,
        error: 'Batch not found',
        message: '批次不存在'
      });
    }

    // 删除批次（会级联删除明细）
    await Database.query(
      'DELETE FROM token_batches WHERE batch_id = ?',
      [batchId]
    );

    logger.info('删除批次', { batchId, username });

    res.json({
      success: true,
      message: '批次已删除'
    });

  } catch (error) {
    logger.error('删除批次失败', { error: error.message });
    res.status(500).json({
      success: false,
      error: 'Delete failed',
      message: error.message
    });
  }
});

/**
 * 获取统计信息
 * GET /api/tokens/stats
 */
router.get('/stats', async (req, res) => {
  try {
    const username = req.user?.username || 'admin';

    // 今日生成统计
    const todayStats = await Database.queryOne(
      `SELECT 
        COUNT(*) as batch_count,
        COALESCE(SUM(token_count), 0) as token_count
       FROM token_batches 
       WHERE DATE(created_at) = CURDATE() AND created_by = ?`,
      [username]
    );

    // 总计统计
    const totalStats = await Database.queryOne(
      `SELECT 
        COUNT(*) as batch_count,
        COALESCE(SUM(token_count), 0) as token_count
       FROM token_batches 
       WHERE created_by = ?`,
      [username]
    );

    // ✅ 确保类型转换为数字
    const todayTokenCount = parseInt(todayStats.token_count) || 0;
    const totalTokenCount = parseInt(totalStats.token_count) || 0;

    res.json({
      success: true,
      today: {
        batches: parseInt(todayStats.batch_count) || 0,
        tokens: todayTokenCount,
        remaining: 5000000 - todayTokenCount
      },
      total: {
        batches: parseInt(totalStats.batch_count) || 0,
        tokens: totalTokenCount
      }
    });

  } catch (error) {
    logger.error('查询统计信息失败', { error: error.message });
    res.status(500).json({
      success: false,
      error: 'Query failed',
      message: error.message
    });
  }
});

module.exports = router;
