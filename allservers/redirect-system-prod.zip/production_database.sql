-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: redirect_system_prod
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.22.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `redirect_system_prod`
--

/*!40000 DROP DATABASE IF EXISTS `redirect_system_prod`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `redirect_system_prod` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `redirect_system_prod`;

--
-- Table structure for table `access_logs`
--

DROP TABLE IF EXISTS `access_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `token_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_code` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `browser` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os_version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_vpn` tinyint(1) DEFAULT '0',
  `is_proxy` tinyint(1) DEFAULT '0',
  `is_tor` tinyint(1) DEFAULT '0',
  `is_threat` tinyint(1) DEFAULT '0',
  `filter_decision` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `filter_results` json DEFAULT NULL,
  `rejection_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect_to` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect_domain` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `process_time_ms` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_token_hash` (`token_hash`) USING BTREE,
  KEY `idx_ip` (`ip`) USING BTREE,
  KEY `idx_created_at` (`created_at`) USING BTREE,
  KEY `idx_decision` (`filter_decision`) USING BTREE,
  KEY `idx_country` (`country_code`) USING BTREE,
  KEY `idx_email_id` (`email_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_logs`
--

LOCK TABLES `access_logs` WRITE;
/*!40000 ALTER TABLE `access_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_logs`
--

DROP TABLE IF EXISTS `admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型',
  `resource` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作资源',
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '详细信息',
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'success' COMMENT 'success,failed',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_username` (`username`) USING BTREE,
  KEY `idx_action` (`action`) USING BTREE,
  KEY `idx_created_at` (`created_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_logs`
--

LOCK TABLES `admin_logs` WRITE;
/*!40000 ALTER TABLE `admin_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_operation_logs`
--

DROP TABLE IF EXISTS `admin_operation_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_operation_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作人',
  `operation_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型',
  `operation_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '操作描述',
  `operation_data` json DEFAULT NULL COMMENT '操作数据',
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IP地址',
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'User-Agent',
  `status` enum('success','failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'success' COMMENT '操作状态',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '错误信息',
  `execution_time` int DEFAULT NULL COMMENT '执行时间(ms)',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_operator` (`operator`) USING BTREE,
  KEY `idx_operation_type` (`operation_type`) USING BTREE,
  KEY `idx_created_at` (`created_at`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='管理员操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_operation_logs`
--

LOCK TABLES `admin_operation_logs` WRITE;
/*!40000 ALTER TABLE `admin_operation_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_operation_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '是否激活',
  `last_login_at` timestamp NULL DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '最后登录IP',
  `login_attempts` int DEFAULT '0' COMMENT '登录失败次数',
  `locked_until` timestamp NULL DEFAULT NULL COMMENT '锁定到期时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE,
  KEY `idx_username` (`username`) USING BTREE,
  KEY `idx_last_login` (`last_login_at`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='管理员用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2a$10$Xjp88/j25Uc7amOMY9v9/eH9RjMrLVIa19JpVZbQR7guaX5M7ypw6',NULL,1,'2025-11-19 10:17:29','127.0.0.1',0,NULL,'2025-11-14 19:13:57','2025-11-19 10:17:29');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_history`
--

DROP TABLE IF EXISTS `config_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` int NOT NULL COMMENT '版本号',
  `config_snapshot` json NOT NULL COMMENT '配置快照',
  `changes` json DEFAULT NULL COMMENT '变更详情',
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人',
  `operation_type` enum('update','rollback','import','template') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'update' COMMENT '操作类型',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_version` (`version`) USING BTREE,
  KEY `idx_operator` (`operator`) USING BTREE,
  KEY `idx_created_at` (`created_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='配置历史表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_history`
--

LOCK TABLES `config_history` WRITE;
/*!40000 ALTER TABLE `config_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_items`
--

DROP TABLE IF EXISTS `config_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置分类',
  `key_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置键名',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  `data_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'string' COMMENT '数据类型: string,number,boolean,json',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '配置说明',
  `is_sensitive` tinyint(1) DEFAULT '0' COMMENT '是否敏感信息',
  `is_active` tinyint(1) DEFAULT '1',
  `updated_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique_config` (`category`,`key_name`) USING BTREE,
  KEY `idx_category` (`category`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_items`
--

LOCK TABLES `config_items` WRITE;
/*!40000 ALTER TABLE `config_items` DISABLE KEYS */;
INSERT INTO `config_items` VALUES (1,'server','NODE_ENV','production','string','运行环境',0,1,'admin','2025-11-18 20:06:16','2025-11-14 20:41:36'),(2,'server','PORT','3000','number','服务端口',0,1,'admin','2025-11-16 14:06:54','2025-11-14 20:41:36'),(3,'server','HOST','127.0.0.1','string','监听地址',0,1,'admin','2025-11-18 19:07:31','2025-11-14 20:41:36'),(4,'database','DB_HOST','127.0.0.1','string','MySQL主机',0,1,'admin','2025-11-18 19:06:51','2025-11-14 20:41:36'),(5,'database','DB_PORT','3306','number','MySQL端口',0,1,'admin','2025-11-16 15:28:36','2025-11-14 20:41:36'),(6,'database','DB_NAME','redirect_system_prod','string','数据库名',0,1,'admin','2025-11-18 19:58:04','2025-11-14 20:41:36'),(7,'database','DB_USER','redirect_user','string','数据库用户',0,1,'admin','2025-11-18 20:03:49','2025-11-14 20:41:36'),(8,'database','DB_PASSWORD','Hell0@MaiDong','string','数据库密码',1,1,'admin','2025-11-16 15:15:20','2025-11-14 20:41:36'),(9,'redis','REDIS_HOST','127.0.0.1','string','Redis主机',0,1,'admin','2025-11-16 14:42:32','2025-11-14 20:41:36'),(10,'redis','REDIS_PORT','6379','number','Redis端口',0,1,'admin','2025-11-16 18:54:14','2025-11-14 20:41:36'),(11,'redis','REDIS_PASSWORD','','string','Redis密码',1,1,'admin','2025-11-16 14:54:35','2025-11-14 20:41:36'),(12,'redis','REDIS_DB','0','number','Redis数据库编号',0,1,'admin','2025-11-16 14:42:36','2025-11-14 20:41:36'),(13,'token','TOKEN_SECRET_KEY','wm2SIJJVpce8eCAfejRXiRgeccFFyXbV','string','Token加密密钥',1,1,'admin','2025-11-16 14:28:54','2025-11-14 20:41:36'),(14,'token','TOKEN_EXPIRY_HOURS','7200','number','Token有效期(小时)',0,1,'admin','2025-11-16 14:47:04','2025-11-14 20:41:36'),(15,'token','TOKEN_MAX_USES','5000000','number','Token最大使用次数',0,1,'admin','2025-11-16 14:07:01','2025-11-14 20:41:36'),(16,'domains','TARGET_URL','https://www.google.com\nhttps://www.facebook.com\nhttps://www.amazon.com\nhttps://www.netflix.com','string','目标URL',0,1,'admin','2025-11-17 16:36:23','2025-11-14 20:41:36'),(17,'domains','FALLBACK_URL_LIGHT','https://www.a.com','string','轻度拒绝URL',0,1,'admin','2025-11-17 13:25:06','2025-11-14 20:41:36'),(18,'domains','FALLBACK_URL_MEDIUM','https://www.b.com','string','中度拒绝URL',0,1,'admin','2025-11-16 18:47:04','2025-11-14 20:41:36'),(19,'domains','FALLBACK_URL_HEAVY','https://www.c.com','string','重度拒绝URL',0,1,'admin','2025-11-16 18:47:05','2025-11-14 20:41:36'),(27,'geo','ALLOWED_COUNTRIES','JP','string','允许的国家列表',0,1,'admin','2025-11-19 16:52:22','2025-11-14 20:41:36'),(29,'language','ALLOWED_LANGUAGES','ja,ja-JP','string','允许的语言列表（逗号分隔）',0,1,'admin','2025-11-19 16:52:22','2025-11-16 12:39:11'),(30,'api','IPREGISTRY_API_KEY','ira_bbCYlp07fQkjDgDIJqtbO12D88M0rg3UEcvf','string','IPRegistry API密钥，用于IP地理位置查询',1,1,'admin','2025-11-16 20:55:43','2025-11-16 13:05:42'),(31,'domains','REDIRECT_DOMAINS','google.com','string','重定向域名列表',0,1,'admin','2025-11-16 21:18:29','2025-11-16 17:35:06'),(32,'filter_settings','FILTER_MODE','strict','string','过滤器模式',0,1,NULL,'2025-11-19 14:42:11','2025-11-19 11:24:55'),(33,'filter_settings','ENABLE_TOKEN_FILTER','true','boolean','Token验证',0,1,'admin','2025-11-19 18:02:46','2025-11-19 11:24:55'),(34,'filter_settings','ENABLE_SECURITY_FILTER','true','boolean','安全过滤',0,1,'admin','2025-11-19 18:02:46','2025-11-19 11:24:55'),(35,'filter_settings','ENABLE_GEO_FILTER','true','boolean','地理过滤',0,1,'admin','2025-11-19 18:02:46','2025-11-19 11:24:55'),(36,'filter_settings','ENABLE_DEVICE_FILTER','true','boolean','设备过滤',0,1,'admin','2025-11-19 18:02:46','2025-11-19 11:24:55'),(37,'filter_settings','ENABLE_BEHAVIOR_FILTER','true','boolean','行为过滤',0,1,'admin','2025-11-19 18:02:46','2025-11-19 11:24:55'),(38,'filter_settings','ENABLE_FINGERPRINT_FILTER','true','boolean','指纹过滤',0,1,'admin','2025-11-19 18:02:46','2025-11-19 11:24:55'),(39,'geo','GEO_MODE','whitelist','string','地理位置模式：whitelist或blacklist',0,1,NULL,'2025-11-19 12:18:32','2025-11-19 12:18:32'),(40,'geo','BLOCKED_COUNTRIES','','string','地理位置黑名单国家（逗号分隔）',0,1,NULL,'2025-11-19 12:18:32','2025-11-19 12:18:32'),(41,'security','BLOCK_VPN','true','boolean','是否阻止VPN',0,1,NULL,'2025-11-19 14:42:11','2025-11-19 14:42:11'),(42,'security','BLOCK_PROXY','true','boolean','是否阻止代理',0,1,NULL,'2025-11-19 14:42:11','2025-11-19 14:42:11'),(43,'security','BLOCK_TOR','true','boolean','是否阻止Tor',0,1,NULL,'2025-11-19 14:42:11','2025-11-19 14:42:11'),(44,'security','BLOCK_CLOUD_PROVIDER','false','boolean','是否阻止云服务商',0,1,NULL,'2025-11-19 14:42:11','2025-11-19 14:42:11'),(48,'language','BLOCKED_LANGUAGES','','string','阻止的语言代码（逗号分隔）',0,1,NULL,'2025-11-19 14:42:11','2025-11-19 14:42:11'),(49,'language','LANGUAGE_MODE','whitelist','string','模式：whitelist或blacklist',0,1,NULL,'2025-11-19 14:42:11','2025-11-19 14:42:11'),(51,'filter_settings','ENABLE_LANGUAGE_FILTER','true','boolean','语言检测过滤器',0,1,'admin','2025-11-19 18:02:46','2025-11-19 14:42:11'),(59,'fingerprint','FINGERPRINT_THRESHOLD','50','integer','可疑分数阈值',0,1,NULL,'2025-11-19 15:52:57','2025-11-19 15:52:57'),(60,'fingerprint','CHECK_AUTOMATION','true','boolean','检测自动化工具',0,1,NULL,'2025-11-19 15:52:57','2025-11-19 15:52:57'),(61,'fingerprint','CHECK_HEADLESS','true','boolean','检测Headless浏览器',0,1,NULL,'2025-11-19 15:52:57','2025-11-19 15:52:57'),(62,'fingerprint','CHECK_BOTS','true','boolean','检测爬虫机器人',0,1,NULL,'2025-11-19 15:52:57','2025-11-19 15:52:57');
/*!40000 ALTER TABLE `config_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_snapshots`
--

DROP TABLE IF EXISTS `config_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_snapshots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '快照名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '快照描述',
  `config_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置JSON数据',
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_created_at` (`created_at`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_snapshots`
--

LOCK TABLES `config_snapshots` WRITE;
/*!40000 ALTER TABLE `config_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_templates`
--

DROP TABLE IF EXISTS `config_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',
  `template_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '模板描述',
  `template_data` json NOT NULL COMMENT '模板数据',
  `template_type` enum('security','performance','custom') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'custom' COMMENT '模板类型',
  `is_builtin` tinyint(1) DEFAULT '0' COMMENT '是否内置模板',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '是否激活',
  `usage_count` int DEFAULT '0' COMMENT '使用次数',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `template_name` (`template_name`) USING BTREE,
  KEY `idx_template_type` (`template_type`) USING BTREE,
  KEY `idx_is_builtin` (`is_builtin`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='配置模板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_templates`
--

LOCK TABLES `config_templates` WRITE;
/*!40000 ALTER TABLE `config_templates` DISABLE KEYS */;
INSERT INTO `config_templates` VALUES (1,'高安全模式','最严格的过滤规则，适合高价值链接保护','{\"geo\": {\"allowedCountries\": [\"JP\"]}, \"filters\": {\"geo\": true, \"token\": true, \"device\": true, \"behavior\": true, \"language\": true, \"security\": true, \"fingerprint\": true}, \"language\": {\"allowedLanguages\": [\"ja\", \"ja-JP\"]}, \"rateLimit\": {\"1min\": {\"max\": 1, \"window\": 60}, \"1hour\": {\"max\": 3, \"window\": 3600}, \"24hour\": {\"max\": 5, \"window\": 86400}}}','security',1,1,0,'2025-11-14 19:12:35','2025-11-14 19:12:35'),(2,'平衡模式','平衡安全性和通过率，适合大多数场景','{\"geo\": {\"allowedCountries\": [\"JP\", \"CN\", \"US\"]}, \"filters\": {\"geo\": true, \"token\": true, \"device\": true, \"behavior\": true, \"language\": false, \"security\": true, \"fingerprint\": false}, \"rateLimit\": {\"1min\": {\"max\": 3, \"window\": 60}, \"1hour\": {\"max\": 10, \"window\": 3600}, \"24hour\": {\"max\": 20, \"window\": 86400}}}','security',1,1,0,'2025-11-14 19:12:35','2025-11-14 19:12:35'),(11,'宽松模式','较低的过滤强度，追求高通过率','{\"filters\": {\"geo\": false, \"token\": true, \"device\": false, \"behavior\": true, \"language\": false, \"security\": true, \"fingerprint\": false}, \"rateLimit\": {\"1min\": {\"max\": 10, \"window\": 60}, \"1hour\": {\"max\": 50, \"window\": 3600}, \"24hour\": {\"max\": 100, \"window\": 86400}}}','performance',1,1,0,'2025-11-14 19:12:35','2025-11-14 19:12:35');
/*!40000 ALTER TABLE `config_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_reputation`
--

DROP TABLE IF EXISTS `ip_reputation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_reputation` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reputation_score` int DEFAULT '50',
  `total_visits` int unsigned DEFAULT '0',
  `successful_visits` int unsigned DEFAULT '0',
  `rejected_visits` int unsigned DEFAULT '0',
  `last_visit_at` timestamp NULL DEFAULT NULL,
  `first_visit_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_whitelisted` tinyint(1) DEFAULT '0',
  `is_blacklisted` tinyint(1) DEFAULT '0',
  `blacklist_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklist_expires_at` timestamp NULL DEFAULT NULL,
  `country_code` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ip` (`ip`) USING BTREE,
  KEY `idx_ip` (`ip`) USING BTREE,
  KEY `idx_reputation` (`reputation_score`) USING BTREE,
  KEY `idx_blacklisted` (`is_blacklisted`) USING BTREE,
  KEY `idx_whitelisted` (`is_whitelisted`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_reputation`
--

LOCK TABLES `ip_reputation` WRITE;
/*!40000 ALTER TABLE `ip_reputation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_reputation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redirect_domains`
--

DROP TABLE IF EXISTS `redirect_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_domains` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '域名',
  `domain_type` enum('main','wildcard') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'main' COMMENT '域名类型: main=主域名, wildcard=通配符',
  `ssl_enabled` tinyint(1) DEFAULT '0' COMMENT '是否启用SSL',
  `ssl_provider` enum('letsencrypt','cloudflare','manual') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'letsencrypt' COMMENT 'SSL提供商',
  `ssl_issued_date` datetime DEFAULT NULL COMMENT 'SSL签发时间',
  `ssl_expiry_date` datetime DEFAULT NULL COMMENT 'SSL过期时间',
  `days_left` int DEFAULT NULL COMMENT '剩余天数',
  `cert_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '证书路径',
  `key_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '私钥路径',
  `nginx_config_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Nginx配置文件路径',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '是否激活',
  `use_for_links` tinyint(1) DEFAULT '1' COMMENT '是否用于生成链接',
  `is_cloudflare` tinyint(1) DEFAULT '0' COMMENT '是否使用CloudFlare',
  `cloudflare_zone_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'CloudFlare Zone ID',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '备注',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `domain_name` (`domain_name`) USING BTREE,
  KEY `idx_domain_name` (`domain_name`) USING BTREE,
  KEY `idx_is_active` (`is_active`) USING BTREE,
  KEY `idx_ssl_expiry` (`ssl_expiry_date`) USING BTREE,
  KEY `idx_use_for_links` (`use_for_links`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='重定向域名管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redirect_domains`
--

LOCK TABLES `redirect_domains` WRITE;
/*!40000 ALTER TABLE `redirect_domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `redirect_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statistics`
--

DROP TABLE IF EXISTS `statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `statistics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stat_hour` timestamp NOT NULL,
  `total_requests` int unsigned DEFAULT '0',
  `successful_requests` int unsigned DEFAULT '0',
  `rejected_requests` int unsigned DEFAULT '0',
  `rejection_rate` decimal(5,2) DEFAULT NULL,
  `unique_ips` int unsigned DEFAULT '0',
  `unique_tokens` int unsigned DEFAULT '0',
  `avg_process_time_ms` int unsigned DEFAULT NULL,
  `top_countries` json DEFAULT NULL,
  `top_rejection_reasons` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique_stat_hour` (`stat_hour`) USING BTREE,
  KEY `idx_stat_hour` (`stat_hour`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistics`
--

LOCK TABLES `statistics` WRITE;
/*!40000 ALTER TABLE `statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_configs`
--

DROP TABLE IF EXISTS `system_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置键',
  `config_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置值',
  `config_type` enum('string','number','boolean','json','array') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'string' COMMENT '配置类型',
  `config_group` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置分组',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '配置描述',
  `default_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '默认值',
  `is_required` tinyint(1) DEFAULT '0' COMMENT '是否必需',
  `is_sensitive` tinyint(1) DEFAULT '0' COMMENT '是否敏感信息',
  `validation_rule` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '验证规则',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `updated_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `config_key` (`config_key`) USING BTREE,
  KEY `idx_config_group` (`config_group`) USING BTREE,
  KEY `idx_updated_at` (`updated_at`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_configs`
--

LOCK TABLES `system_configs` WRITE;
/*!40000 ALTER TABLE `system_configs` DISABLE KEYS */;
INSERT INTO `system_configs` VALUES (1,'server.port','3000','string','server',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(2,'database.host','127.0.0.1','string','database',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(3,'database.port','3306','string','database',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(4,'database.name','redirect_system_dev','string','database',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(5,'database.user','redirect_user','string','database',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(6,'database.password','Hell0@MaiDong','string','database',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(7,'redis.host','127.0.0.1','string','redis',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(8,'redis.port','6379','string','redis',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(9,'redis.db','0','string','redis',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(10,'token.secretKey','2f6835361d0f64a2aaa07581b2224cec','string','token',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(11,'token.expiryHours','720','string','token',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(12,'token.maxUses','5000000','string','token',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(13,'ipregistry.apiKey','ira_zbwzRqtBDJ4V16RCqAujZEkW5pfhj11qdEo8','string','ipregistry',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(14,'ipregistry.timeout','5000','string','ipregistry',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(15,'domains.targetURL','https://claude.ai/chats','string','domains',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(16,'domains.redirectDomains','[\"b.com\",\"c.com\",\"d.com\",\"e.com\",\"f.com\"]','string','domains',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(17,'domains.fallback','{\"light\":\"https://www.youtube.com/\",\"medium\":\"https://ipinfo.io/\",\"heavy\":\"https://x.com/\"}','string','domains',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(18,'logging.level','info','string','logging',NULL,NULL,0,0,NULL,'2025-11-14 19:45:16','admin'),(82,'redis.password','','string','redis',NULL,NULL,0,0,NULL,'2025-11-14 19:53:33','admin'),(130,'filters.token','true','string','filters',NULL,NULL,0,0,NULL,'2025-11-14 20:10:18','admin'),(131,'filters.security','true','string','filters',NULL,NULL,0,0,NULL,'2025-11-14 20:10:18','admin'),(132,'filters.geo','true','string','filters',NULL,NULL,0,0,NULL,'2025-11-14 20:14:43','admin'),(133,'filters.language','true','string','filters',NULL,NULL,0,0,NULL,'2025-11-14 20:14:48','admin'),(134,'filters.device','true','string','filters',NULL,NULL,0,0,NULL,'2025-11-14 20:14:43','admin'),(135,'filters.behavior','true','string','filters',NULL,NULL,0,0,NULL,'2025-11-14 20:10:18','admin'),(136,'geo.allowedCountries','[]','string','geo',NULL,NULL,0,0,NULL,'2025-11-14 20:10:18','admin'),(137,'language.allowedLanguages','[]','string','language',NULL,NULL,0,0,NULL,'2025-11-14 20:10:18','admin'),(138,'rateLimit.1min','{\"window\":60,\"max\":1}','string','rateLimit',NULL,NULL,0,0,NULL,'2025-11-14 20:15:03','admin'),(139,'rateLimit.1hour','{\"window\":3600,\"max\":3}','string','rateLimit',NULL,NULL,0,0,NULL,'2025-11-14 20:15:03','admin'),(140,'rateLimit.24hour','{\"window\":86400,\"max\":5}','string','rateLimit',NULL,NULL,0,0,NULL,'2025-11-14 20:15:03','admin');
/*!40000 ALTER TABLE `system_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_monitor_stats`
--

DROP TABLE IF EXISTS `system_monitor_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_monitor_stats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stat_date` date NOT NULL COMMENT '统计日期',
  `stat_hour` tinyint NOT NULL COMMENT '统计小时',
  `total_requests` int DEFAULT '0' COMMENT '总请求数',
  `successful_requests` int DEFAULT '0' COMMENT '成功请求数',
  `failed_requests` int DEFAULT '0' COMMENT '失败请求数',
  `blocked_requests` int DEFAULT '0' COMMENT '拦截请求数',
  `unique_ips` int DEFAULT '0' COMMENT '独立IP数',
  `avg_process_time` int DEFAULT '0' COMMENT '平均处理时间(ms)',
  `top_countries` json DEFAULT NULL COMMENT 'Top国家统计',
  `top_rejection_reasons` json DEFAULT NULL COMMENT 'Top拒绝原因',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_date_hour` (`stat_date`,`stat_hour`) USING BTREE,
  KEY `idx_stat_date` (`stat_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='系统监控统计表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_monitor_stats`
--

LOCK TABLES `system_monitor_stats` WRITE;
/*!40000 ALTER TABLE `system_monitor_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_monitor_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_batch_items`
--

DROP TABLE IF EXISTS `token_batch_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_batch_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '批次ID',
  `token` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '16位Token',
  `token_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Token SHA256哈希值',
  `tracking_link` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '完整跟踪链接',
  `email_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '邮件ID',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `expires_at` timestamp NOT NULL COMMENT '过期时间',
  `is_used` tinyint(1) DEFAULT '0' COMMENT '是否已使用',
  `use_count` int unsigned DEFAULT '0' COMMENT '使用次数',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_batch_id` (`batch_id`) USING BTREE,
  KEY `idx_token` (`token`) USING BTREE,
  KEY `idx_token_hash` (`token_hash`) USING BTREE,
  KEY `idx_created_at` (`created_at`) USING BTREE,
  CONSTRAINT `fk_batch_id` FOREIGN KEY (`batch_id`) REFERENCES `token_batches` (`batch_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='Token批次明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_batch_items`
--

LOCK TABLES `token_batch_items` WRITE;
/*!40000 ALTER TABLE `token_batch_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `token_batch_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_batches`
--

DROP TABLE IF EXISTS `token_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_batches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '批次唯一ID',
  `token_count` int unsigned NOT NULL COMMENT '生成的Token数量',
  `base_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '基础URL',
  `expiry_hours` int unsigned NOT NULL COMMENT '有效期(小时)',
  `expires_at` timestamp NOT NULL COMMENT '批次中Token的过期时间',
  `created_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'admin' COMMENT '创建人',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `batch_id` (`batch_id`) USING BTREE,
  KEY `idx_batch_id` (`batch_id`) USING BTREE,
  KEY `idx_created_at` (`created_at`) USING BTREE,
  KEY `idx_expires_at` (`expires_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='Token批次表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_batches`
--

LOCK TABLES `token_batches` WRITE;
/*!40000 ALTER TABLE `token_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `token_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_usage`
--

DROP TABLE IF EXISTS `token_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_usage` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `first_used_at` timestamp NULL DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `use_count` int unsigned DEFAULT '0',
  `max_uses` int unsigned DEFAULT '3',
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_expired` tinyint(1) DEFAULT '0',
  `is_blocked` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `token_hash` (`token_hash`) USING BTREE,
  KEY `idx_token_hash` (`token_hash`) USING BTREE,
  KEY `idx_email_id` (`email_id`) USING BTREE,
  KEY `idx_expires_at` (`expires_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_usage`
--

LOCK TABLES `token_usage` WRITE;
/*!40000 ALTER TABLE `token_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `token_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'redirect_system_prod'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-20  3:51:24
