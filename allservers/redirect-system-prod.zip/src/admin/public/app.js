// ============================================
// 反检测重定向系统 - 管理后台前端
// 版本: 3.0 - 包含仪表板 + 过滤器配置
// ============================================

const API_BASE = window.location.origin + '/api';

// Axios配置
axios.defaults.baseURL = API_BASE;
axios.interceptors.request.use(config => {
    const token = localStorage.getItem('admin_token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

axios.interceptors.response.use(
    response => response,
    error => {
        if (error.response?.status === 401) {
            localStorage.removeItem('admin_token');
            localStorage.removeItem('user_info');
            window.location.reload();
        }
        return Promise.reject(error);
    }
);

// Vue应用
const { createApp } = Vue;
const app = createApp({
    data() {
        return {
            loading: false,
            isLoggedIn: false,
            currentPage: 'dashboard',
            userInfo: {},
            loginForm: {
                username: '',
                password: ''
            },
            loginLoading: false,
            showPasswordDialog: false,
            passwordForm: {
                oldPassword: '',
                newPassword: '',
                confirmPassword: ''
            },
            menuList: [
                { key: 'dashboard', label: '仪表板', icon: '📊' },
                { key: 'config-basic', label: '基础配置', icon: '⚙️' },
                { key: 'config-database', label: '数据库配置', icon: '🗄️' },
                { key: 'config-filters', label: '过滤器配置', icon: '🛡️' },
                { key: 'config-domains', label: '域名配置', icon: '🌐' },
                { key: 'logs', label: '日志查询', icon: '📝' },
                { key: 'settings', label: '系统设置', icon: '⚙️' }
            ],
            // 仪表板数据
            dashboardData: {
                system: {},
                today: {},
                countries: [],
                tokens: {}
            },
            dashboardTimer: null,
            
            // 过滤器配置数据
            filtersConfig: {
                ENABLE_TOKEN_FILTER: { value: 'true' },
                ENABLE_SECURITY_FILTER: { value: 'true' },
                ENABLE_GEO_FILTER: { value: 'true' },
                ENABLE_LANGUAGE_FILTER: { value: 'true' },
                ENABLE_DEVICE_FILTER: { value: 'true' },
                ENABLE_BEHAVIOR_FILTER: { value: 'true' },
                ENABLE_FINGERPRINT_FILTER: { value: 'false' }
            },
            geoConfig: {
                ALLOWED_COUNTRIES: { value: '' }
            },
            languageConfig: {
                ALLOWED_LANGUAGES: { value: '' }
            },
            filtersLoading: false,
            filterStats: null
        };
    },
    computed: {
        currentPageTitle() {
            const menu = this.menuList.find(m => m.key === this.currentPage);
            return menu ? menu.label : '';
        }
    },
    watch: {
        currentPage(newPage, oldPage) {
            // 离开仪表板时停止自动刷新
            if (oldPage === 'dashboard' && this.dashboardTimer) {
                clearInterval(this.dashboardTimer);
                this.dashboardTimer = null;
            }
            
            // 根据页面加载对应数据
            if (newPage === 'dashboard') {
                this.startDashboardAutoRefresh();
            } else if (newPage === 'config-filters') {
                this.loadFiltersConfig();
            }
        }
    },
    mounted() {
        this.checkLogin();
    },
    beforeUnmount() {
        if (this.dashboardTimer) {
            clearInterval(this.dashboardTimer);
        }
    },
    methods: {
        // ============================================
        // 认证相关
        // ============================================
        
        checkLogin() {
            const token = localStorage.getItem('admin_token');
            const userInfo = localStorage.getItem('user_info');
            
            if (token && userInfo) {
                this.isLoggedIn = true;
                this.userInfo = JSON.parse(userInfo);
                this.loadDashboard();
            }
        },

        async handleLogin() {
            if (!this.loginForm.username || !this.loginForm.password) {
                ElementPlus.ElMessage.error('请输入用户名和密码');
                return;
            }

            this.loginLoading = true;
            try {
                const { data } = await axios.post('/auth/login', this.loginForm);
                
                if (data.success) {
                    localStorage.setItem('admin_token', data.data.token);
                    localStorage.setItem('user_info', JSON.stringify(data.data.user));
                    
                    this.isLoggedIn = true;
                    this.userInfo = data.data.user;
                    
                    ElementPlus.ElMessage.success('登录成功');
                    this.loadDashboard();
                }
            } catch (error) {
                const message = error.response?.data?.message || '登录失败';
                ElementPlus.ElMessage.error(message);
            } finally {
                this.loginLoading = false;
            }
        },

        async handleLogout() {
            try {
                await axios.post('/auth/logout');
            } catch (error) {
                // 忽略错误
            }
            
            localStorage.removeItem('admin_token');
            localStorage.removeItem('user_info');
            window.location.reload();
        },

        async handleChangePassword() {
            const { oldPassword, newPassword, confirmPassword } = this.passwordForm;
            
            if (!oldPassword || !newPassword || !confirmPassword) {
                ElementPlus.ElMessage.error('请填写完整');
                return;
            }
            
            if (newPassword !== confirmPassword) {
                ElementPlus.ElMessage.error('两次密码不一致');
                return;
            }
            
            if (newPassword.length < 6) {
                ElementPlus.ElMessage.error('密码长度至少6位');
                return;
            }

            try {
                const { data } = await axios.put('/auth/password', {
                    oldPassword,
                    newPassword
                });
                
                if (data.success) {
                    ElementPlus.ElMessage.success('密码修改成功，请重新登录');
                    this.showPasswordDialog = false;
                    setTimeout(() => {
                        this.handleLogout();
                    }, 1500);
                }
            } catch (error) {
                const message = error.response?.data?.message || '修改失败';
                ElementPlus.ElMessage.error(message);
            }
        },

        // ============================================
        // 仪表板 - 完整实现
        // ============================================
        
        async loadDashboard() {
            if (!this.isLoggedIn) return;
            
            try {
                const { data } = await axios.get('/stats/overview');
                if (data.success) {
                    this.dashboardData = data.data;
                    this.renderDashboard();
                }
            } catch (error) {
                console.error('加载仪表板失败', error);
            }
        },

        startDashboardAutoRefresh() {
            this.loadDashboard();
            this.dashboardTimer = setInterval(() => {
                this.loadDashboard();
            }, 30000);
        },

        renderDashboard() {
            const el = document.getElementById('page-dashboard');
            if (!el) {
                setTimeout(() => this.renderDashboard(), 100);
                return;
            }

            const { system, today, countries, tokens } = this.dashboardData;
            
            const uptime = system.uptime || 0;
            const days = Math.floor(uptime / 86400);
            const hours = Math.floor((uptime % 86400) / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            
            let uptimeStr = '';
            if (days > 0) uptimeStr += `${days}天 `;
            if (hours > 0 || days > 0) uptimeStr += `${hours}小时 `;
            uptimeStr += `${minutes}分钟`;

            el.innerHTML = `
                <div class="stat-grid">
                    <div class="stat-card">
                        <div class="stat-label">系统状态</div>
                        <div class="stat-value" style="color: ${system.mysqlStatus === 'connected' && system.redisStatus === 'connected' ? '#67c23a' : '#f56c6c'};">
                            ${system.mysqlStatus === 'connected' && system.redisStatus === 'connected' ? '✅ 正常运行' : '⚠️ 服务异常'}
                        </div>
                        <div style="margin-top: 10px; font-size: 12px; color: #999;">
                            MySQL: ${system.mysqlStatus === 'connected' ? '<span style="color: #67c23a;">✅ 已连接</span>' : '<span style="color: #f56c6c;">❌ 断开</span>'} | 
                            Redis: ${system.redisStatus === 'connected' ? '<span style="color: #67c23a;">✅ 已连接</span>' : '<span style="color: #f56c6c;">❌ 断开</span>'}
                        </div>
                        <div style="margin-top: 5px; font-size: 12px; color: #999;">
                            运行时间: ${uptimeStr}
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-label">今日访问</div>
                        <div class="stat-value" style="color: #409EFF;">${today.total || 0}</div>
                        <div style="margin-top: 10px; font-size: 12px; color: #999;">
                            <span style="color: #67c23a;">✓ 通过: ${today.allowed || 0}</span> | 
                            <span style="color: #f56c6c;">✗ 拒绝: ${today.rejected || 0}</span>
                        </div>
                        <div style="margin-top: 5px; font-size: 12px; color: #999;">
                            平均处理: ${today.avg_process_time ? Math.round(today.avg_process_time) + 'ms' : '-'}
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-label">访问通过率</div>
                        <div class="stat-value" style="color: ${(today.allowRate || 0) >= 70 ? '#67c23a' : (today.allowRate || 0) >= 50 ? '#E6A23C' : '#f56c6c'};">
                            ${today.allowRate || 0}%
                        </div>
                        <div style="margin-top: 10px; font-size: 12px; color: #999;">
                            拒绝率: ${today.rejectRate || 0}%
                        </div>
                        <div style="margin-top: 5px;">
                            <div style="background: #f0f0f0; height: 6px; border-radius: 3px; overflow: hidden;">
                                <div style="background: #67c23a; height: 100%; width: ${today.allowRate || 0}%;"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-label">Token统计</div>
                        <div class="stat-value" style="color: #409EFF;">${tokens.active_tokens || 0}</div>
                        <div style="margin-top: 10px; font-size: 12px; color: #999;">
                            活跃: ${tokens.active_tokens || 0} | 
                            已过期: ${tokens.expired_tokens || 0}
                        </div>
                        <div style="margin-top: 5px; font-size: 12px; color: #999;">
                            总计: ${(tokens.active_tokens || 0) + (tokens.expired_tokens || 0)}
                        </div>
                    </div>
                </div>

                <div class="page-card">
                    <div class="card-title">📍 今日访问国家分布 (Top 10)</div>
                    ${countries && countries.length > 0 ? `
                        <table style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="background: #f5f7fa; text-align: left;">
                                    <th style="padding: 12px; border-bottom: 1px solid #ebeef5;">排名</th>
                                    <th style="padding: 12px; border-bottom: 1px solid #ebeef5;">国家代码</th>
                                    <th style="padding: 12px; border-bottom: 1px solid #ebeef5;">国家名称</th>
                                    <th style="padding: 12px; border-bottom: 1px solid #ebeef5;">访问次数</th>
                                    <th style="padding: 12px; border-bottom: 1px solid #ebeef5;">占比</th>
                                    <th style="padding: 12px; border-bottom: 1px solid #ebeef5;">通过</th>
                                    <th style="padding: 12px; border-bottom: 1px solid #ebeef5;">拒绝</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${countries.slice(0, 10).map((item, index) => {
                                    const total = today.total || 1;
                                    const percent = ((item.count / total) * 100).toFixed(1);
                                    const allowedCount = item.allowed || 0;
                                    const rejectedCount = item.rejected || 0;
                                    return `
                                        <tr>
                                            <td style="padding: 12px; border-bottom: 1px solid #ebeef5;">
                                                <span style="
                                                    display: inline-block;
                                                    width: 24px;
                                                    height: 24px;
                                                    line-height: 24px;
                                                    text-align: center;
                                                    border-radius: 50%;
                                                    background: ${index < 3 ? '#409EFF' : '#909399'};
                                                    color: white;
                                                    font-size: 12px;
                                                ">${index + 1}</span>
                                            </td>
                                            <td style="padding: 12px; border-bottom: 1px solid #ebeef5;">
                                                <strong>${item.country_code || '-'}</strong>
                                            </td>
                                            <td style="padding: 12px; border-bottom: 1px solid #ebeef5;">
                                                ${item.country_name || '-'}
                                            </td>
                                            <td style="padding: 12px; border-bottom: 1px solid #ebeef5;">
                                                <strong style="color: #409EFF;">${item.count}</strong>
                                            </td>
                                            <td style="padding: 12px; border-bottom: 1px solid #ebeef5;">
                                                ${percent}%
                                                <div style="margin-top: 4px; background: #f0f0f0; height: 4px; border-radius: 2px; overflow: hidden; width: 100px;">
                                                    <div style="background: #409EFF; height: 100%; width: ${percent}%;"></div>
                                                </div>
                                            </td>
                                            <td style="padding: 12px; border-bottom: 1px solid #ebeef5;">
                                                <span style="color: #67c23a;">${allowedCount}</span>
                                            </td>
                                            <td style="padding: 12px; border-bottom: 1px solid #ebeef5;">
                                                <span style="color: #f56c6c;">${rejectedCount}</span>
                                            </td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    ` : '<div style="text-align: center; padding: 40px; color: #999;">暂无访问数据</div>'}
                </div>

                <div class="page-card">
                    <div class="card-title">💻 系统信息</div>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                        <div>
                            <div style="margin-bottom: 15px;">
                                <div style="color: #999; font-size: 12px; margin-bottom: 5px;">运行环境</div>
                                <div style="font-size: 16px; font-weight: bold;">${system.env || 'development'}</div>
                            </div>
                            <div style="margin-bottom: 15px;">
                                <div style="color: #999; font-size: 12px; margin-bottom: 5px;">Node.js版本</div>
                                <div style="font-size: 16px;">${system.nodeVersion || '-'}</div>
                            </div>
                            <div>
                                <div style="color: #999; font-size: 12px; margin-bottom: 5px;">运行平台</div>
                                <div style="font-size: 16px;">${system.platform || '-'}</div>
                            </div>
                        </div>
                        <div>
                            <div style="margin-bottom: 15px;">
                                <div style="color: #999; font-size: 12px; margin-bottom: 5px;">运行时间</div>
                                <div style="font-size: 16px; font-weight: bold; color: #67c23a;">${uptimeStr}</div>
                            </div>
                            <div style="margin-bottom: 15px;">
                                <div style="color: #999; font-size: 12px; margin-bottom: 5px;">上次刷新</div>
                                <div style="font-size: 14px;">${new Date().toLocaleString('zh-CN')}</div>
                            </div>
                            <div>
                                <div style="color: #999; font-size: 12px; margin-bottom: 5px;">自动刷新</div>
                                <div style="font-size: 14px;">
                                    <span style="
                                        display: inline-block;
                                        padding: 2px 8px;
                                        background: #e1f3d8;
                                        color: #67c23a;
                                        border-radius: 4px;
                                        font-size: 12px;
                                    ">每30秒</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        },

        // ============================================
        // 过滤器配置 - 完整实现
        // ============================================
        
        async loadFiltersConfig() {
            this.filtersLoading = true;
            try {
                const { data } = await axios.get('/config/all');
                if (data.success) {
                    const configs = data.data;
                    
                    // 提取过滤器配置
                    if (configs.filters) {
                        configs.filters.forEach(item => {
                            if (this.filtersConfig[item.key_name]) {
                                this.filtersConfig[item.key_name] = item;
                            }
                        });
                    }
                    
                    // 提取地理位置配置
                    if (configs.geo) {
                        configs.geo.forEach(item => {
                            if (item.key_name === 'ALLOWED_COUNTRIES') {
                                this.geoConfig.ALLOWED_COUNTRIES = item;
                            }
                        });
                    }
                    
                    // 提取语言配置
                    if (configs.language) {
                        configs.language.forEach(item => {
                            if (item.key_name === 'ALLOWED_LANGUAGES') {
                                this.languageConfig.ALLOWED_LANGUAGES = item;
                            }
                        });
                    }
                    
                    // 加载过滤器统计
                    await this.loadFilterStats();
                    
                    this.renderFiltersConfig();
                }
            } catch (error) {
                console.error('加载过滤器配置失败', error);
                ElementPlus.ElMessage.error('加载配置失败');
            } finally {
                this.filtersLoading = false;
            }
        },

        async loadFilterStats() {
            try {
                const { data } = await axios.get('/stats/overview');
                if (data.success) {
                    this.filterStats = data.data.today;
                }
            } catch (error) {
                console.error('加载过滤器统计失败', error);
            }
        },

        async toggleFilter(filterKey) {
            const currentValue = this.filtersConfig[filterKey].value;
            const newValue = currentValue === 'true' ? 'false' : 'true';
            
            if (filterKey === 'ENABLE_TOKEN_FILTER' && newValue === 'false') {
                ElementPlus.ElMessage.warning('Token验证过滤器不能关闭');
                return;
            }
            
            try {
                const { data } = await axios.put(`/config/filters/${filterKey}`, {
                    value: newValue
                });
                
                if (data.success) {
                    this.filtersConfig[filterKey].value = newValue;
                    ElementPlus.ElMessage.success('过滤器状态已更新');
                    this.renderFiltersConfig();
                }
            } catch (error) {
                ElementPlus.ElMessage.error('更新失败');
            }
        },

        async saveGeoConfig() {
            const countries = this.geoConfig.ALLOWED_COUNTRIES.value;
            
            try {
                const { data } = await axios.put('/config/geo/ALLOWED_COUNTRIES', {
                    value: countries
                });
                
                if (data.success) {
                    ElementPlus.ElMessage.success('地理位置配置已保存');
                }
            } catch (error) {
                ElementPlus.ElMessage.error('保存失败');
            }
        },

        async setFilterMode(mode) {
            const modes = {
                minimal: ['ENABLE_TOKEN_FILTER'],
                balanced: ['ENABLE_TOKEN_FILTER', 'ENABLE_SECURITY_FILTER', 'ENABLE_GEO_FILTER', 'ENABLE_BEHAVIOR_FILTER'],
                strict: Object.keys(this.filtersConfig)
            };
            
            const enableFilters = modes[mode];
            
            try {
                // 批量更新
                const updates = Object.keys(this.filtersConfig).map(key => ({
                    category: 'filter_settings',
                    key: key,
                    value: enableFilters.includes(key) ? 'true' : 'false'
                }));
                
                const { data } = await axios.post('/config/batch', { configs: updates });
                
                if (data.success) {
                    Object.keys(this.filtersConfig).forEach(key => {
                        this.filtersConfig[key].value = enableFilters.includes(key) ? 'true' : 'false';
                    });
                    
                    const modeName = mode === 'minimal' ? '宽松' : mode === 'balanced' ? '平衡' : '严格';
                    ElementPlus.ElMessage.success(`已切换到${modeName}模式`);
                    this.renderFiltersConfig();
                }
            } catch (error) {
                ElementPlus.ElMessage.error('切换模式失败');
            }
        },

        addCountry(code) {
            const input = document.getElementById('allowed-countries');
            const current = this.geoConfig.ALLOWED_COUNTRIES.value;
            const countries = current ? current.split(',').map(c => c.trim()) : [];
            
            if (!countries.includes(code)) {
                countries.push(code);
                this.geoConfig.ALLOWED_COUNTRIES.value = countries.join(',');
                input.value = this.geoConfig.ALLOWED_COUNTRIES.value;
            }
        },

        getFilterDescription(filterKey) {
            const descriptions = {
                ENABLE_TOKEN_FILTER: {
                    name: 'Token验证',
                    desc: '验证访问链接中的Token是否有效',
                    icon: '🔐',
                    importance: '必须',
                    detail: '这是系统的核心防护，验证每个访问请求的Token有效性、是否过期、使用次数等'
                },
                ENABLE_SECURITY_FILTER: {
                    name: '安全检测',
                    desc: '检测VPN、代理、Tor等隐藏身份工具',
                    icon: '🛡️',
                    importance: '重要',
                    detail: '通过IP信誉库检测访问者是否使用VPN、代理服务器、Tor网络等工具'
                },
                ENABLE_GEO_FILTER: {
                    name: '地理位置',
                    desc: '限制特定国家/地区的访问',
                    icon: '🌍',
                    importance: '中等',
                    detail: '根据IP地址判断访问者的地理位置，只允许白名单中的国家访问'
                },
                ENABLE_LANGUAGE_FILTER: {
                    name: '语言检测',
                    desc: '检测浏览器语言设置',
                    icon: '🗣️',
                    importance: '中等',
                    detail: '分析浏览器的Accept-Language头，判断用户的语言偏好'
                },
                ENABLE_DEVICE_FILTER: {
                    name: '设备指纹',
                    desc: '分析设备类型和User-Agent',
                    icon: '📱',
                    importance: '中等',
                    detail: '检测设备类型、操作系统、浏览器版本等信息，识别可疑的自动化工具'
                },
                ENABLE_BEHAVIOR_FILTER: {
                    name: '行为分析',
                    desc: '分析访问频率和行为模式',
                    icon: '📊',
                    importance: '高',
                    detail: '检测异常的访问频率、短时间内的重复访问等可疑行为'
                },
                ENABLE_FINGERPRINT_FILTER: {
                    name: '高级指纹',
                    desc: '使用Canvas/WebGL等高级指纹技术',
                    icon: '🔬',
                    importance: '可选',
                    detail: '使用浏览器指纹技术（Canvas、WebGL等）进行更精确的设备识别'
                }
            };
            return descriptions[filterKey] || {};
        },

        renderFiltersConfig() {
            const el = document.getElementById('page-filters');
            if (!el) {
                setTimeout(() => this.renderFiltersConfig(), 100);
                return;
            }

            const filters = this.filtersConfig;
            const stats = this.filterStats || {};
            
            const enabledCount = Object.values(filters).filter(f => f.value === 'true').length;
            const totalCount = Object.keys(filters).length;

            el.innerHTML = `
                <div class="stat-grid" style="margin-bottom: 20px;">
                    <div class="stat-card">
                        <div class="stat-label">启用的过滤器</div>
                        <div class="stat-value" style="color: #409EFF;">${enabledCount} / ${totalCount}</div>
                        <div style="margin-top: 10px;">
                            <div style="background: #f0f0f0; height: 6px; border-radius: 3px; overflow: hidden;">
                                <div style="background: #409EFF; height: 100%; width: ${(enabledCount/totalCount*100).toFixed(0)}%;"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-label">今日通过</div>
                        <div class="stat-value" style="color: #67c23a;">${stats.allowed || 0}</div>
                        <div style="margin-top: 10px; font-size: 12px; color: #999;">
                            通过率: ${stats.allowRate || 0}%
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-label">今日拒绝</div>
                        <div class="stat-value" style="color: #f56c6c;">${stats.rejected || 0}</div>
                        <div style="margin-top: 10px; font-size: 12px; color: #999;">
                            拒绝率: ${stats.rejectRate || 0}%
                        </div>
                    </div>
                </div>

                <div class="page-card">
                    <div class="card-title">⚡ 快速模式</div>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                        <div style="
                            padding: 15px;
                            border: 2px solid ${enabledCount === 1 ? '#409EFF' : '#dcdfe6'};
                            border-radius: 8px;
                            cursor: pointer;
                            text-align: center;
                            transition: all 0.3s;
                        " onclick="app._instance.ctx.setFilterMode('minimal')">
                            <div style="font-size: 24px; margin-bottom: 5px;">🔓</div>
                            <div style="font-weight: bold; margin-bottom: 5px;">宽松模式</div>
                            <div style="font-size: 12px; color: #999;">仅Token验证</div>
                            <div style="font-size: 12px; color: #999; margin-top: 5px;">适合测试环境</div>
                        </div>
                        
                        <div style="
                            padding: 15px;
                            border: 2px solid ${enabledCount === 4 ? '#409EFF' : '#dcdfe6'};
                            border-radius: 8px;
                            cursor: pointer;
                            text-align: center;
                            transition: all 0.3s;
                        " onclick="app._instance.ctx.setFilterMode('balanced')">
                            <div style="font-size: 24px; margin-bottom: 5px;">⚖️</div>
                            <div style="font-weight: bold; margin-bottom: 5px;">平衡模式</div>
                            <div style="font-size: 12px; color: #999;">4个核心过滤器</div>
                            <div style="font-size: 12px; color: #409EFF; margin-top: 5px;">推荐</div>
                        </div>
                        
                        <div style="
                            padding: 15px;
                            border: 2px solid ${enabledCount === totalCount ? '#409EFF' : '#dcdfe6'};
                            border-radius: 8px;
                            cursor: pointer;
                            text-align: center;
                            transition: all 0.3s;
                        " onclick="app._instance.ctx.setFilterMode('strict')">
                            <div style="font-size: 24px; margin-bottom: 5px;">🔒</div>
                            <div style="font-weight: bold; margin-bottom: 5px;">严格模式</div>
                            <div style="font-size: 12px; color: #999;">全部启用</div>
                            <div style="font-size: 12px; color: #999; margin-top: 5px;">最高安全性</div>
                        </div>
                    </div>
                </div>

                <div class="page-card">
                    <div class="card-title">🛡️ 过滤器配置</div>
                    ${Object.keys(filters).map((key) => {
                        const filter = filters[key];
                        const info = this.getFilterDescription(key);
                        const isEnabled = filter.value === 'true';
                        const isRequired = key === 'ENABLE_TOKEN_FILTER';
                        
                        return `
                            <div style="
                                padding: 20px;
                                border: 2px solid ${isEnabled ? '#e1f3d8' : '#f5f7fa'};
                                border-radius: 8px;
                                margin-bottom: 15px;
                                background: ${isEnabled ? '#f0f9ff' : 'white'};
                                transition: all 0.3s;
                            ">
                                <div style="display: flex; align-items: center; justify-content: space-between;">
                                    <div style="flex: 1;">
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <span style="font-size: 24px; margin-right: 10px;">${info.icon}</span>
                                            <div>
                                                <div style="font-size: 18px; font-weight: bold; margin-bottom: 5px;">
                                                    ${info.name}
                                                    ${isRequired ? '<span style="color: #f56c6c; font-size: 12px; margin-left: 5px;">必须</span>' : ''}
                                                    <span style="
                                                        margin-left: 10px;
                                                        padding: 2px 8px;
                                                        background: ${isEnabled ? '#67c23a' : '#909399'};
                                                        color: white;
                                                        border-radius: 4px;
                                                        font-size: 12px;
                                                    ">${isEnabled ? '已启用' : '已禁用'}</span>
                                                </div>
                                                <div style="color: #666; font-size: 14px;">${info.desc}</div>
                                            </div>
                                        </div>
                                        
                                        <div style="
                                            padding: 10px;
                                            background: white;
                                            border-left: 3px solid #409EFF;
                                            margin: 10px 0;
                                            font-size: 13px;
                                            color: #666;
                                            line-height: 1.6;
                                        ">
                                            ${info.detail}
                                        </div>
                                        
                                        <div style="margin-top: 10px;">
                                            <span style="
                                                display: inline-block;
                                                padding: 4px 12px;
                                                background: #f5f7fa;
                                                border-radius: 4px;
                                                font-size: 12px;
                                                color: #666;
                                            ">
                                                重要程度: <strong style="color: ${
                                                    info.importance === '必须' ? '#f56c6c' :
                                                    info.importance === '重要' ? '#E6A23C' :
                                                    info.importance === '高' ? '#409EFF' : '#909399'
                                                };">${info.importance}</strong>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div style="margin-left: 20px;">
                                        <label class="filter-switch">
                                            <input type="checkbox" 
                                                ${isEnabled ? 'checked' : ''} 
                                                ${isRequired ? 'disabled' : ''}
                                                onchange="app._instance.ctx.toggleFilter('${key}')">
                                            <span class="slider"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>

                <div class="page-card">
                    <div class="card-title">🌍 地理位置白名单</div>
                    <div style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px; font-weight: bold;">
                            允许的国家（国家代码，用逗号分隔）
                        </label>
                        <input 
                            type="text" 
                            id="allowed-countries"
                            value="${this.geoConfig.ALLOWED_COUNTRIES.value || ''}"
                            placeholder="例如: CN,JP,US,KR"
                            style="
                                width: 100%;
                                padding: 10px;
                                border: 1px solid #dcdfe6;
                                border-radius: 4px;
                                font-size: 14px;
                            "
                            oninput="app._instance.data.geoConfig.ALLOWED_COUNTRIES.value = this.value"
                        >
                        <div style="margin-top: 10px; font-size: 12px; color: #999;">
                            💡 留空表示允许所有国家。只有启用"地理位置过滤器"时此配置才生效。
                        </div>
                    </div>
                    
                    <div style="margin-top: 15px;">
                        <div style="font-weight: bold; margin-bottom: 10px;">常用国家：</div>
                        <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                            ${['CN-中国', 'JP-日本', 'US-美国', 'KR-韩国', 'GB-英国', 'DE-德国', 'FR-法国', 'CA-加拿大'].map(country => {
                                const [code, name] = country.split('-');
                                return `
                                    <button onclick="app._instance.ctx.addCountry('${code}')" style="
                                        padding: 8px 15px;
                                        border: 1px solid #dcdfe6;
                                        border-radius: 4px;
                                        background: white;
                                        cursor: pointer;
                                        font-size: 13px;
                                        transition: all 0.3s;
                                    " onmouseover="this.style.borderColor='#409EFF'; this.style.color='#409EFF';" 
                                       onmouseout="this.style.borderColor='#dcdfe6'; this.style.color='#333';">
                                        ${code} ${name}
                                    </button>
                                `;
                            }).join('')}
                        </div>
                    </div>
                    
                    <div style="margin-top: 20px;">
                        <button onclick="app._instance.ctx.saveGeoConfig()" style="
                            padding: 10px 30px;
                            background: #409EFF;
                            color: white;
                            border: none;
                            border-radius: 4px;
                            cursor: pointer;
                            font-size: 14px;
                        ">保存地理位置配置</button>
                    </div>
                </div>

                <style>
                    .filter-switch {
                        position: relative;
                        display: inline-block;
                        width: 60px;
                        height: 34px;
                    }
                    
                    .filter-switch input {
                        opacity: 0;
                        width: 0;
                        height: 0;
                    }
                    
                    .filter-switch .slider {
                        position: absolute;
                        cursor: pointer;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        background-color: #ccc;
                        transition: .4s;
                        border-radius: 34px;
                    }
                    
                    .filter-switch .slider:before {
                        position: absolute;
                        content: "";
                        height: 26px;
                        width: 26px;
                        left: 4px;
                        bottom: 4px;
                        background-color: white;
                        transition: .4s;
                        border-radius: 50%;
                    }
                    
                    .filter-switch input:checked + .slider {
                        background-color: #67c23a;
                    }
                    
                    .filter-switch input:disabled + .slider {
                        background-color: #909399;
                        cursor: not-allowed;
                    }
                    
                    .filter-switch input:checked + .slider:before {
                        transform: translateX(26px);
                    }
                </style>
            `;
        }
    }
});

// 注册Element Plus
app.use(ElementPlus);

// 注册Element Plus Icons
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component);
}

// 挂载应用
app.mount('#app');
