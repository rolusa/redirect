/**
 * ============================================
 * 重定向路由
 * ============================================
 * 功能：
 * 1. 处理/r路由（主要的重定向端点）
 * 2. 调用过滤引擎进行验证
 * 3. 根据验证结果进行重定向
 * 4. 提供测试和管理端点
 * ============================================
 */

const express = require('express');
const router = express.Router();
const { tokenValidator, recordTokenUsage } = require('../middleware/tokenValidator');
const { asyncHandler } = require('../middleware/errorHandler');
const IPRegistryService = require('../services/ipRegistry');
const FilterEngine = require('../services/filterEngine');
const TokenGenerator = require('../utils/tokenGenerator');
const BehaviorFilter = require('../filters/behaviorFilter');
const logger = require('../utils/logger');
const { config } = require('../config');

/**
 * 主重定向端点
 * GET /?token=xxx
 */
router.get('/', tokenValidator, asyncHandler(async (req, res) => {
  const startTime = Date.now();
  const ip = req.ip || req.connection.remoteAddress;

  try {
    // 1. 获取IP信息
    logger.info('处理重定向请求', {
      ip,
      emailId: req.tokenData.eid,
    });

    const ipInfo = await IPRegistryService.getIPInfo(ip);

    // 2. 执行过滤
    const filterResult = await FilterEngine.filter(ipInfo, req, req.tokenData);

    // 3. 记录Token使用（异步，不阻塞）
    recordTokenUsage(req.tokenHash, req.tokenData).catch(err => {
      logger.error('记录Token使用失败', { error: err.message });
    });

    // 4. 根据过滤结果重定向
    const redirectURL = filterResult.redirectTo;

    if (filterResult.decision === 'allow') {
      logger.info('访问允许，重定向到目标', {
        ip,
        emailId: req.tokenData.eid,
        redirectTo: redirectURL,
        processTime: filterResult.processTime,
      });
    } else {
      logger.warn('访问被拒绝', {
        ip,
        emailId: req.tokenData.eid,
        reason: filterResult.reason,
        score: filterResult.score,
        redirectTo: redirectURL,
      });
    }

    // 5. 执行重定向
    res.redirect(302, redirectURL);

  } catch (error) {
    logger.error('重定向处理失败', {
      ip,
      error: error.message,
      stack: error.stack,
    });

    // 出错时重定向到备用URL
    res.redirect(302, config.domains.fallback.medium);
  }
}));

/**
 * 生成Token测试端点（仅开发环境）
 * GET /generate-token?email=xxx
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.get('/generate-token', asyncHandler(async (req, res) => {
    const email = req.query.email || 'test@example.com';

    try {
      // ✅ 添加 await 等待异步操作完成
      const tokenResult = await TokenGenerator.generate({
        emailId: `email-${Date.now()}`,
        recipientEmail: email,
      });

      // tokenResult 包含 { token, emailId, expiresAt }
      const token = tokenResult.token;

      // ✅ 添加 await 等待验证结果
      const verifyResult = await TokenGenerator.verify(token);
      
      // ✅ 添加 await 等待TTL计算
      const ttl = await TokenGenerator.getTimeToLive(token);

      res.json({
        success: true,
        token,
        testURL: `${req.protocol}://${req.get('host')}/?token=${token}`,
        tokenInfo: {
          emailId: verifyResult.data.eid,
          expiresAt: new Date(verifyResult.data.exp).toISOString(),
          timeToLive: `${Math.floor(ttl / 3600)} hours`,
          createdAt: new Date(verifyResult.data.ts).toISOString(),
        },
      });
    } catch (error) {
      logger.error('生成Token失败', {
        error: error.message,
        stack: error.stack
      });
      res.status(500).json({
        error: 'Failed to generate token',
        message: error.message,
      });
    }
  }));
}

/**
 * 健康检查端点
 * GET /health
 */
router.get('/health', asyncHandler(async (req, res) => {
  const health = {
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: config.server.env,
  };

  // 检查关键服务
  try {
    // 测试Redis
    const Cache = require('../utils/cache');
    await Cache.get('health_check');
    health.redis = 'ok';
  } catch (error) {
    health.redis = 'error';
    health.status = 'degraded';
  }

  try {
    // 测试MySQL
    const Database = require('../database/mysql');
    await Database.query('SELECT 1');
    health.database = 'ok';
  } catch (error) {
    health.database = 'error';
    health.status = 'degraded';
  }

  const statusCode = health.status === 'ok' ? 200 : 503;
  res.status(statusCode).json(health);
}));

/**
 * 统计信息端点（仅开发环境）
 * GET /stats
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.get('/stats', asyncHandler(async (req, res) => {
    const stats = await FilterEngine.getStats();
    const cacheStats = await require('../services/ipRegistry').getCacheStats();

    res.json({
      success: true,
      data: {
        ...stats,
        cache: cacheStats,
      },
    });
  }));
}

/**
 * 测试过滤器端点（仅开发环境）
 * POST /test-filter
 * Body: { ip, userAgent, language, isVPN, etc... }
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.post('/test-filter', asyncHandler(async (req, res) => {
    const result = await FilterEngine.test(req.body);
    res.json({
      success: true,
      result,
    });
  }));
}

/**
 * 清除IP记录端点（仅开发环境）
 * POST /clear-ip
 * Body: { ip }
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.post('/clear-ip', asyncHandler(async (req, res) => {
    const { ip } = req.body;

    if (!ip) {
      return res.status(400).json({
        error: 'Missing ip parameter',
      });
    }

    await BehaviorFilter.clearIPRecords(ip);
    await require('../services/ipRegistry').clearCache(ip);

    res.json({
      success: true,
      message: `Records cleared for IP: ${ip}`,
    });
  }));
}

module.exports = router;
