/**
 * ============================================
 * 日志系统
 * ============================================
 * 功能：
 * 1. 使用Winston创建日志记录器
 * 2. 支持不同级别的日志（error, warn, info, debug）
 * 3. 日志文件自动轮转
 * 4. 控制台彩色输出（开发环境）
 * ============================================
 */

const winston = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');
const path = require('path');
const fs = require('fs');
const { config } = require('../config');

// 确保日志目录存在
const logDir = config.logging.dir;
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

/**
 * 自定义日志格式
 */
const logFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.json()
);

/**
 * 控制台输出格式（带颜色）
 */
const consoleFormat = winston.format.combine(
  winston.format.colorize(),
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    let log = `${timestamp} [${level}]: ${message}`;
    
    // 如果有额外的元数据，添加到日志中
    if (Object.keys(meta).length > 0) {
      log += '\n' + JSON.stringify(meta, null, 2);
    }
    
    return log;
  })
);

/**
 * 创建日志传输配置
 */
const transports = [];

// 1. 控制台输出（开发环境）
if (config.server.env === 'development') {
  transports.push(
    new winston.transports.Console({
      format: consoleFormat,
      level: config.logging.level,
    })
  );
}

// 2. 错误日志文件（所有环境）
transports.push(
  new DailyRotateFile({
    filename: path.join(logDir, 'error-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    level: 'error',
    format: logFormat,
    maxSize: config.logging.maxSize,
    maxFiles: config.logging.maxFiles,
    zippedArchive: true,
  })
);

// 3. 访问日志文件
transports.push(
  new DailyRotateFile({
    filename: path.join(logDir, 'access-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    level: 'info',
    format: logFormat,
    maxSize: config.logging.maxSize,
    maxFiles: config.logging.maxFiles,
    zippedArchive: true,
  })
);

// 4. 组合日志文件（所有级别）
transports.push(
  new DailyRotateFile({
    filename: path.join(logDir, 'combined-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    format: logFormat,
    maxSize: config.logging.maxSize,
    maxFiles: config.logging.maxFiles,
    zippedArchive: true,
  })
);

/**
 * 创建Winston日志记录器
 */
const logger = winston.createLogger({
  level: config.logging.level,
  format: logFormat,
  transports,
  // 捕获未处理的异常和Promise拒绝
  exceptionHandlers: [
    new DailyRotateFile({
      filename: path.join(logDir, 'exceptions-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: config.logging.maxSize,
      maxFiles: config.logging.maxFiles,
    }),
  ],
  rejectionHandlers: [
    new DailyRotateFile({
      filename: path.join(logDir, 'rejections-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: config.logging.maxSize,
      maxFiles: config.logging.maxFiles,
    }),
  ],
});

/**
 * 记录访问日志的辅助函数
 * @param {Object} data - 访问数据
 */
logger.logAccess = function(data) {
  this.info('Access', {
    ...data,
    type: 'access',
  });
};

/**
 * 记录过滤结果的辅助函数
 * @param {Object} data - 过滤数据
 */
logger.logFilter = function(data) {
  const level = data.decision === 'reject' ? 'warn' : 'info';
  this.log(level, 'Filter', {
    ...data,
    type: 'filter',
  });
};

/**
 * 记录性能数据的辅助函数
 * @param {Object} data - 性能数据
 */
logger.logPerformance = function(data) {
  this.debug('Performance', {
    ...data,
    type: 'performance',
  });
};

/**
 * 记录安全事件的辅助函数
 * @param {Object} data - 安全事件数据
 */
logger.logSecurity = function(data) {
  this.warn('Security', {
    ...data,
    type: 'security',
  });
};

/**
 * Express中间件：记录HTTP请求
 */
logger.requestLogger = function() {
  return (req, res, next) => {
    const startTime = Date.now();

    // 记录响应完成事件
    res.on('finish', () => {
      const duration = Date.now() - startTime;
      const logData = {
        method: req.method,
        url: req.url,
        status: res.statusCode,
        duration: `${duration}ms`,
        ip: req.ip || req.connection.remoteAddress,
        userAgent: req.get('user-agent'),
      };

      // 根据状态码选择日志级别
      if (res.statusCode >= 500) {
        logger.error('HTTP Request', logData);
      } else if (res.statusCode >= 400) {
        logger.warn('HTTP Request', logData);
      } else {
        logger.info('HTTP Request', logData);
      }
    });

    next();
  };
};

// 生产环境：只输出到文件，不输出到控制台
if (config.server.env === 'production') {
  logger.info('日志系统初始化完成（生产模式）');
} else {
  logger.info('日志系统初始化完成（开发模式）');
}

module.exports = logger;
