/**
 * ============================================
 * Google Safe Browsing URL安全监控服务
 * ============================================
 * 功能：
 * 1. 定时调用Google Safe Browsing API检查URL安全状态
 * 2. 自动替换不安全的URL
 * 3. 从备用URL池中按顺序取用安全URL
 * 4. 替换前预检新URL确保安全
 * 5. API Key轮换、错误容错
 * 6. URL最大使用时长自动轮换
 * ============================================
 */

const axios = require('axios');
const Database = require('../database/mysql');
const logger = require('../utils/logger');

const CATEGORY = 'safety_monitor';
const API_URL = 'https://safebrowsing.googleapis.com/v4/threatMatches:find';

class SafeBrowsingService {
  static timer = null;
  static isChecking = false;
  static consecutiveFailures = 0;
  static MAX_CONSECUTIVE_FAILURES = 3;

  // ============================================
  // 配置读写
  // ============================================

  /**
   * 读取一个配置项
   */
  static async getConfig(key, defaultValue = '') {
    try {
      const row = await Database.queryOne(
        'SELECT value FROM config_items WHERE category = ? AND key_name = ? AND is_active = 1',
        [CATEGORY, key]
      );
      return row ? row.value : defaultValue;
    } catch (e) {
      logger.error('SafeBrowsing: 读取配置失败', { key, error: e.message });
      return defaultValue;
    }
  }

  /**
   * 写入一个配置项（upsert）
   */
  static async setConfig(key, value, description = '', dataType = 'string') {
    try {
      const existing = await Database.queryOne(
        'SELECT id FROM config_items WHERE category = ? AND key_name = ?',
        [CATEGORY, key]
      );
      if (existing) {
        await Database.update('config_items',
          { value: String(value), updated_by: 'system', updated_at: new Date() },
          { id: existing.id }
        );
      } else {
        await Database.insert('config_items', {
          category: CATEGORY,
          key_name: key,
          value: String(value),
          data_type: dataType,
          description: description,
          is_sensitive: false,
          is_active: true,
          updated_by: 'system'
        });
      }
    } catch (e) {
      logger.error('SafeBrowsing: 写入配置失败', { key, error: e.message });
    }
  }

  /**
   * 读取完整配置
   */
  static async getAllConfig() {
    const enabled = await this.getConfig('ENABLED', 'false');
    const checkInterval = parseInt(await this.getConfig('CHECK_INTERVAL_MINUTES', '5')) || 5;
    const activeUrlCount = parseInt(await this.getConfig('ACTIVE_URL_COUNT', '1')) || 1;
    const maxUrlAgeHours = parseInt(await this.getConfig('MAX_URL_AGE_HOURS', '0')) || 0;
    const poolUrls = (await this.getConfig('POOL_URLS', '')).split('\n').map(u => u.trim()).filter(u => u.startsWith('http'));
    const apiKeys = (await this.getConfig('API_KEYS', '')).split('\n').map(k => k.trim()).filter(k => k.length > 0);
    const lastCheckTime = await this.getConfig('LAST_CHECK_TIME', '');
    const urlActivatedAt = this._parseJSON(await this.getConfig('URL_ACTIVATED_AT', '{}'), {});
    const retiredUrls = this._parseJSON(await this.getConfig('RETIRED_URLS', '[]'), []);

    // 从domains.TARGET_URL读取当前生效的URL（B输入框）
    let activeUrls = [];
    try {
      const targetConfig = await Database.queryOne(
        'SELECT value FROM config_items WHERE key_name = ? AND category = ?',
        ['TARGET_URL', 'domains']
      );
      if (targetConfig && targetConfig.value) {
        activeUrls = targetConfig.value.split('\n').map(u => u.trim()).filter(u => u.startsWith('http'));
      }
    } catch (e) {
      logger.error('SafeBrowsing: 读取TARGET_URL失败', { error: e.message });
    }

    return {
      enabled: enabled === 'true',
      checkInterval,
      activeUrlCount,
      maxUrlAgeHours,
      poolUrls,
      activeUrls,
      apiKeys,
      lastCheckTime,
      urlActivatedAt,
      retiredUrls
    };
  }

  // ============================================
  // 定时器管理
  // ============================================

  /**
   * 初始化（服务启动时调用）
   */
  static async init() {
    try {
      const config = await this.getAllConfig();
      if (config.enabled && config.apiKeys.length > 0) {
        this.startTimer(config.checkInterval);
        logger.info('SafeBrowsing: 安全监控已自动启动', { interval: config.checkInterval });
      } else {
        logger.info('SafeBrowsing: 安全监控未启用或缺少API Key');
      }
    } catch (e) {
      logger.error('SafeBrowsing: 初始化失败', { error: e.message });
    }
  }

  /**
   * 启动定时器
   */
  static startTimer(intervalMinutes) {
    this.stopTimer();
    const ms = Math.max(1, intervalMinutes) * 60 * 1000;
    this.timer = setInterval(() => this.checkNow(), ms);
    logger.info('SafeBrowsing: 定时器已启动', { intervalMinutes });
  }

  /**
   * 停止定时器
   */
  static stopTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      logger.info('SafeBrowsing: 定时器已停止');
    }
  }

  /**
   * 启动监控
   */
  static async start() {
    const config = await this.getAllConfig();
    if (config.apiKeys.length === 0) {
      throw new Error('请先配置至少一个Google Safe Browsing API Key');
    }
    await this.setConfig('ENABLED', 'true');
    this.consecutiveFailures = 0;
    this.startTimer(config.checkInterval);
    return { success: true, message: '监控已启动' };
  }

  /**
   * 停止监控
   */
  static async stop() {
    this.stopTimer();
    await this.setConfig('ENABLED', 'false');
    return { success: true, message: '监控已停止' };
  }

  // ============================================
  // 核心检查逻辑
  // ============================================

  /**
   * 执行一次检查（主流程）
   */
  static async checkNow() {
    if (this.isChecking) {
      logger.warn('SafeBrowsing: 上一次检查尚未完成，跳过本次');
      return { skipped: true, reason: '上一次检查尚未完成' };
    }

    this.isChecking = true;
    const startTime = Date.now();

    try {
      const config = await this.getAllConfig();

      if (config.apiKeys.length === 0) {
        return { success: false, error: '未配置API Key' };
      }

      if (config.activeUrls.length === 0) {
        return { success: true, message: 'B输入框为空，无需检查' };
      }

      logger.info('SafeBrowsing: 开始安全检查', {
        activeUrls: config.activeUrls.length,
        poolUrls: config.poolUrls.length
      });

      // 1. 检查URL安全性
      const apiKey = this._getRandomItem(config.apiKeys);
      const unsafeResults = await this.checkURLsSafety(config.activeUrls, apiKey);

      // 2. 检查URL年龄（自动轮换）
      let ageExpiredUrls = [];
      if (config.maxUrlAgeHours > 0) {
        ageExpiredUrls = this._getAgeExpiredUrls(config.activeUrls, config.urlActivatedAt, config.maxUrlAgeHours);
      }

      // 3. 合并需要替换的URL列表（去重）
      const unsafeUrlSet = new Set(unsafeResults.map(r => r.url));
      const ageExpiredSet = new Set(ageExpiredUrls);
      const toReplaceUrls = [...new Set([...unsafeUrlSet, ...ageExpiredSet])];

      // 4. 记录检查时间
      await this.setConfig('LAST_CHECK_TIME', new Date().toISOString());

      if (toReplaceUrls.length === 0) {
        this.consecutiveFailures = 0;
        const elapsed = Date.now() - startTime;
        logger.info('SafeBrowsing: 所有URL安全', { elapsed: elapsed + 'ms' });
        return {
          success: true,
          allSafe: true,
          checkedCount: config.activeUrls.length,
          elapsed
        };
      }

      // 5. 执行替换
      logger.warn('SafeBrowsing: 发现需要替换的URL', {
        unsafe: unsafeResults.length,
        ageExpired: ageExpiredUrls.length,
        totalReplace: toReplaceUrls.length
      });

      const replaceResult = await this.replaceURLs(
        toReplaceUrls,
        config.activeUrls,
        config.poolUrls,
        config.apiKeys,
        config.urlActivatedAt,
        config.retiredUrls,
        unsafeResults
      );

      this.consecutiveFailures = 0;
      const elapsed = Date.now() - startTime;

      return {
        success: true,
        allSafe: false,
        checkedCount: config.activeUrls.length,
        replacedCount: replaceResult.replacedCount,
        elapsed,
        details: replaceResult
      };

    } catch (error) {
      this.consecutiveFailures++;
      logger.error('SafeBrowsing: 检查失败', {
        error: error.message,
        consecutiveFailures: this.consecutiveFailures
      });

      if (this.consecutiveFailures >= this.MAX_CONSECUTIVE_FAILURES) {
        logger.error('SafeBrowsing: 连续失败已达上限，暂停监控');
        this.stopTimer();
        await this.setConfig('ENABLED', 'false');
      }

      return { success: false, error: error.message };
    } finally {
      this.isChecking = false;
    }
  }

  /**
   * 调用Google Safe Browsing API批量检查URL安全性
   * @param {string[]} urls - URL列表
   * @param {string} apiKey - API Key
   * @returns {Array} 不安全的URL列表 [{url, threatType}]
   */
  static async checkURLsSafety(urls, apiKey) {
    if (!urls || urls.length === 0) return [];

    try {
      const response = await axios.post(
        `${API_URL}?key=${apiKey}`,
        {
          client: {
            clientId: 'redirect-system-safety-monitor',
            clientVersion: '1.0.0'
          },
          threatInfo: {
            threatTypes: [
              'MALWARE',
              'SOCIAL_ENGINEERING',
              'UNWANTED_SOFTWARE',
              'POTENTIALLY_HARMFUL_APPLICATION'
            ],
            platformTypes: ['ANY_PLATFORM'],
            threatEntryTypes: ['URL'],
            threatEntries: urls.map(url => ({ url }))
          }
        },
        { timeout: 10000 }
      );

      const matches = response.data.matches || [];

      return matches.map(match => ({
        url: match.threat.url,
        threatType: match.threatType,
        platformType: match.platformType
      }));

    } catch (error) {
      if (error.response) {
        const status = error.response.status;
        const msg = error.response.data?.error?.message || '';
        logger.error('SafeBrowsing: API调用失败', { status, msg });

        if (status === 400 && msg.includes('API key not valid')) {
          throw new Error(`API Key无效: ${apiKey.substring(0, 15)}...`);
        }
        if (status === 429) {
          throw new Error('API配额耗尽，请稍后重试');
        }
      }
      throw new Error(`API调用失败: ${error.message}`);
    }
  }

  /**
   * 替换不安全URL的完整流程
   */
  static async replaceURLs(toReplaceUrls, currentActiveUrls, currentPoolUrls, apiKeys, urlActivatedAt, retiredUrls, unsafeDetails) {
    let newActiveUrls = [...currentActiveUrls];
    let newPoolUrls = [...currentPoolUrls];
    let newActivatedAt = { ...urlActivatedAt };
    let newRetiredUrls = [...retiredUrls];
    let replacedCount = 0;
    const logEntries = [];

    for (const badUrl of toReplaceUrls) {
      const idx = newActiveUrls.indexOf(badUrl);
      if (idx === -1) continue;

      // 确定淘汰原因
      const unsafeDetail = unsafeDetails.find(d => d.url === badUrl);
      const reason = unsafeDetail
        ? `不安全(${unsafeDetail.threatType})`
        : 'URL使用时长超限';

      // 从池中取一个安全URL（带预检）
      let replacementUrl = null;

      while (newPoolUrls.length > 0) {
        const candidate = newPoolUrls.shift(); // 从顶部取
        const apiKey = this._getRandomItem(apiKeys);

        try {
          const checkResult = await this.checkURLsSafety([candidate], apiKey);
          if (checkResult.length === 0) {
            // 预检通过，使用这个URL
            replacementUrl = candidate;
            break;
          } else {
            // 预检不通过，丢弃并记录
            logger.warn('SafeBrowsing: 备用URL预检不安全，丢弃', {
              url: candidate,
              threat: checkResult[0].threatType
            });
            newRetiredUrls.push({
              url: candidate,
              reason: `预检不安全(${checkResult[0].threatType})`,
              retiredAt: new Date().toISOString()
            });
          }
        } catch (e) {
          // 预检失败（网络问题等），把这个URL放回池尾，不丢弃
          logger.warn('SafeBrowsing: 备用URL预检失败，放回池尾', {
            url: candidate, error: e.message
          });
          newPoolUrls.push(candidate);
          break; // 防止无限循环
        }
      }

      if (replacementUrl) {
        // 执行替换
        newActiveUrls[idx] = replacementUrl;
        newActivatedAt[replacementUrl] = new Date().toISOString();
        delete newActivatedAt[badUrl];
        replacedCount++;

        // 记录淘汰
        newRetiredUrls.push({
          url: badUrl,
          reason: reason,
          replacedBy: replacementUrl,
          retiredAt: new Date().toISOString()
        });

        logEntries.push({
          oldUrl: badUrl,
          newUrl: replacementUrl,
          reason: reason
        });

        logger.warn('SafeBrowsing: URL已替换', {
          old: badUrl.substring(0, 50),
          new: replacementUrl.substring(0, 50),
          reason
        });
      } else {
        // 没有可用的替换URL
        logger.error('SafeBrowsing: 备用URL池已耗尽，无法替换', { badUrl });
        logEntries.push({
          oldUrl: badUrl,
          newUrl: null,
          reason: reason + ' (无可用替换URL)'
        });
      }
    }

    // 保存所有更新
    if (replacedCount > 0) {
      // 更新TARGET_URL（B输入框）
      const targetValue = newActiveUrls.join('\n');
      const targetConfig = await Database.queryOne(
        'SELECT id FROM config_items WHERE key_name = ? AND category = ?',
        ['TARGET_URL', 'domains']
      );
      if (targetConfig) {
        await Database.update('config_items',
          { value: targetValue, updated_by: 'safety_monitor', updated_at: new Date() },
          { id: targetConfig.id }
        );
      }
    }

    // 保存备用URL池（A输入框）
    await this.setConfig('POOL_URLS', newPoolUrls.join('\n'));

    // 保存激活时间
    await this.setConfig('URL_ACTIVATED_AT', JSON.stringify(newActivatedAt));

    // 保存淘汰列表（只保留最近200条）
    if (newRetiredUrls.length > 200) {
      newRetiredUrls = newRetiredUrls.slice(-200);
    }
    await this.setConfig('RETIRED_URLS', JSON.stringify(newRetiredUrls));

    // 写入日志表
    for (const entry of logEntries) {
      try {
        await Database.insert('url_safety_logs', {
          action: 'replace',
          old_url: entry.oldUrl,
          new_url: entry.newUrl,
          reason: entry.reason,
          created_by: 'safety_monitor'
        });
      } catch (e) {
        logger.error('SafeBrowsing: 写入日志失败', { error: e.message });
      }
    }

    return { replacedCount, logEntries, remainingPool: newPoolUrls.length };
  }

  // ============================================
  // 获取监控状态
  // ============================================

  static async getStatus() {
    const config = await this.getAllConfig();

    let nextCheckTime = null;
    if (config.enabled && config.lastCheckTime) {
      const lastCheck = new Date(config.lastCheckTime);
      nextCheckTime = new Date(lastCheck.getTime() + config.checkInterval * 60 * 1000).toISOString();
    }

    // 统计今日数据
    let todayChecks = 0;
    let todayReplaces = 0;
    try {
      const checksResult = await Database.queryOne(
        "SELECT COUNT(*) as cnt FROM url_safety_logs WHERE action = 'check' AND DATE(created_at) = CURDATE()"
      );
      todayChecks = checksResult?.cnt || 0;

      const replacesResult = await Database.queryOne(
        "SELECT COUNT(*) as cnt FROM url_safety_logs WHERE action = 'replace' AND DATE(created_at) = CURDATE()"
      );
      todayReplaces = replacesResult?.cnt || 0;
    } catch (e) {
      // 表可能不存在
    }

    // B输入框URL安全状态（如果最近有检查结果，取最近的）
    const urlStatuses = config.activeUrls.map(url => ({
      url,
      status: 'unknown', // 默认未知，前端可以触发立即检查
      activatedAt: config.urlActivatedAt[url] || null
    }));

    return {
      enabled: config.enabled,
      timerRunning: this.timer !== null,
      isChecking: this.isChecking,
      checkInterval: config.checkInterval,
      activeUrlCount: config.activeUrlCount,
      maxUrlAgeHours: config.maxUrlAgeHours,
      lastCheckTime: config.lastCheckTime || null,
      nextCheckTime,
      consecutiveFailures: this.consecutiveFailures,
      poolUrlsCount: config.poolUrls.length,
      activeUrls: config.activeUrls,
      poolUrls: config.poolUrls,
      apiKeysCount: config.apiKeys.length,
      apiKeys: config.apiKeys,
      urlStatuses,
      todayChecks,
      todayReplaces,
      retiredUrls: config.retiredUrls.slice(-50), // 最近50条
      poolWarning: config.poolUrls.length <= 5 ? `备用URL池仅剩${config.poolUrls.length}个` : null,
      poolEmpty: config.poolUrls.length === 0
    };
  }

  // ============================================
  // 工具方法
  // ============================================

  static _getRandomItem(arr) {
    if (!arr || arr.length === 0) return null;
    return arr[Math.floor(Math.random() * arr.length)];
  }

  static _parseJSON(str, defaultVal) {
    try { return JSON.parse(str); }
    catch { return defaultVal; }
  }

  /**
   * 找出超过最大使用时长的URL
   */
  static _getAgeExpiredUrls(activeUrls, activatedAt, maxHours) {
    const now = Date.now();
    const maxMs = maxHours * 60 * 60 * 1000;
    const expired = [];

    for (const url of activeUrls) {
      const activatedTime = activatedAt[url];
      if (activatedTime) {
        const elapsed = now - new Date(activatedTime).getTime();
        if (elapsed > maxMs) {
          expired.push(url);
        }
      }
    }

    return expired;
  }
}

module.exports = SafeBrowsingService;
