/**
 * ============================================
 * URL安全监控 - 管理API路由
 * ============================================
 */

const express = require('express');
const router = express.Router();
const SafeBrowsingService = require('../../services/safeBrowsingService');
const Database = require('../../database/mysql');
const logger = require('../../utils/logger');

/**
 * GET /api/safety-monitor/status
 * 获取监控状态
 */
router.get('/status', async (req, res) => {
  try {
    const status = await SafeBrowsingService.getStatus();
    res.json({ success: true, data: status });
  } catch (error) {
    logger.error('获取安全监控状态失败', { error: error.message });
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * POST /api/safety-monitor/save-config
 * 保存监控配置（A输入框、B输入框、API Keys、间隔等）
 */
router.post('/save-config', async (req, res) => {
  try {
    const {
      poolUrls,          // A输入框内容
      activeUrls,        // B输入框内容
      activeUrlCount,    // B框URL数量上限
      apiKeys,           // API Key列表
      checkInterval,     // 检查间隔（分钟）
      maxUrlAgeHours     // URL最大使用时长（小时，0=禁用）
    } = req.body;
    const username = req.user?.username || 'admin';

    // 保存各项配置
    if (poolUrls !== undefined) {
      await SafeBrowsingService.setConfig('POOL_URLS', poolUrls, '备用URL池（A输入框）');
    }

    if (activeUrlCount !== undefined) {
      await SafeBrowsingService.setConfig('ACTIVE_URL_COUNT', String(activeUrlCount), 'B输入框URL数量');
    }

    if (apiKeys !== undefined) {
      await SafeBrowsingService.setConfig('API_KEYS', apiKeys, 'Google Safe Browsing API Keys');
    }

    if (checkInterval !== undefined) {
      const interval = Math.max(1, parseInt(checkInterval) || 5);
      await SafeBrowsingService.setConfig('CHECK_INTERVAL_MINUTES', String(interval), '检查间隔（分钟）');

      // 如果监控正在运行，重启定时器
      if (SafeBrowsingService.timer) {
        SafeBrowsingService.startTimer(interval);
      }
    }

    if (maxUrlAgeHours !== undefined) {
      await SafeBrowsingService.setConfig('MAX_URL_AGE_HOURS', String(maxUrlAgeHours), 'URL最大使用时长（小时）');
    }

    // B输入框 → 写入 TARGET_URL
    if (activeUrls !== undefined) {
      const targetConfig = await Database.queryOne(
        'SELECT id FROM config_items WHERE key_name = ? AND category = ?',
        ['TARGET_URL', 'domains']
      );
      if (targetConfig) {
        await Database.update('config_items',
          { value: activeUrls, updated_by: username, updated_at: new Date() },
          { id: targetConfig.id }
        );
      }

      // 记录激活时间
      const urls = activeUrls.split('\n').map(u => u.trim()).filter(u => u.startsWith('http'));
      const currentActivatedAt = SafeBrowsingService._parseJSON(
        await SafeBrowsingService.getConfig('URL_ACTIVATED_AT', '{}'), {}
      );
      for (const url of urls) {
        if (!currentActivatedAt[url]) {
          currentActivatedAt[url] = new Date().toISOString();
        }
      }
      await SafeBrowsingService.setConfig('URL_ACTIVATED_AT', JSON.stringify(currentActivatedAt));
    }

    // 记录操作日志
    await Database.insert('admin_logs', {
      username,
      action: 'safety_monitor_config_update',
      resource: 'safety_monitor',
      details: '更新安全监控配置',
      ip_address: req.ip,
      status: 'success'
    });

    res.json({ success: true, message: '配置已保存' });

  } catch (error) {
    logger.error('保存安全监控配置失败', { error: error.message });
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * POST /api/safety-monitor/start
 * 启动监控
 */
router.post('/start', async (req, res) => {
  try {
    const result = await SafeBrowsingService.start();
    res.json(result);
  } catch (error) {
    logger.error('启动安全监控失败', { error: error.message });
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * POST /api/safety-monitor/stop
 * 停止监控
 */
router.post('/stop', async (req, res) => {
  try {
    const result = await SafeBrowsingService.stop();
    res.json(result);
  } catch (error) {
    logger.error('停止安全监控失败', { error: error.message });
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * POST /api/safety-monitor/check-now
 * 立即执行一次检查
 */
router.post('/check-now', async (req, res) => {
  try {
    const result = await SafeBrowsingService.checkNow();
    res.json({ success: true, data: result });
  } catch (error) {
    logger.error('立即检查失败', { error: error.message });
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * POST /api/safety-monitor/quick-check
 * 快速检查指定URL列表的安全状态（不执行替换）
 */
router.post('/quick-check', async (req, res) => {
  try {
    const { urls } = req.body;
    if (!urls || !Array.isArray(urls) || urls.length === 0) {
      return res.status(400).json({ success: false, message: '请提供URL列表' });
    }

    const config = await SafeBrowsingService.getAllConfig();
    if (config.apiKeys.length === 0) {
      return res.status(400).json({ success: false, message: '未配置API Key' });
    }

    const apiKey = SafeBrowsingService._getRandomItem(config.apiKeys);
    const unsafeResults = await SafeBrowsingService.checkURLsSafety(urls, apiKey);

    const results = urls.map(url => {
      const unsafe = unsafeResults.find(r => r.url === url);
      return {
        url,
        safe: !unsafe,
        threatType: unsafe ? unsafe.threatType : null
      };
    });

    res.json({ success: true, data: results });

  } catch (error) {
    logger.error('快速检查失败', { error: error.message });
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * GET /api/safety-monitor/logs
 * 获取替换日志
 */
router.get('/logs', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;

    const countResult = await Database.queryOne(
      'SELECT COUNT(*) as total FROM url_safety_logs'
    );

    const logs = await Database.query(
      'SELECT * FROM url_safety_logs ORDER BY created_at DESC LIMIT ? OFFSET ?',
      [limit, offset]
    );

    res.json({
      success: true,
      data: logs,
      pagination: {
        page, limit,
        total: countResult?.total || 0,
        totalPages: Math.ceil((countResult?.total || 0) / limit)
      }
    });
  } catch (error) {
    res.json({ success: true, data: [], pagination: { page: 1, total: 0, totalPages: 0 } });
  }
});

/**
 * POST /api/safety-monitor/clear-retired
 * 清空已淘汰URL列表
 */
router.post('/clear-retired', async (req, res) => {
  try {
    await SafeBrowsingService.setConfig('RETIRED_URLS', '[]');
    res.json({ success: true, message: '已淘汰URL列表已清空' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
