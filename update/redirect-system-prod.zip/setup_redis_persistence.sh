#!/bin/bash

# ============================================
# Redis持久化配置脚本
# ============================================

echo "=========================================="
echo "  配置Redis持久化"
echo "=========================================="
echo ""

# 检查Redis是否运行
if ! systemctl is-active --quiet redis; then
    echo "❌ Redis未运行，请先启动Redis"
    exit 1
fi

echo "✅ Redis正在运行"
echo ""

# 备份当前配置
echo "💾 备份当前Redis配置..."
cp /etc/redis/redis.conf /etc/redis/redis.conf.backup_$(date +%s)
echo "✅ 备份完成"
echo ""

# 配置RDB持久化
echo "🔧 配置RDB持久化..."
sed -i 's/^# save 900 1/save 900 1/' /etc/redis/redis.conf
sed -i 's/^# save 300 10/save 300 10/' /etc/redis/redis.conf
sed -i 's/^# save 60 10000/save 60 10000/' /etc/redis/redis.conf

# 确保dir和dbfilename配置正确
if ! grep -q "^dir /var/lib/redis" /etc/redis/redis.conf; then
    echo "dir /var/lib/redis" >> /etc/redis/redis.conf
fi
if ! grep -q "^dbfilename dump.rdb" /etc/redis/redis.conf; then
    echo "dbfilename dump.rdb" >> /etc/redis/redis.conf
fi

echo "✅ RDB配置完成"
echo ""

# 配置AOF持久化
echo "🔧 配置AOF持久化..."
sed -i 's/^appendonly no/appendonly yes/' /etc/redis/redis.conf
if ! grep -q "^appendonly yes" /etc/redis/redis.conf; then
    echo "appendonly yes" >> /etc/redis/redis.conf
fi

if ! grep -q "^appendfsync everysec" /etc/redis/redis.conf; then
    echo "appendfsync everysec" >> /etc/redis/redis.conf
fi

echo "✅ AOF配置完成"
echo ""

# 创建数据目录
echo "📁 确保数据目录存在..."
mkdir -p /var/lib/redis
chown redis:redis /var/lib/redis
chmod 750 /var/lib/redis
echo "✅ 数据目录配置完成"
echo ""

# 重启Redis
echo "🔄 重启Redis..."
systemctl restart redis

sleep 2

# 验证Redis状态
if systemctl is-active --quiet redis; then
    echo "✅ Redis重启成功"
else
    echo "❌ Redis重启失败"
    exit 1
fi

echo ""
echo "=========================================="
echo "  验证配置"
echo "=========================================="
echo ""

# 检查RDB配置
echo "📋 RDB配置："
redis-cli CONFIG GET save
echo ""

# 检查AOF配置
echo "📋 AOF配置："
redis-cli CONFIG GET appendonly
redis-cli CONFIG GET appendfsync
echo ""

# 检查数据目录
echo "📁 数据目录："
redis-cli CONFIG GET dir
echo ""

# 检查持久化文件
echo "📄 持久化文件："
ls -lh /var/lib/redis/
echo ""

echo "=========================================="
echo "  ✅ Redis持久化配置完成！"
echo "=========================================="
echo ""
echo "配置说明："
echo "1. ✅ RDB持久化已启用（定期快照）"
echo "2. ✅ AOF持久化已启用（每秒同步）"
echo "3. ✅ 数据保存在 /var/lib/redis/"
echo "4. ✅ 重启后数据会自动恢复"
echo ""
echo "测试持久化："
echo "  redis-cli SET test_key 'test_value'"
echo "  systemctl restart redis"
echo "  redis-cli GET test_key  # 应该返回 'test_value'"
echo ""
