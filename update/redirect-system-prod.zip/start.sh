#!/bin/bash

echo "=================================="
echo "反检测重定向系统 - 快速启动"
echo "=================================="
echo ""

# 检查是否安装了依赖
if [ ! -d "node_modules" ]; then
    echo "📦 首次运行，正在安装依赖..."
    npm install
    echo ""
fi

# 检查.env文件
if [ ! -f ".env" ]; then
    echo "⚠️  警告：未找到.env文件"
    echo "请根据 .env.example 创建 .env 文件并配置数据库信息"
    echo ""
    read -p "是否继续？(y/n) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo "🚀 启动选项："
echo "1. 启动主服务 (端口3000)"
echo "2. 启动管理后台 (端口3001)"
echo "3. 同时启动两个服务"
echo ""
read -p "请选择 (1-3): " choice

case $choice in
    1)
        echo "🚀 启动主服务..."
        npm start
        ;;
    2)
        echo "🚀 启动管理后台..."
        npm run admin
        ;;
    3)
        echo "🚀 同时启动主服务和管理后台..."
        npm run dev:all
        ;;
    *)
        echo "❌ 无效的选择"
        exit 1
        ;;
esac
