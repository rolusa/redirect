-- 重定向域名管理表
CREATE TABLE IF NOT EXISTS redirect_domains (
    id INT AUTO_INCREMENT PRIMARY KEY,
    domain_name VARCHAR(255) NOT NULL UNIQUE COMMENT '域名',
    domain_type ENUM('main', 'wildcard') DEFAULT 'main' COMMENT '域名类型: main=主域名, wildcard=通配符',
    ssl_enabled BOOLEAN DEFAULT FALSE COMMENT '是否启用SSL',
    ssl_provider ENUM('letsencrypt', 'cloudflare', 'manual') DEFAULT 'letsencrypt' COMMENT 'SSL提供商',
    ssl_issued_date DATETIME COMMENT 'SSL签发时间',
    ssl_expiry_date DATETIME COMMENT 'SSL过期时间',
    days_left INT COMMENT '剩余天数',
    cert_path VARCHAR(500) COMMENT '证书路径',
    key_path VARCHAR(500) COMMENT '私钥路径',
    nginx_config_path VARCHAR(500) COMMENT 'Nginx配置文件路径',
    is_active BOOLEAN DEFAULT TRUE COMMENT '是否激活',
    is_cloudflare BOOLEAN DEFAULT FALSE COMMENT '是否使用CloudFlare',
    cloudflare_zone_id VARCHAR(100) COMMENT 'CloudFlare Zone ID',
    notes TEXT COMMENT '备注',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_domain_name (domain_name),
    INDEX idx_is_active (is_active),
    INDEX idx_ssl_expiry (ssl_expiry_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='重定向域名管理表';

-- 插入示例数据
INSERT INTO redirect_domains (domain_name, domain_type, is_active, notes) VALUES
('example.com', 'main', TRUE, '示例主域名'),
('*.example.com', 'wildcard', TRUE, '示例通配符域名');
