/**
 * ============================================
 * 应用入口文件
 * ============================================
 * 功能：
 * 1. 初始化Express应用
 * 2. 配置中间件
 * 3. 初始化数据库连接
 * 4. 加载路由
 * 5. 启动HTTP服务器
 * ============================================
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { config, validateConfig, printConfigSummary } = require('./config');
const logger = require('./utils/logger');
const Database = require('./database/mysql');
const Redis = require('./database/redis'); // ← 添加Redis引用
const redirectRoutes = require('./routes/redirect');
const refreshRoutes = require('./routes/refresh'); // ← 添加配置刷新API
const {
  errorHandler,
  notFoundHandler,
  timeoutHandler,
} = require('./middleware/errorHandler');

// 创建Express应用
const app = express();

/**
 * 初始化应用
 */
async function initialize() {
  try {
    // 1. 验证配置
    logger.info('验证配置...');
    validateConfig();
    printConfigSummary();

    // 2. 初始化数据库
    logger.info('连接数据库...');
    
    // ✅ 添加Redis初始化 - 使用 await 等待连接完成
    await Redis.init();
    
    // ✅ MySQL初始化
    await Database.initialize();

    // 3. 测试ipregistry API（可选）
    if (config.debug.enabled) {
      logger.info('测试ipregistry API...');
      const IPRegistryService = require('./services/ipRegistry');
      const apiTest = await IPRegistryService.testAPIConnection();
      if (apiTest.success) {
        logger.info('ipregistry API测试成功', { duration: apiTest.duration });
      } else {
        logger.warn('ipregistry API测试失败', { message: apiTest.message });
      }
    }

    logger.info('初始化完成');
  } catch (error) {
    logger.error('初始化失败', {
      error: error.message,
      stack: error.stack,
    });
    throw error;
  }
}

/**
 * 配置中间件
 */
function setupMiddlewares() {
  // 1. 安全中间件
  app.use(helmet({
    contentSecurityPolicy: false, // 允许重定向
    crossOriginEmbedderPolicy: false,
  }));

  // 2. CORS配置
  app.use(cors({
    origin: '*', // 开发环境允许所有来源
    methods: ['GET', 'POST'],
  }));

  // 3. 请求体解析
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // 4. 设置信任代理（如果在Nginx后面）
  app.set('trust proxy', true);

  // 5. 请求日志中间件
  app.use(logger.requestLogger());

  // 6. 请求超时
  app.use(timeoutHandler(30000)); // 30秒超时

  logger.info('中间件配置完成');
}

/**
 * 配置路由
 */
function setupRoutes() {
  // 挂载主要路由
  app.use('/', redirectRoutes);
  
  // 挂载配置刷新API路由
  app.use('/api', refreshRoutes); // ← 添加配置刷新API路由

  // 404处理
  app.use(notFoundHandler);

  // 错误处理（必须放在最后）
  app.use(errorHandler);

  logger.info('路由配置完成');
}

/**
 * 启动服务器
 */
function startServer() {
  const port = config.server.port;

  // 强制使用 0.0.0.0 监听所有接口
  const server = app.listen(port, '0.0.0.0', () => {
    const addresses = [
      `http://127.0.0.1:${port}`,
      `http://localhost:${port}`,
      `http://0.0.0.0:${port}`
    ];
    
    logger.info('='.repeat(60));
    logger.info(`服务器启动成功`);
    logger.info(`监听地址：`);
    addresses.forEach(addr => logger.info(`  - ${addr}`));
    logger.info(`环境: ${config.server.env}`);
    logger.info(`PID: ${process.pid}`);
    logger.info('='.repeat(60));
    
    // 在控制台也输出（方便查看）
    console.log('\n✅ 服务器已启动！');
    console.log('📍 访问地址：');
    addresses.forEach(addr => console.log(`   ${addr}`));
    console.log('');
  });

  // 优雅关闭
  process.on('SIGTERM', () => gracefulShutdown(server, 'SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown(server, 'SIGINT'));

  return server;
}

/**
 * 优雅关闭
 * @param {Object} server - HTTP服务器实例
 * @param {string} signal - 信号名称
 */
async function gracefulShutdown(server, signal) {
  logger.info(`收到${signal}信号，开始优雅关闭...`);

  // 停止接受新连接
  server.close(async () => {
    logger.info('HTTP服务器已关闭');

    try {
      // 关闭数据库连接
      await Database.close();
      logger.info('数据库连接已关闭');

      // ✅ 修复：关闭Redis连接 - 使用正确的路径
      await Redis.close();
      logger.info('Redis连接已关闭');

      logger.info('所有连接已关闭，进程退出');
      process.exit(0);
    } catch (error) {
      logger.error('关闭过程出错', { error: error.message });
      process.exit(1);
    }
  });

  // 30秒后强制退出
  setTimeout(() => {
    logger.error('强制关闭超时，强制退出');
    process.exit(1);
  }, 30000);
}

/**
 * 未捕获异常处理
 */
process.on('uncaughtException', (error) => {
  logger.error('未捕获的异常', {
    error: error.message,
    stack: error.stack,
  });

  // 记录错误后退出
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('未处理的Promise拒绝', {
    reason: reason,
    promise: promise,
  });
});

/**
 * 主函数
 */
async function main() {
  try {
    // 显示启动信息
    console.log('\n');
    console.log('='.repeat(60));
    console.log('   反检测重定向系统 v1.0.0');
    console.log('='.repeat(60));
    console.log('\n');

    // 初始化
    await initialize();

    // 配置中间件
    setupMiddlewares();

    // 配置路由
    setupRoutes();

    // 启动服务器
    startServer();

  } catch (error) {
    logger.error('应用启动失败', {
      error: error.message,
      stack: error.stack,
    });
    process.exit(1);
  }
}

// 启动应用
if (require.main === module) {
  main();
}

// 导出app供测试使用
module.exports = app;
