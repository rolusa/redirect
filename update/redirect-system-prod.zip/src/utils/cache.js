/**
 * ============================================
 * Redis缓存工具
 * ============================================
 * 功能：
 * 1. 封装Redis操作
 * 2. 提供get/set/del等基础操作
 * 3. 支持自动序列化/反序列化
 * 4. 连接管理和错误处理
 * ============================================
 */

const Redis = require('ioredis');
const { config } = require('../config');
const logger = require('./logger');

/**
 * 创建Redis客户端
 */
const redis = new Redis({
  host: config.redis.host,
  port: config.redis.port,
  password: config.redis.password || undefined,
  db: config.redis.db,
  keyPrefix: config.redis.keyPrefix,
  retryStrategy(times) {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3,
});

/**
 * Redis连接事件处理
 */
redis.on('connect', () => {
  logger.info('Redis连接成功', {
    host: config.redis.host,
    port: config.redis.port,
    db: config.redis.db,
  });
});

redis.on('error', (err) => {
  logger.error('Redis错误', {
    error: err.message,
    host: config.redis.host,
    port: config.redis.port,
  });
});

redis.on('close', () => {
  logger.warn('Redis连接关闭');
});

/**
 * 缓存工具类
 */
class Cache {
  /**
   * 获取缓存
   * @param {string} key - 缓存键
   * @returns {Promise<any>} - 缓存值（自动反序列化）
   */
  static async get(key) {
    try {
      const value = await redis.get(key);
      if (!value) {
        return null;
      }

      // 尝试解析JSON
      try {
        return JSON.parse(value);
      } catch (e) {
        // 如果不是JSON，返回原始字符串
        return value;
      }
    } catch (error) {
      logger.error('缓存读取失败', { key, error: error.message });
      return null;
    }
  }

  /**
   * 设置缓存
   * @param {string} key - 缓存键
   * @param {any} value - 缓存值（自动序列化）
   * @param {number} ttl - 过期时间（秒），默认不过期
   * @returns {Promise<boolean>} - 是否成功
   */
  static async set(key, value, ttl = null) {
    try {
      // 序列化值
      const serialized = typeof value === 'string'
        ? value
        : JSON.stringify(value);

      // 设置缓存
      if (ttl) {
        await redis.setex(key, ttl, serialized);
      } else {
        await redis.set(key, serialized);
      }

      return true;
    } catch (error) {
      logger.error('缓存写入失败', { key, error: error.message });
      return false;
    }
  }

  /**
   * 删除缓存
   * @param {string} key - 缓存键
   * @returns {Promise<boolean>} - 是否成功
   */
  static async del(key) {
    try {
      await redis.del(key);
      return true;
    } catch (error) {
      logger.error('缓存删除失败', { key, error: error.message });
      return false;
    }
  }

  /**
   * 检查键是否存在
   * @param {string} key - 缓存键
   * @returns {Promise<boolean>} - 是否存在
   */
  static async exists(key) {
    try {
      const result = await redis.exists(key);
      return result === 1;
    } catch (error) {
      logger.error('缓存检查失败', { key, error: error.message });
      return false;
    }
  }

  /**
   * 增加计数器
   * @param {string} key - 缓存键
   * @param {number} increment - 增加值，默认1
   * @returns {Promise<number>} - 增加后的值
   */
  static async incr(key, increment = 1) {
    try {
      return await redis.incrby(key, increment);
    } catch (error) {
      logger.error('缓存递增失败', { key, error: error.message });
      return 0;
    }
  }

  /**
   * 设置过期时间
   * @param {string} key - 缓存键
   * @param {number} ttl - 过期时间（秒）
   * @returns {Promise<boolean>} - 是否成功
   */
  static async expire(key, ttl) {
    try {
      await redis.expire(key, ttl);
      return true;
    } catch (error) {
      logger.error('设置过期时间失败', { key, ttl, error: error.message });
      return false;
    }
  }

  /**
   * 获取剩余过期时间
   * @param {string} key - 缓存键
   * @returns {Promise<number>} - 剩余秒数，-1表示永不过期，-2表示不存在
   */
  static async ttl(key) {
    try {
      return await redis.ttl(key);
    } catch (error) {
      logger.error('获取TTL失败', { key, error: error.message });
      return -2;
    }
  }

  /**
   * 批量获取
   * @param {string[]} keys - 缓存键数组
   * @returns {Promise<Object>} - 键值对对象
   */
  static async mget(keys) {
    try {
      const values = await redis.mget(keys);
      const result = {};

      keys.forEach((key, index) => {
        const value = values[index];
        if (value) {
          try {
            result[key] = JSON.parse(value);
          } catch (e) {
            result[key] = value;
          }
        }
      });

      return result;
    } catch (error) {
      logger.error('批量读取失败', { keys, error: error.message });
      return {};
    }
  }

  /**
   * 模式匹配删除
   * @param {string} pattern - 匹配模式，如 "user:*"
   * @returns {Promise<number>} - 删除的键数量
   */
  static async delPattern(pattern) {
    try {
      const keys = await redis.keys(config.redis.keyPrefix + pattern);
      if (keys.length === 0) {
        return 0;
      }

      // 移除前缀后删除
      const keysWithoutPrefix = keys.map(k =>
        k.replace(config.redis.keyPrefix, '')
      );
      await redis.del(...keysWithoutPrefix);
      return keys.length;
    } catch (error) {
      logger.error('模式删除失败', { pattern, error: error.message });
      return 0;
    }
  }

  /**
   * 清空所有缓存（谨慎使用！）
   * @returns {Promise<boolean>} - 是否成功
   */
  static async flush() {
    try {
      await redis.flushdb();
      logger.warn('缓存已清空');
      return true;
    } catch (error) {
      logger.error('清空缓存失败', { error: error.message });
      return false;
    }
  }

  /**
   * 获取Redis客户端（用于高级操作）
   * @returns {Redis} - Redis客户端实例
   */
  static getClient() {
    return redis;
  }

  /**
   * 关闭Redis连接
   */
  static async close() {
    try {
      await redis.quit();
      logger.info('Redis连接已关闭');
    } catch (error) {
      logger.error('关闭Redis连接失败', { error: error.message });
    }
  }

  /**
   * 获取缓存统计信息
   * @returns {Promise<Object>} - 统计信息
   */
  static async getStats() {
    try {
      const info = await redis.info('stats');
      const dbSize = await redis.dbsize();

      return {
        dbSize,
        info,
      };
    } catch (error) {
      logger.error('获取缓存统计失败', { error: error.message });
      return null;
    }
  }
}

// 优雅退出时关闭连接
process.on('SIGINT', async () => {
  await Cache.close();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await Cache.close();
  process.exit(0);
});

module.exports = Cache;
