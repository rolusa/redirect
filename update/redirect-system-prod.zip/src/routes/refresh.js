/**
 * ============================================
 * 配置刷新API路由
 * ============================================
 * 功能：
 * 1. 提供配置刷新API端点
 * 2. 清空所有过滤器的配置缓存
 * 3. 使配置修改立即生效，无需重启服务
 * ============================================
 */

const express = require('express');
const router = express.Router();
const logger = require('../utils/logger');

/**
 * POST /api/refresh-config
 * 刷新所有过滤器的配置缓存
 */
router.post('/refresh-config', async (req, res) => {
  try {
    logger.info('🔄 ========== 开始刷新配置缓存 ==========');

    let clearedCount = 0;
    const results = [];

    // 注意：这些过滤器导出的是实例，不是类
    // 所以直接 require 就能得到实例，不需要 new
    
    try {
      // 1. Security Filter
      const securityFilter = require('../filters/securityFilter');
      if (typeof securityFilter.clearCache === 'function') {
        securityFilter.clearCache();
        clearedCount++;
        results.push({ filter: 'Security', status: 'cleared' });
        logger.info('✅ Security Filter: 缓存已清空');
      }
    } catch (error) {
      results.push({ filter: 'Security', status: 'error', error: error.message });
      logger.error('❌ Security Filter: 清空缓存失败', error);
    }

    try {
      // 2. UserAgent Filter
      const userAgentFilter = require('../filters/userAgentFilter');
      if (typeof userAgentFilter.clearCache === 'function') {
        userAgentFilter.clearCache();
        clearedCount++;
        results.push({ filter: 'UserAgent', status: 'cleared' });
        logger.info('✅ UserAgent Filter: 缓存已清空');
      }
    } catch (error) {
      results.push({ filter: 'UserAgent', status: 'error', error: error.message });
      logger.error('❌ UserAgent Filter: 清空缓存失败', error);
    }

    try {
      // 3. Company Filter
      const companyFilter = require('../filters/companyFilter');
      if (typeof companyFilter.clearCache === 'function') {
        companyFilter.clearCache();
        clearedCount++;
        results.push({ filter: 'Company', status: 'cleared' });
        logger.info('✅ Company Filter: 缓存已清空');
      }
    } catch (error) {
      results.push({ filter: 'Company', status: 'error', error: error.message });
      logger.error('❌ Company Filter: 清空缓存失败', error);
    }

    try {
      // 4. Connection Filter
      const connectionFilter = require('../filters/connectionFilter');
      if (typeof connectionFilter.clearCache === 'function') {
        connectionFilter.clearCache();
        clearedCount++;
        results.push({ filter: 'Connection', status: 'cleared' });
        logger.info('✅ Connection Filter: 缓存已清空');
      }
    } catch (error) {
      results.push({ filter: 'Connection', status: 'error', error: error.message });
      logger.error('❌ Connection Filter: 清空缓存失败', error);
    }

    logger.info(`🎉 配置刷新完成！成功清空 ${clearedCount} 个过滤器的缓存`);
    logger.info('=========================================');

    res.json({
      success: true,
      message: `Successfully cleared ${clearedCount} filter caches`,
      clearedCount,
      results,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logger.error('❌ 配置刷新失败:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to refresh config',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

/**
 * GET /api/refresh-config/status
 * 查看配置刷新API状态
 */
router.get('/refresh-config/status', (req, res) => {
  res.json({
    success: true,
    message: 'Config refresh API is running',
    endpoint: 'POST /api/refresh-config',
    timestamp: new Date().toISOString()
  });
});

module.exports = router;
