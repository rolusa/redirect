/**
 * Company 公司类型过滤器
 * 用于过滤基于公司类型、名称、ASN的访问
 * 
 * 功能：
 * - Company类型白名单/黑名单（business/edu/government/hosting/isp）
 * - 公司名称白名单/黑名单
 * - ASN号白名单/黑名单
 * 
 * 版本: 1.0
 * 日期: 2025-11-22
 */

const logger = require('../utils/logger');
const Database = require('../database/mysql');

class CompanyFilter {
  constructor() {
    // 配置缓存
    this.configCache = null;
    this.cacheExpiry = 0;
    this.cacheTTL = 10000; // 缓存10秒

    // Company类型定义
    this.companyTypes = {
      business: '商业公司',
      edu: '教育机构',
      government: '政府机构',
      hosting: '托管服务商',
      isp: '互联网服务提供商'
    };

    // Connection类型定义
    this.connectionTypes = {
      wired: '有线连接',
      wireless: '无线连接',
      cellular: '蜂窝网络'
    };
  }

  /**
   * 获取Company配置（带缓存）
   * @returns {Promise<Object>} Company配置对象
   */
  async getConfig() {
    const now = Date.now();
    
    // 使用缓存
    if (this.configCache && now < this.cacheExpiry) {
      return this.configCache;
    }

    try {
      const config = {
        mode: 'off',
        allowedTypes: [],
        blockedTypes: [],
        allowedNames: [],
        blockedNames: [],
        allowedASN: [],
        blockedASN: []
      };

      // 从数据库读取配置
      const configItems = await Database.query(
        'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
        ['company']
      );

      // 解析配置
      configItems.forEach(item => {
        const value = item.value || '';
        
        switch (item.key_name) {
          case 'COMPANY_MODE':
            config.mode = value;
            break;
          case 'ALLOWED_TYPES':
            config.allowedTypes = value.split(',').map(t => t.trim()).filter(t => t);
            break;
          case 'BLOCKED_TYPES':
            config.blockedTypes = value.split(',').map(t => t.trim()).filter(t => t);
            break;
          case 'ALLOWED_NAMES':
            config.allowedNames = value.split(',').map(n => n.trim().toLowerCase()).filter(n => n);
            break;
          case 'BLOCKED_NAMES':
            config.blockedNames = value.split(',').map(n => n.trim().toLowerCase()).filter(n => n);
            break;
          case 'ALLOWED_ASN':
            config.allowedASN = value.split(',').map(a => parseInt(a.trim())).filter(a => !isNaN(a));
            break;
          case 'BLOCKED_ASN':
            config.blockedASN = value.split(',').map(a => parseInt(a.trim())).filter(a => !isNaN(a));
            break;
        }
      });

      // 更新缓存
      this.configCache = config;
      this.cacheExpiry = now + this.cacheTTL;

      logger.debug('Company Filter: Loaded config', { config });
      return config;

    } catch (error) {
      logger.error('Company Filter: Failed to load config', { error: error.message });
      
      // 降级到默认配置（关闭状态）
      return {
        mode: 'off',
        allowedTypes: [],
        blockedTypes: [],
        allowedNames: [],
        blockedNames: [],
        allowedASN: [],
        blockedASN: []
      };
    }
  }

  /**
   * 执行Company过滤
   * @param {Object} ipInfo - IP信息对象
   * @returns {Promise<Object>} { passed: boolean, reason: string, details: object }
   */
  async filter(ipInfo) {
    try {
      const config = await this.getConfig();

      // 如果过滤器关闭，直接通过
      if (config.mode === 'off') {
        return {
          passed: true,
          reason: 'Company filter is off',
          details: { mode: 'off' }
        };
      }

      const company = ipInfo?.company || {};
      const connection = ipInfo?.connection || {};
      const companyName = (company.name || '').toLowerCase();
      const companyType = (company.type || '').toLowerCase();
      const asn = connection.asn;

      logger.debug('Company Filter: Processing', {
        ip: ipInfo.ip,
        company: companyName,
        type: companyType,
        asn: asn
      });

      // 1. 优先检查ASN黑名单
      if (asn && config.blockedASN.length > 0 && config.blockedASN.includes(asn)) {
        logger.warn('Company Filter: ASN in blacklist', {
          ip: ipInfo.ip,
          asn: asn
        });
        return {
          passed: false,
          reason: `ASN ${asn} is in blacklist`,
          details: {
            type: 'asn_blocked',
            asn: asn
          }
        };
      }

      // 2. 检查ASN白名单（如果配置了）
      if (config.allowedASN.length > 0) {
        if (!asn || !config.allowedASN.includes(asn)) {
          logger.info('Company Filter: ASN not in whitelist', {
            ip: ipInfo.ip,
            asn: asn
          });
          return {
            passed: false,
            reason: 'ASN not in whitelist',
            details: {
              type: 'asn_not_allowed',
              asn: asn
            }
          };
        }
      }

      // 3. 检查公司名称黑名单
      if (companyName && config.blockedNames.length > 0) {
        const isBlocked = config.blockedNames.some(blocked => 
          companyName.includes(blocked) || blocked.includes(companyName)
        );
        
        if (isBlocked) {
          logger.warn('Company Filter: Company name in blacklist', {
            ip: ipInfo.ip,
            company: companyName
          });
          return {
            passed: false,
            reason: `Company "${company.name}" is in blacklist`,
            details: {
              type: 'company_blocked',
              company: company.name
            }
          };
        }
      }

      // 4. 检查公司名称白名单（如果配置了）
      if (config.allowedNames.length > 0) {
        if (!companyName) {
          return {
            passed: false,
            reason: 'Company name required but not available',
            details: {
              type: 'company_missing'
            }
          };
        }

        const isAllowed = config.allowedNames.some(allowed => 
          companyName.includes(allowed) || allowed.includes(companyName)
        );

        if (!isAllowed) {
          logger.info('Company Filter: Company name not in whitelist', {
            ip: ipInfo.ip,
            company: companyName
          });
          return {
            passed: false,
            reason: 'Company not in whitelist',
            details: {
              type: 'company_not_allowed',
              company: company.name
            }
          };
        }
      }

      // 5. 白名单模式 - 检查Company类型
      if (config.mode === 'whitelist') {
        if (!companyType) {
          logger.info('Company Filter: Company type missing in whitelist mode', {
            ip: ipInfo.ip
          });
          return {
            passed: false,
            reason: 'Company type required in whitelist mode',
            details: {
              type: 'type_missing',
              mode: 'whitelist'
            }
          };
        }

        if (!config.allowedTypes.includes(companyType)) {
          logger.info('Company Filter: Company type not in whitelist', {
            ip: ipInfo.ip,
            type: companyType
          });
          return {
            passed: false,
            reason: `Company type "${companyType}" not in whitelist`,
            details: {
              type: 'type_not_allowed',
              companyType: companyType
            }
          };
        }
      }

      // 6. 黑名单模式 - 检查Company类型
      if (config.mode === 'blacklist') {
        if (companyType && config.blockedTypes.includes(companyType)) {
          logger.warn('Company Filter: Company type in blacklist', {
            ip: ipInfo.ip,
            type: companyType
          });
          return {
            passed: false,
            reason: `Company type "${companyType}" is in blacklist`,
            details: {
              type: 'type_blocked',
              companyType: companyType
            }
          };
        }
      }

      // 全部检查通过
      logger.debug('Company Filter: Passed', {
        ip: ipInfo.ip,
        company: companyName,
        type: companyType
      });

      return {
        passed: true,
        reason: 'Company filter passed',
        details: {
          mode: config.mode,
          company: company.name,
          type: companyType,
          asn: asn
        }
      };

    } catch (error) {
      logger.error('Company Filter: Error during filtering', {
        error: error.message,
        stack: error.stack,
        ip: ipInfo?.ip
      });

      // 出错时采取保守策略：允许通过（避免误杀）
      return {
        passed: true,
        reason: 'Company filter error - allowing by default',
        details: {
          error: error.message
        }
      };
    }
  }

  /**
   * 清除配置缓存
   */
  clearCache() {
    this.configCache = null;
    this.cacheExpiry = 0;
    logger.info('Company Filter: Cache cleared');
  }

  /**
   * 获取配置摘要（用于管理后台显示）
   * @returns {Promise<Object>} 配置摘要
   */
  async getConfigSummary() {
    const config = await this.getConfig();
    
    return {
      mode: config.mode,
      allowedTypesCount: config.allowedTypes.length,
      blockedTypesCount: config.blockedTypes.length,
      allowedNamesCount: config.allowedNames.length,
      blockedNamesCount: config.blockedNames.length,
      allowedASNCount: config.allowedASN.length,
      blockedASNCount: config.blockedASN.length,
      config: config
    };
  }
}

module.exports = new CompanyFilter();
