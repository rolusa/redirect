/**
 * Connection 连接类型过滤器
 * 用于过滤基于连接类型的访问
 * 
 * 功能：
 * - Connection类型白名单/黑名单（wired/wireless/cellular）
 * 
 * 版本: 1.0
 * 日期: 2025-11-22
 */

const logger = require('../utils/logger');
const Database = require('../database/mysql');

class ConnectionFilter {
  constructor() {
    // 配置缓存
    this.configCache = null;
    this.cacheExpiry = 0;
    this.cacheTTL = 10000; // 缓存10秒

    // Connection类型定义
    this.connectionTypes = {
      wired: '有线连接',
      wireless: '无线连接',
      cellular: '蜂窝网络'
    };
  }

  /**
   * 获取Connection配置（带缓存）
   * @returns {Promise<Object>} Connection配置对象
   */
  async getConfig() {
    const now = Date.now();
    
    // 使用缓存
    if (this.configCache && now < this.cacheExpiry) {
      return this.configCache;
    }

    try {
      const config = {
        mode: 'off',
        allowedTypes: [],
        blockedTypes: []
      };

      // 从数据库读取配置
      const configItems = await Database.query(
        'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
        ['connection']
      );

      // 解析配置
      configItems.forEach(item => {
        const value = item.value || '';
        
        switch (item.key_name) {
          case 'CONNECTION_MODE':
            config.mode = value;
            break;
          case 'ALLOWED_TYPES':
            config.allowedTypes = value.split(',').map(t => t.trim()).filter(t => t);
            break;
          case 'BLOCKED_TYPES':
            config.blockedTypes = value.split(',').map(t => t.trim()).filter(t => t);
            break;
        }
      });

      // 更新缓存
      this.configCache = config;
      this.cacheExpiry = now + this.cacheTTL;

      logger.debug('Connection Filter: Loaded config', { config });
      return config;

    } catch (error) {
      logger.error('Connection Filter: Failed to load config', { error: error.message });
      
      // 降级到默认配置（关闭状态）
      return {
        mode: 'off',
        allowedTypes: [],
        blockedTypes: []
      };
    }
  }

  /**
   * 执行Connection过滤
   * @param {Object} ipInfo - IP信息对象
   * @returns {Promise<Object>} { passed: boolean, reason: string, details: object }
   */
  async filter(ipInfo) {
    try {
      const config = await this.getConfig();

      // 如果过滤器关闭，直接通过
      if (config.mode === 'off') {
        return {
          passed: true,
          reason: 'Connection filter is off',
          details: { mode: 'off' }
        };
      }

      const connection = ipInfo?.connection || {};
      const connectionType = (connection.type || '').toLowerCase();

      logger.debug('Connection Filter: Processing', {
        ip: ipInfo.ip,
        type: connectionType
      });

      // 白名单模式
      if (config.mode === 'whitelist') {
        if (!connectionType) {
          logger.info('Connection Filter: Connection type missing in whitelist mode', {
            ip: ipInfo.ip
          });
          return {
            passed: false,
            reason: 'Connection type required in whitelist mode',
            details: {
              type: 'type_missing',
              mode: 'whitelist'
            }
          };
        }

        if (!config.allowedTypes.includes(connectionType)) {
          logger.info('Connection Filter: Connection type not in whitelist', {
            ip: ipInfo.ip,
            type: connectionType
          });
          return {
            passed: false,
            reason: `Connection type "${connectionType}" not in whitelist`,
            details: {
              type: 'type_not_allowed',
              connectionType: connectionType
            }
          };
        }
      }

      // 黑名单模式
      if (config.mode === 'blacklist') {
        if (connectionType && config.blockedTypes.includes(connectionType)) {
          logger.warn('Connection Filter: Connection type in blacklist', {
            ip: ipInfo.ip,
            type: connectionType
          });
          return {
            passed: false,
            reason: `Connection type "${connectionType}" is in blacklist`,
            details: {
              type: 'type_blocked',
              connectionType: connectionType
            }
          };
        }
      }

      // 全部检查通过
      logger.debug('Connection Filter: Passed', {
        ip: ipInfo.ip,
        type: connectionType
      });

      return {
        passed: true,
        reason: 'Connection filter passed',
        details: {
          mode: config.mode,
          type: connectionType
        }
      };

    } catch (error) {
      logger.error('Connection Filter: Error during filtering', {
        error: error.message,
        stack: error.stack,
        ip: ipInfo?.ip
      });

      // 出错时采取保守策略：允许通过
      return {
        passed: true,
        reason: 'Connection filter error - allowing by default',
        details: {
          error: error.message
        }
      };
    }
  }

  /**
   * 清除配置缓存
   */
  clearCache() {
    this.configCache = null;
    this.cacheExpiry = 0;
    logger.info('Connection Filter: Cache cleared');
  }

  /**
   * 获取配置摘要（用于管理后台显示）
   * @returns {Promise<Object>} 配置摘要
   */
  async getConfigSummary() {
    const config = await this.getConfig();
    
    return {
      mode: config.mode,
      allowedTypesCount: config.allowedTypes.length,
      blockedTypesCount: config.blockedTypes.length,
      config: config
    };
  }
}

module.exports = new ConnectionFilter();
