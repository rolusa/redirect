/**
 * 安全过滤器 - 增强版
 * 检测和过滤潜在的安全威胁访问
 * 版本: 2.0 (增强版 - Security 11项独立配置)
 * 更新日期: 2025-11-22
 * 
 * 新增功能:
 * - 11个Security检测项独立配置
 * - 每项支持三种处理方式: reject/allow/pass
 * - 动态从数据库读取配置
 * - 保持向后兼容
 */

const logger = require('../utils/logger');
const Database = require('../database/mysql');

class SecurityFilter {
  constructor() {
    // Security 11项检测类型定义
    this.securityTypes = {
      abuser: { key: 'is_abuser', label: '滥用源', configKey: 'ABUSER_ACTION' },
      attacker: { key: 'is_attacker', label: '攻击者', configKey: 'ATTACKER_ACTION' },
      bogon: { key: 'is_bogon', label: '黑洞地址', configKey: 'BOGON_ACTION' },
      cloud_provider: { key: 'is_cloud_provider', label: '云服务商', configKey: 'CLOUD_PROVIDER_ACTION' },
      proxy: { key: 'is_proxy', label: '代理', configKey: 'PROXY_ACTION' },
      relay: { key: 'is_relay', label: '中继', configKey: 'RELAY_ACTION' },
      tor: { key: 'is_tor', label: 'Tor中继', configKey: 'TOR_ACTION' },
      tor_exit: { key: 'is_tor_exit', label: 'Tor出口节点', configKey: 'TOR_EXIT_ACTION' },
      vpn: { key: 'is_vpn', label: 'VPN', configKey: 'VPN_ACTION' },
      anonymous: { key: 'is_anonymous', label: '匿名', configKey: 'ANONYMOUS_ACTION' },
      threat: { key: 'is_threat', label: '威胁', configKey: 'THREAT_ACTION' }
    };

    // 默认配置（向后兼容）
    this.defaultSecurityConfig = {
      blockVpn: true,
      blockProxy: true,
      blockTor: true,
      blockCloudProvider: false, // 默认允许云服务商
      blockAbuser: true,
      blockAttacker: true,
      blockAnonymous: true,
      blockThreat: true,
      allowHosting: false
    };

    // 配置缓存（减少数据库查询）
    this.configCache = null;
    this.cacheExpiry = 0;
    this.cacheTTL = 10000; // 缓存10秒
  }

  /**
   * 获取Security配置（带缓存）
   * @returns {Promise<Object>} Security配置对象
   */
  async getSecurityConfig() {
    const now = Date.now();
    
    // 使用缓存
    if (this.configCache && now < this.cacheExpiry) {
      return this.configCache;
    }

    try {
      const config = {};
      
      // 从config_items表读取每项配置
      for (const [type, info] of Object.entries(this.securityTypes)) {
        const result = await Database.queryOne(
          'SELECT value FROM config_items WHERE category = ? AND key_name = ? AND is_active = 1',
          ['security', info.configKey]
        );
        
        config[type] = result?.value || 'reject'; // 默认拒绝
      }

      // 更新缓存
      this.configCache = config;
      this.cacheExpiry = now + this.cacheTTL;

      logger.debug('Security Filter: Loaded config from database', { config });
      return config;

    } catch (error) {
      logger.error('Security Filter: Failed to load config', { error: error.message });
      
      // 降级到默认配置
      return {
        abuser: 'reject',
        attacker: 'reject',
        bogon: 'reject',
        cloud_provider: 'allow',
        proxy: 'reject',
        relay: 'reject',
        tor: 'reject',
        tor_exit: 'reject',
        vpn: 'reject',
        anonymous: 'reject',
        threat: 'reject'
      };
    }
  }

  /**
   * 执行安全过滤（增强版）
   * @param {Object} ipInfo - IP信息对象
   * @param {Object} legacyConfig - 旧版配置（向后兼容）
   * @returns {Promise<Object>} { passed: boolean, reason: string, details: object }
   */
  async filter(ipInfo, legacyConfig = null) {
    const security = ipInfo?.security || {};
    const detectedIssues = [];
    let shouldReject = false;
    let rejectReason = null;

    try {
      // 获取配置（优先使用新版配置）
      const config = await this.getSecurityConfig();

      // 逐项检查 Security 11项
      for (const [type, info] of Object.entries(this.securityTypes)) {
        const isDetected = security[info.key] === true;
        
        if (isDetected) {
          const action = config[type] || 'reject';
          
          detectedIssues.push({
            type: type,
            label: info.label,
            key: info.key,
            action: action,
            detected: true
          });

          // 记录检测日志
          logger.info(`Security Filter: ${info.label} detected`, {
            ip: ipInfo.ip,
            type: type,
            action: action
          });

          // 判断是否需要拒绝
          if (action === 'reject') {
            shouldReject = true;
            rejectReason = `${info.label}检测失败`;
            
            // 发现拒绝项可以提前退出，提高性能
            break;
          }
        }
      }

      // 判断最终结果
      const passed = !shouldReject;

      if (!passed) {
        logger.warn('Security Filter: Access rejected', {
          ip: ipInfo.ip,
          reason: rejectReason,
          detectedIssues: detectedIssues
        });
      } else {
        logger.debug('Security Filter: Access allowed', {
          ip: ipInfo.ip,
          detectedCount: detectedIssues.length,
          detectedIssues: detectedIssues
        });
      }

      return {
        passed,
        reason: passed ? 'Security check passed' : rejectReason,
        details: {
          detectedIssues: detectedIssues,
          riskScore: this.calculateRiskScore(security),
          // 保持向后兼容的字段
          vpn: security.is_vpn,
          proxy: security.is_proxy,
          tor: security.is_tor,
          cloudProvider: security.is_cloud_provider,
          abuser: security.is_abuser,
          attacker: security.is_attacker,
          anonymous: security.is_anonymous,
          threat: security.is_threat
        }
      };

    } catch (error) {
      logger.error('Security Filter: Error during filtering', {
        error: error.message,
        stack: error.stack,
        ip: ipInfo?.ip
      });

      // 出错时采取保守策略：拒绝访问
      return {
        passed: false,
        reason: 'Security filter error',
        details: {
          error: error.message,
          detectedIssues: []
        }
      };
    }
  }

  /**
   * 根据配置对象检查多个安全属性（向后兼容）
   * @param {Object} security - 安全信息对象
   * @param {Object} settings - 设置对象（包含各种安全开关）
   * @returns {boolean} 是否通过检查
   */
  checkSecurityAttributes(security, settings) {
    if (!security || typeof security !== 'object') {
      return false;
    }

    // 根据设置检查各个属性
    const checks = [
      { attr: 'is_abuser', enabled: settings.blockAbuser !== false },
      { attr: 'is_attacker', enabled: settings.blockAttacker !== false },
      { attr: 'is_bogon', enabled: settings.blockBogon !== false },
      { attr: 'is_cloud_provider', enabled: settings.blockCloudProvider !== false },
      { attr: 'is_proxy', enabled: settings.blockProxy !== false },
      { attr: 'is_relay', enabled: settings.blockRelay !== false },
      { attr: 'is_tor', enabled: settings.blockTor !== false },
      { attr: 'is_tor_exit', enabled: settings.blockTorExit !== false },
      { attr: 'is_vpn', enabled: settings.blockVpn !== false },
      { attr: 'is_anonymous', enabled: settings.blockAnonymous !== false },
      { attr: 'is_threat', enabled: settings.blockThreat !== false }
    ];

    for (const check of checks) {
      if (check.enabled && security[check.attr] === true) {
        logger.debug(`Security attribute check failed: ${check.attr}`, {
          attribute: check.attr,
          value: security[check.attr]
        });
        return false;
      }
    }

    return true;
  }

  /**
   * 获取安全威胁详情
   * @param {Object} security - 安全信息对象
   * @returns {Object} 威胁详情
   */
  getThreatDetails(security) {
    if (!security) return {};

    return {
      hasVpn: security.is_vpn === true,
      hasProxy: security.is_proxy === true,
      hasTor: security.is_tor === true || security.is_tor_exit === true,
      hasCloudProvider: security.is_cloud_provider === true,
      hasHosting: security.is_hosting === true,
      isAbuser: security.is_abuser === true,
      isAttacker: security.is_attacker === true,
      isAnonymous: security.is_anonymous === true,
      isThreat: security.is_threat === true,
      isBogon: security.is_bogon === true,
      riskScore: this.calculateRiskScore(security)
    };
  }

  /**
   * 计算风险评分（0-100）
   * @param {Object} security - 安全信息对象
   * @returns {number} 风险评分
   */
  calculateRiskScore(security) {
    let score = 0;

    if (security.is_attacker) score += 30;
    if (security.is_threat) score += 25;
    if (security.is_abuser) score += 20;
    if (security.is_tor || security.is_tor_exit) score += 15;
    if (security.is_vpn) score += 10;
    if (security.is_proxy) score += 10;
    if (security.is_anonymous) score += 8;
    if (security.is_cloud_provider) score += 5;
    if (security.is_bogon) score += 10;
    if (security.is_relay) score += 10;

    return Math.min(score, 100);
  }

  /**
   * 判断是否为高风险IP
   * @param {Object} security - 安全信息对象
   * @returns {boolean}
   */
  isHighRisk(security) {
    return this.calculateRiskScore(security) >= 50;
  }

  /**
   * 清除配置缓存（用于配置更新后立即生效）
   */
  clearCache() {
    this.configCache = null;
    this.cacheExpiry = 0;
    logger.info('Security Filter: Cache cleared');
  }

  /**
   * 获取Security配置摘要（用于管理后台显示）
   * @returns {Promise<Object>} 配置摘要
   */
  async getConfigSummary() {
    const config = await this.getSecurityConfig();
    const summary = {
      total: Object.keys(this.securityTypes).length,
      reject: 0,
      allow: 0,
      pass: 0,
      items: []
    };

    for (const [type, info] of Object.entries(this.securityTypes)) {
      const action = config[type] || 'reject';
      
      summary.items.push({
        type,
        label: info.label,
        action
      });

      if (action === 'reject') summary.reject++;
      else if (action === 'allow') summary.allow++;
      else if (action === 'pass') summary.pass++;
    }

    return summary;
  }
}

module.exports = new SecurityFilter();
