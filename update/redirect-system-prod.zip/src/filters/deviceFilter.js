/**
 * ============================================
 * 设备指纹过滤器
 * ============================================
 * 功能：
 * 1. User-Agent检测（浏览器、爬虫识别）
 * 2. 浏览器语言检查
 * 3. 设备类型验证
 * 4. 操作系统和浏览器引擎检查
 * ============================================
 */

const UAParser = require('ua-parser-js');
const logger = require('../utils/logger');
const { config } = require('../config');

/**
 * 设备指纹过滤器类
 */
class DeviceFilter {
  /**
   * 执行设备指纹过滤
   * @param {Object} ipInfo - IP信息对象
   * @param {Object} request - 请求对象
   * @returns {Object} - 过滤结果
   */
  static async filter(ipInfo, request) {
    try {
      const userAgent = request.headers['user-agent'] || '';
      const acceptLanguage = request.headers['accept-language'] || '';

      // 解析User-Agent
      const uaParser = new UAParser(userAgent);
      const uaInfo = {
        browser: uaParser.getBrowser(),
        device: uaParser.getDevice(),
        os: uaParser.getOS(),
        engine: uaParser.getEngine(),
        raw: userAgent,
      };

      const checks = [];
      let decision = 'allow';
      let reason = null;

      // 1. User-Agent基础检查
      const uaCheck = this._checkUserAgent(userAgent);
      checks.push(uaCheck);
      if (!uaCheck.passed) {
        decision = 'reject';
        reason = uaCheck.reason;
      }

      // 2. 浏览器类型检查
      if (decision === 'allow') {
        const browserCheck = this._checkBrowser(uaInfo.browser);
        checks.push(browserCheck);
        if (!browserCheck.passed) {
          decision = 'reject';
          reason = browserCheck.reason;
        }
      }

      // 3. 语言检查
      if (decision === 'allow' && config.filters.language) {
        const languageCheck = this._checkLanguage(acceptLanguage);
        checks.push(languageCheck);
        if (!languageCheck.passed) {
          decision = 'reject';
          reason = languageCheck.reason;
        }
      }

      // 4. 设备类型检查
      if (decision === 'allow' && config.filters.device) {
        const deviceCheck = this._checkDeviceType(uaInfo.device);
        checks.push(deviceCheck);
        if (!deviceCheck.passed) {
          decision = 'reject';
          reason = deviceCheck.reason;
        }
      }

      // 5. 操作系统检查
      if (decision === 'allow') {
        const osCheck = this._checkOS(uaInfo.os);
        checks.push(osCheck);
        if (!osCheck.passed) {
          decision = 'reject';
          reason = osCheck.reason;
        }
      }

      // 6. 浏览器引擎检查
      if (decision === 'allow') {
        const engineCheck = this._checkEngine(uaInfo.engine, uaInfo.browser, uaInfo.os);
        checks.push(engineCheck);
        if (!engineCheck.passed) {
          decision = 'reject';
          reason = engineCheck.reason;
        }
      }

      const result = {
        passed: decision === 'allow',
        decision,
        reason,
        checks,
        userAgent: {
          browser: `${uaInfo.browser.name || 'Unknown'} ${uaInfo.browser.version || ''}`,
          os: `${uaInfo.os.name || 'Unknown'} ${uaInfo.os.version || ''}`,
          device: uaInfo.device.type || 'desktop',
          engine: uaInfo.engine.name || 'Unknown',
        },
        language: this._extractPrimaryLanguage(acceptLanguage),
      };

      logger.debug('设备指纹过滤完成', {
        ip: ipInfo.ip,
        decision,
        browser: result.userAgent.browser,
        os: result.userAgent.os,
      });

      return result;
    } catch (error) {
      logger.error('设备指纹过滤失败', {
        ip: ipInfo?.ip,
        error: error.message,
      });

      return {
        passed: true,
        decision: 'allow',
        reason: 'Filter error - default allow',
        checks: [],
        error: error.message,
      };
    }
  }

  /**
   * 检查User-Agent基础有效性
   * @param {string} userAgent - User-Agent字符串
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkUserAgent(userAgent) {
    // 检查是否为空
    if (!userAgent || userAgent.trim().length === 0) {
      return {
        name: 'User-Agent Presence',
        passed: false,
        reason: 'Empty User-Agent',
      };
    }

    // 检查长度（太短可能是伪造的）
    if (userAgent.length < 20) {
      return {
        name: 'User-Agent Length',
        passed: false,
        reason: 'User-Agent too short',
        length: userAgent.length,
      };
    }

    // 检查是否包含爬虫关键词
    const botKeywords = [
      'bot', 'crawler', 'spider', 'scraper', 'curl', 'wget',
      'python-requests', 'python-urllib', 'java/', 'okhttp',
      'scrapy', 'selenium', 'phantomjs', 'headless'
    ];

    const lowerUA = userAgent.toLowerCase();
    const foundKeyword = botKeywords.find(keyword => lowerUA.includes(keyword));

    if (foundKeyword) {
      return {
        name: 'Bot Detection',
        passed: false,
        reason: `Bot/Crawler detected: ${foundKeyword}`,
        keyword: foundKeyword,
      };
    }

    return {
      name: 'User-Agent Check',
      passed: true,
      length: userAgent.length,
    };
  }

  /**
   * 检查浏览器类型
   * @param {Object} browser - 浏览器信息
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkBrowser(browser) {
    const browserName = browser.name || '';

    // 如果无法识别浏览器，拒绝
    if (!browserName || browserName === 'Unknown') {
      return {
        name: 'Browser Detection',
        passed: false,
        reason: 'Unknown browser',
      };
    }

    // 常见的真实浏览器
    const legitimateBrowsers = [
      'Chrome', 'Firefox', 'Safari', 'Edge', 'Opera',
      'Brave', 'Vivaldi', 'Samsung Browser', 'UC Browser'
    ];

    const isLegitimate = legitimateBrowsers.some(
      legit => browserName.toLowerCase().includes(legit.toLowerCase())
    );

    if (!isLegitimate) {
      return {
        name: 'Browser Validation',
        passed: false,
        reason: `Non-standard browser: ${browserName}`,
        browser: browserName,
      };
    }

    return {
      name: 'Browser Check',
      passed: true,
      browser: `${browserName} ${browser.version || ''}`,
    };
  }

  /**
   * 检查浏览器语言
   * @param {string} acceptLanguage - Accept-Language头
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkLanguage(acceptLanguage) {
    const allowedLanguages = config.language.allowedLanguages || [];
    const mode = config.language.mode || 'all';

    // 如果没有配置语言限制，允许所有
    if (mode === 'all' || allowedLanguages.length === 0) {
      return {
        name: 'Language Check',
        passed: true,
        mode: 'all',
      };
    }

    // 如果没有语言头，拒绝
    if (!acceptLanguage) {
      return {
        name: 'Language Presence',
        passed: false,
        reason: 'No Accept-Language header',
      };
    }

    // 提取主要语言（例如：zh-CN,zh;q=0.9,en;q=0.8 -> zh-CN, zh, en）
    const languages = acceptLanguage
      .split(',')
      .map(lang => lang.split(';')[0].trim().toLowerCase());

    // 检查是否有允许的语言
    const hasAllowedLanguage = languages.some(lang =>
      allowedLanguages.some(allowed =>
        lang.includes(allowed.toLowerCase()) || allowed.toLowerCase().includes(lang)
      )
    );

    if (!hasAllowedLanguage) {
      return {
        name: 'Language Validation',
        passed: false,
        reason: `Language not allowed: ${languages[0]}`,
        detected: languages[0],
        allowed: allowedLanguages.join(', '),
      };
    }

    return {
      name: 'Language Check',
      passed: true,
      detected: languages[0],
    };
  }

  /**
   * 检查设备类型
   * @param {Object} device - 设备信息
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkDeviceType(device) {
    const deviceType = device.type || 'desktop';

    // 允许的设备类型
    const allowedTypes = ['mobile', 'tablet', 'desktop'];

    // 如果设备类型不在允许列表中
    if (!allowedTypes.includes(deviceType)) {
      return {
        name: 'Device Type',
        passed: false,
        reason: `Unusual device type: ${deviceType}`,
        deviceType,
      };
    }

    return {
      name: 'Device Type',
      passed: true,
      deviceType,
      vendor: device.vendor || 'Unknown',
    };
  }

  /**
   * 检查操作系统
   * @param {Object} os - 操作系统信息
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkOS(os) {
    const osName = os.name || '';

    // 如果无法识别操作系统，拒绝
    if (!osName || osName === 'Unknown') {
      return {
        name: 'OS Detection',
        passed: false,
        reason: 'Unknown operating system',
      };
    }

    // 常见的操作系统
    const legitimateOS = [
      'Windows', 'Mac OS', 'iOS', 'Android', 'Linux',
      'Chrome OS', 'Ubuntu', 'Debian'
    ];

    const isLegitimate = legitimateOS.some(
      legit => osName.toLowerCase().includes(legit.toLowerCase())
    );

    if (!isLegitimate) {
      return {
        name: 'OS Validation',
        passed: false,
        reason: `Unusual OS: ${osName}`,
        os: osName,
      };
    }

    return {
      name: 'OS Check',
      passed: true,
      os: `${osName} ${os.version || ''}`,
    };
  }

  /**
   * 检查浏览器引擎一致性
   * @param {Object} engine - 引擎信息
   * @param {Object} browser - 浏览器信息
   * @param {Object} os - 操作系统信息
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkEngine(engine, browser, os) {
    const engineName = engine.name || '';
    const browserName = browser.name || '';
    const osName = os.name || '';

    // 基本的一致性检查
    // Safari 应该使用 WebKit
    if (browserName.includes('Safari') && !browserName.includes('Chrome')) {
      if (!engineName.includes('WebKit')) {
        return {
          name: 'Engine Consistency',
          passed: false,
          reason: 'Safari should use WebKit engine',
          engine: engineName,
        };
      }
    }

    // iOS 上应该使用 WebKit
    if (osName.includes('iOS') && !engineName.includes('WebKit')) {
      return {
        name: 'Engine Consistency',
        passed: false,
        reason: 'iOS browsers should use WebKit',
        engine: engineName,
        os: osName,
      };
    }

    return {
      name: 'Engine Check',
      passed: true,
      engine: engineName,
    };
  }

  /**
   * 提取主要语言
   * @param {string} acceptLanguage - Accept-Language头
   * @returns {string} - 主要语言
   * @private
   */
  static _extractPrimaryLanguage(acceptLanguage) {
    if (!acceptLanguage) return 'unknown';
    return acceptLanguage.split(',')[0].split(';')[0].trim();
  }

  /**
   * 获取过滤器名称
   * @returns {string}
   */
  static getName() {
    return 'DeviceFilter';
  }

  /**
   * 检查是否启用
   * @returns {boolean}
   */
  static isEnabled() {
    return config.filters.device !== false;
  }
}

module.exports = DeviceFilter;
