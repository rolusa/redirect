/**
 * 地理位置过滤器
 * 基于IP地理位置信息进行访问控制
 * - 国家白名单/黑名单
 * - 地区过滤
 * - 城市过滤
 * - 大陆过滤
 */

const logger = require('../utils/logger');

class GeoFilter {
  constructor() {
    // 默认配置
    this.defaultConfig = {
      mode: 'whitelist', // whitelist 或 blacklist
      allowedCountries: ['JP'], // 国家代码数组
      blockedCountries: [],
      allowedContinents: [], // 大陆代码：AS, EU, NA, SA, AF, OC, AN
      blockedContinents: [],
      allowedRegions: [], // 地区名称
      blockedRegions: [],
      allowedCities: [], // 城市名称
      blockedCities: []
    };

    // 大陆代码映射
    this.continentMap = {
      'AS': 'Asia',
      'EU': 'Europe',
      'NA': 'North America',
      'SA': 'South America',
      'AF': 'Africa',
      'OC': 'Oceania',
      'AN': 'Antarctica'
    };
  }

  /**
   * 执行地理位置过滤
   * @param {Object} ipInfo - IP信息对象
   * @param {Object} geoConfig - 地理位置配置（可选）
   * @returns {Object} { passed: boolean, reason: string, location: object }
   */
  filter(ipInfo, geoConfig = null) {
    const config = geoConfig || this.defaultConfig;
    const location = ipInfo?.location || {};

    try {
      // 提取地理位置信息
      const country = ipInfo.country?.code || ipInfo.location?.country?.code || '';
      const countryName = ipInfo.country?.name || ipInfo.location?.country?.name || '';
      const continent = ipInfo.location?.continent?.code || '';
      const region = ipInfo.location?.region?.name || '';
      const city = ipInfo.location?.city || '';

      // 添加调试日志
      console.log('📍 地理位置信息:', { country, countryName, continent, region, city });

      logger.debug('Geo Filter: Checking location', {
        ip: ipInfo.ip,
        country,
        countryName,
        continent,
        region,
        city
      });

      // 1. 国家级过滤
      const countryCheck = this._checkCountry(country, config);
      if (!countryCheck.passed) {
        logger.info('Geo Filter: Country check failed', {
          ip: ipInfo.ip,
          country,
          countryName,
          reason: countryCheck.reason
        });
        return {
          passed: false,
          reason: countryCheck.reason,
          location: {
            country,
            countryName,
            continent,
            region,
            city
          }
        };
      }

      // 2. 大陆级过滤
      const continentCheck = this._checkContinent(continent, config);
      if (!continentCheck.passed) {
        logger.info('Geo Filter: Continent check failed', {
          ip: ipInfo.ip,
          continent,
          reason: continentCheck.reason
        });
        return {
          passed: false,
          reason: continentCheck.reason,
          location: {
            country,
            countryName,
            continent,
            region,
            city
          }
        };
      }

      // 3. 地区级过滤
      const regionCheck = this._checkRegion(region, config);
      if (!regionCheck.passed) {
        logger.info('Geo Filter: Region check failed', {
          ip: ipInfo.ip,
          region,
          reason: regionCheck.reason
        });
        return {
          passed: false,
          reason: regionCheck.reason,
          location: {
            country,
            countryName,
            continent,
            region,
            city
          }
        };
      }

      // 4. 城市级过滤
      const cityCheck = this._checkCity(city, config);
      if (!cityCheck.passed) {
        logger.info('Geo Filter: City check failed', {
          ip: ipInfo.ip,
          city,
          reason: cityCheck.reason
        });
        return {
          passed: false,
          reason: cityCheck.reason,
          location: {
            country,
            countryName,
            continent,
            region,
            city
          }
        };
      }

      // 全部通过
      logger.debug('Geo Filter: Passed', {
        ip: ipInfo.ip,
        country,
        countryName
      });

      return {
        passed: true,
        reason: 'Geographic location allowed',
        location: {
          country,
          countryName,
          continent,
          region,
          city,
          latitude: location.latitude,
          longitude: location.longitude,
          timezone: location.timezone
        }
      };

    } catch (error) {
      logger.error('Geo Filter: Error during filtering', {
        error: error.message,
        ip: ipInfo?.ip
      });

      // 出错时采取保守策略
      return {
        passed: false,
        reason: 'Geo filter error',
        location: {}
      };
    }
  }

  /**
   * 检查国家代码
   * @private
   */
  _checkCountry(countryCode, config) {
    console.log('🔍 国家检查 - 输入:', { countryCode, configMode: config.mode, allowedCountries: config.allowedCountries });

    if (!countryCode) {
      console.log('❌ 国家代码为空');
      return {
        passed: false,
        reason: 'Country code not available'
      };
    }

    const upperCountry = countryCode.toUpperCase();

    // 黑名单模式
    if (config.mode === 'blacklist') {
      if (config.blockedCountries && config.blockedCountries.length > 0) {
        const blocked = config.blockedCountries.some(
          c => c.toUpperCase() === upperCountry
        );
        if (blocked) {
          console.log('❌ 国家在黑名单中');
          return {
            passed: false,
            reason: `Country ${upperCountry} is blocked`
          };
        }
      }
      console.log('✅ 黑名单模式 - 国家不在黑名单');
      return { passed: true, reason: 'Country not in blacklist' };
    }

    // 白名单模式（默认）
    if (config.allowedCountries && config.allowedCountries.length > 0) {
      const allowed = config.allowedCountries.some(
        c => c.toUpperCase() === upperCountry
      );
      console.log('🔍 白名单检查:', { upperCountry, allowed, allowedCountries: config.allowedCountries });
      if (!allowed) {
        console.log('❌ 国家不在白名单中');
        return {
          passed: false,
          reason: `Country ${upperCountry} not in whitelist`
        };
      }
      console.log('✅ 国家在白名单中');
      return { passed: true, reason: 'Country in whitelist' };
    }

    // 未配置白名单时默认允许
    console.log('⚠️ 未配置白名单，默认允许');
    return { passed: true, reason: 'No country whitelist configured' };
  }

  /**
   * 检查大陆代码
   * @private
   */
  _checkContinent(continentCode, config) {
    if (!continentCode) {
      // 如果没有大陆信息，且配置了大陆过滤，则拒绝
      if ((config.allowedContinents && config.allowedContinents.length > 0) ||
        (config.blockedContinents && config.blockedContinents.length > 0)) {
        return {
          passed: false,
          reason: 'Continent information not available'
        };
      }
      return { passed: true, reason: 'No continent filter configured' };
    }

    const upperContinent = continentCode.toUpperCase();

    // 检查黑名单
    if (config.blockedContinents && config.blockedContinents.length > 0) {
      const blocked = config.blockedContinents.some(
        c => c.toUpperCase() === upperContinent
      );
      if (blocked) {
        return {
          passed: false,
          reason: `Continent ${upperContinent} is blocked`
        };
      }
    }

    // 检查白名单
    if (config.allowedContinents && config.allowedContinents.length > 0) {
      const allowed = config.allowedContinents.some(
        c => c.toUpperCase() === upperContinent
      );
      if (!allowed) {
        return {
          passed: false,
          reason: `Continent ${upperContinent} not in whitelist`
        };
      }
    }

    return { passed: true, reason: 'Continent check passed' };
  }

  /**
   * 检查地区名称
   * @private
   */
  _checkRegion(regionName, config) {
    if (!regionName) {
      // 如果没有地区信息，且配置了地区过滤，则拒绝
      if ((config.allowedRegions && config.allowedRegions.length > 0) ||
        (config.blockedRegions && config.blockedRegions.length > 0)) {
        return {
          passed: false,
          reason: 'Region information not available'
        };
      }
      return { passed: true, reason: 'No region filter configured' };
    }

    const lowerRegion = regionName.toLowerCase();

    // 检查黑名单
    if (config.blockedRegions && config.blockedRegions.length > 0) {
      const blocked = config.blockedRegions.some(
        r => r.toLowerCase() === lowerRegion
      );
      if (blocked) {
        return {
          passed: false,
          reason: `Region ${regionName} is blocked`
        };
      }
    }

    // 检查白名单
    if (config.allowedRegions && config.allowedRegions.length > 0) {
      const allowed = config.allowedRegions.some(
        r => r.toLowerCase() === lowerRegion
      );
      if (!allowed) {
        return {
          passed: false,
          reason: `Region ${regionName} not in whitelist`
        };
      }
    }

    return { passed: true, reason: 'Region check passed' };
  }

  /**
   * 检查城市名称
   * @private
   */
  _checkCity(cityName, config) {
    if (!cityName) {
      // 如果没有城市信息,且配置了城市过滤,则拒绝
      if ((config.allowedCities && config.allowedCities.length > 0) ||
        (config.blockedCities && config.blockedCities.length > 0)) {
        return {
          passed: false,
          reason: 'City information not available'
        };
      }
      return { passed: true, reason: 'No city filter configured' };
    }

    const lowerCity = cityName.toLowerCase();

    // 检查黑名单
    if (config.blockedCities && config.blockedCities.length > 0) {
      const blocked = config.blockedCities.some(
        c => c.toLowerCase() === lowerCity
      );
      if (blocked) {
        return {
          passed: false,
          reason: `City ${cityName} is blocked`
        };
      }
    }

    // 检查白名单
    if (config.allowedCities && config.allowedCities.length > 0) {
      const allowed = config.allowedCities.some(
        c => c.toLowerCase() === lowerCity
      );
      if (!allowed) {
        return {
          passed: false,
          reason: `City ${cityName} not in whitelist`
        };
      }
    }

    return { passed: true, reason: 'City check passed' };
  }

  /**
   * 简单的国家检查（兼容原有代码）
   * @param {Array|String} allowedCountries - 允许的国家代码（逗号分隔或数组）
   * @param {String} countryCode - 要检查的国家代码
   * @returns {boolean}
   */
  checkLocationCountry(allowedCountries, countryCode) {
    if (!countryCode) return false;

    // 处理字符串或数组
    let countries = [];
    if (typeof allowedCountries === 'string') {
      countries = allowedCountries.split(',').map(c => c.trim().toUpperCase());
    } else if (Array.isArray(allowedCountries)) {
      countries = allowedCountries.map(c => c.toString().trim().toUpperCase());
    }

    if (countries.length === 0) return true; // 未配置则允许全部

    return countries.includes(countryCode.toUpperCase());
  }

  /**
   * 获取地理位置摘要信息
   * @param {Object} location - 位置信息对象
   * @returns {String}
   */
  getLocationSummary(location) {
    if (!location) return 'Unknown';

    const parts = [];
    if (location.city?.name) parts.push(location.city.name);
    if (location.region?.name) parts.push(location.region.name);
    if (location.country?.name) parts.push(location.country.name);

    return parts.length > 0 ? parts.join(', ') : 'Unknown';
  }

  /**
   * 判断是否为特定国家
   * @param {Object} location - 位置信息对象
   * @param {String} countryCode - 国家代码
   * @returns {boolean}
   */
  isCountry(location, countryCode) {
    return location?.country?.code?.toUpperCase() === countryCode.toUpperCase();
  }

  /**
   * 判断是否为特定大陆
   * @param {Object} location - 位置信息对象
   * @param {String} continentCode - 大陆代码
   * @returns {boolean}
   */
  isContinent(location, continentCode) {
    return location?.continent?.code?.toUpperCase() === continentCode.toUpperCase();
  }
}

module.exports = new GeoFilter();
