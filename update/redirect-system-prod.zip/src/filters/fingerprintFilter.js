/**
 * ============================================
 * 高级指纹过滤器
 * ============================================
 * 功能：
 * 1. 检测自动化工具（Selenium、Puppeteer、Headless Chrome）
 * 2. 检测请求头一致性和异常组合
 * 3. 检测爬虫和机器人特征
 * 4. 检测TLS/HTTP指纹异常
 * ============================================
 */

const logger = require('../utils/logger');

/**
 * 高级指纹过滤器类
 */
class FingerprintFilter {
  /**
   * 执行高级指纹过滤
   * @param {Object} ipInfo - IP信息对象
   * @param {Object} request - Express请求对象
   * @param {Object} config - 过滤配置
   * @returns {Object} - 过滤结果
   */
  static filter(ipInfo, request, config = null) {
    try {
      const headers = request.headers || {};
      const userAgent = headers['user-agent'] || '';
      const checks = [];
      let suspicionScore = 0; // 可疑分数，越高越可疑
      const suspicions = []; // 可疑项列表

      console.log('🔍 高级指纹检查开始...');

      // 1. 检测自动化工具特征
      const automationCheck = this._checkAutomationTools(headers, userAgent);
      checks.push(automationCheck);
      if (!automationCheck.passed) {
        suspicionScore += automationCheck.score || 50;
        suspicions.push(automationCheck.reason);
      }

      // 2. 检测Headless浏览器
      const headlessCheck = this._checkHeadlessBrowser(headers, userAgent);
      checks.push(headlessCheck);
      if (!headlessCheck.passed) {
        suspicionScore += headlessCheck.score || 40;
        suspicions.push(headlessCheck.reason);
      }

      // 3. 检测请求头完整性
      const headersCheck = this._checkHeadersIntegrity(headers, userAgent);
      checks.push(headersCheck);
      if (!headersCheck.passed) {
        suspicionScore += headersCheck.score || 30;
        suspicions.push(headersCheck.reason);
      }

      // 4. 检测Accept头异常
      const acceptCheck = this._checkAcceptHeaders(headers);
      checks.push(acceptCheck);
      if (!acceptCheck.passed) {
        suspicionScore += acceptCheck.score || 20;
        suspicions.push(acceptCheck.reason);
      }

      // 5. 检测User-Agent与浏览器头不一致
      const consistencyCheck = this._checkHeaderConsistency(headers, userAgent);
      checks.push(consistencyCheck);
      if (!consistencyCheck.passed) {
        suspicionScore += consistencyCheck.score || 30;
        suspicions.push(consistencyCheck.reason);
      }

      // 6. 检测已知爬虫特征
      const botCheck = this._checkKnownBots(headers, userAgent);
      checks.push(botCheck);
      if (!botCheck.passed) {
        suspicionScore += botCheck.score || 60;
        suspicions.push(botCheck.reason);
      }

      console.log('🔍 高级指纹检查完成:', { suspicionScore, suspicionCount: suspicions.length });

      // 判定逻辑：可疑分数超过阈值则拒绝
      const threshold = config?.threshold || 50; // 默认阈值50
      const passed = suspicionScore < threshold;

      const result = {
        passed,
        reason: passed ? 'Advanced fingerprint check passed' : `Suspicious activity detected (score: ${suspicionScore})`,
        suspicionScore,
        threshold,
        suspicions,
        checks,
        details: {
          totalChecks: checks.length,
          failedChecks: checks.filter(c => !c.passed).length,
          suspicionScore,
        }
      };

      if (!passed) {
        logger.warn('Advanced Fingerprint: Suspicious activity detected', {
          ip: ipInfo.ip,
          suspicionScore,
          suspicions,
        });
        console.log('❌ 高级指纹检查失败:', suspicions);
      } else {
        console.log('✅ 高级指纹检查通过');
      }

      return result;

    } catch (error) {
      logger.error('Advanced Fingerprint Filter Error', {
        error: error.message,
        ip: ipInfo?.ip,
      });

      return {
        passed: true, // 出错时不阻止访问
        reason: 'Fingerprint check error (allowed)',
        suspicionScore: 0,
        checks: [],
        error: error.message,
      };
    }
  }

  /**
   * 检测自动化工具特征
   * @private
   */
  static _checkAutomationTools(headers, userAgent) {
    const automationSignals = [
      'HeadlessChrome',
      'PhantomJS',
      'Selenium',
      'WebDriver',
      'Puppeteer',
      'playwright',
      'automation',
      'bot',
      'crawler',
      'spider',
      'scraper',
    ];

    // 检查UA中的自动化特征
    const uaLower = userAgent.toLowerCase();
    const foundSignals = automationSignals.filter(signal => 
      uaLower.includes(signal.toLowerCase())
    );

    // 检查请求头中的自动化标记
    const automationHeaders = [
      'x-requested-with',
      'x-automation',
      'x-webkit-inspector',
      'x-devtools-emulate-network-conditions-client-id',
    ];

    const foundHeaders = automationHeaders.filter(header => headers[header]);

    if (foundSignals.length > 0 || foundHeaders.length > 0) {
      return {
        name: 'Automation Tools Check',
        passed: false,
        reason: foundSignals.length > 0 
          ? `Automation tool detected in UA: ${foundSignals.join(', ')}`
          : `Automation headers detected: ${foundHeaders.join(', ')}`,
        score: 50,
        signals: foundSignals,
        headers: foundHeaders,
      };
    }

    return {
      name: 'Automation Tools Check',
      passed: true,
      reason: 'No automation tools detected',
      score: 0,
    };
  }

  /**
   * 检测Headless浏览器
   * @private
   */
  static _checkHeadlessBrowser(headers, userAgent) {
    const headlessSignals = [];

    // 1. Chrome Headless特征
    if (userAgent.includes('HeadlessChrome') || userAgent.includes('Headless')) {
      headlessSignals.push('Explicit Headless in UA');
    }

    // 2. 缺少Chrome特有的头但UA声称是Chrome
    if (userAgent.includes('Chrome') && !userAgent.includes('Headless')) {
      const chromeHeaders = [
        'sec-ch-ua',
        'sec-ch-ua-mobile',
        'sec-ch-ua-platform',
      ];
      
      const missingHeaders = chromeHeaders.filter(h => !headers[h]);
      if (missingHeaders.length === chromeHeaders.length) {
        headlessSignals.push('Missing Chrome security headers');
      }
    }

    // 3. 检查 sec-fetch-* 头
    if (userAgent.includes('Chrome') || userAgent.includes('Edge')) {
      const secFetchHeaders = ['sec-fetch-site', 'sec-fetch-mode', 'sec-fetch-dest'];
      const hasSome = secFetchHeaders.some(h => headers[h]);
      const hasAll = secFetchHeaders.every(h => headers[h]);
      
      if (!hasSome && userAgent.match(/Chrome\/\d{3,}/)) {
        // Chrome 76+ 应该有这些头
        headlessSignals.push('Missing sec-fetch headers (Chrome 76+)');
      }
    }

    if (headlessSignals.length > 0) {
      return {
        name: 'Headless Browser Check',
        passed: false,
        reason: `Headless browser detected: ${headlessSignals.join(', ')}`,
        score: 40,
        signals: headlessSignals,
      };
    }

    return {
      name: 'Headless Browser Check',
      passed: true,
      reason: 'No headless browser detected',
      score: 0,
    };
  }

  /**
   * 检测请求头完整性
   * @private
   */
  static _checkHeadersIntegrity(headers, userAgent) {
    const issues = [];

    // 1. 真实浏览器应该有的基本头
    const requiredHeaders = [
      'accept',
      'accept-language',
      'user-agent',
    ];

    const missingRequired = requiredHeaders.filter(h => !headers[h]);
    if (missingRequired.length > 0) {
      issues.push(`Missing required headers: ${missingRequired.join(', ')}`);
    }

    // 2. Accept-Encoding检查
    if (!headers['accept-encoding']) {
      issues.push('Missing accept-encoding header');
    } else {
      const encoding = headers['accept-encoding'].toLowerCase();
      if (!encoding.includes('gzip') && !encoding.includes('deflate')) {
        issues.push('Unusual accept-encoding (missing gzip/deflate)');
      }
    }

    // 3. Connection头检查
    if (headers['connection']) {
      const conn = headers['connection'].toLowerCase();
      if (conn === 'close' && userAgent.includes('Mozilla')) {
        // 现代浏览器通常用 keep-alive
        issues.push('Unusual connection header for modern browser');
      }
    }

    // 4. 请求头数量异常（太少）
    const headerCount = Object.keys(headers).length;
    if (headerCount < 5) {
      issues.push(`Too few headers (${headerCount})`);
    }

    if (issues.length > 0) {
      return {
        name: 'Headers Integrity Check',
        passed: false,
        reason: issues.join('; '),
        score: Math.min(issues.length * 10, 30),
        issues,
      };
    }

    return {
      name: 'Headers Integrity Check',
      passed: true,
      reason: 'Headers integrity OK',
      score: 0,
    };
  }

  /**
   * 检测Accept头异常
   * @private
   */
  static _checkAcceptHeaders(headers) {
    const issues = [];

    // 1. Accept头检查
    if (!headers['accept']) {
      issues.push('Missing accept header');
    } else {
      const accept = headers['accept'].toLowerCase();
      
      // 真实浏览器通常接受 text/html
      if (!accept.includes('text/html') && !accept.includes('*/*')) {
        issues.push('Accept header missing text/html');
      }

      // 检查是否是简化的Accept头（爬虫常见）
      if (accept === '*/*' && headers['user-agent']?.includes('Mozilla')) {
        issues.push('Simplified accept header for browser UA');
      }
    }

    // 2. Accept-Language检查
    if (!headers['accept-language']) {
      issues.push('Missing accept-language header');
    }

    if (issues.length > 0) {
      return {
        name: 'Accept Headers Check',
        passed: false,
        reason: issues.join('; '),
        score: Math.min(issues.length * 10, 20),
        issues,
      };
    }

    return {
      name: 'Accept Headers Check',
      passed: true,
      reason: 'Accept headers OK',
      score: 0,
    };
  }

  /**
   * 检测请求头一致性
   * @private
   */
  static _checkHeaderConsistency(headers, userAgent) {
    const issues = [];

    // 1. Chrome浏览器应该有的头
    if (userAgent.includes('Chrome') && !userAgent.includes('Headless')) {
      if (!headers['sec-ch-ua'] && !headers['sec-fetch-site']) {
        issues.push('Chrome UA but missing Chrome-specific headers');
      }
    }

    // 2. 移动设备检查
    const isMobile = /Mobile|Android|iPhone|iPad/i.test(userAgent);
    if (isMobile) {
      if (headers['sec-ch-ua-mobile'] === '?0') {
        issues.push('Mobile UA but sec-ch-ua-mobile indicates desktop');
      }
    }

    // 3. Safari特有检查
    if (userAgent.includes('Safari') && !userAgent.includes('Chrome')) {
      // 真正的Safari不会有Chrome的特征
      if (headers['sec-ch-ua']) {
        issues.push('Safari UA but has Chrome security headers');
      }
    }

    if (issues.length > 0) {
      return {
        name: 'Header Consistency Check',
        passed: false,
        reason: issues.join('; '),
        score: Math.min(issues.length * 15, 30),
        issues,
      };
    }

    return {
      name: 'Header Consistency Check',
      passed: true,
      reason: 'Headers consistent with UA',
      score: 0,
    };
  }

  /**
   * 检测已知爬虫
   * @private
   */
  static _checkKnownBots(headers, userAgent) {
    // 常见爬虫UA特征
    const knownBots = [
      'googlebot',
      'bingbot',
      'slurp', // Yahoo
      'duckduckbot',
      'baiduspider',
      'yandexbot',
      'sogou',
      'exabot',
      'facebot',
      'ia_archiver',
      'curl',
      'wget',
      'python-requests',
      'java/',
      'apache-httpclient',
      'go-http-client',
      'okhttp',
      'scrapy',
      'nutch',
    ];

    const uaLower = userAgent.toLowerCase();
    const foundBots = knownBots.filter(bot => uaLower.includes(bot));

    if (foundBots.length > 0) {
      return {
        name: 'Known Bot Check',
        passed: false,
        reason: `Known bot/crawler detected: ${foundBots.join(', ')}`,
        score: 60,
        bots: foundBots,
      };
    }

    // 检查From头（爬虫通常会设置）
    if (headers['from'] && headers['from'].includes('@')) {
      return {
        name: 'Known Bot Check',
        passed: false,
        reason: 'From header present (crawler indicator)',
        score: 40,
      };
    }

    return {
      name: 'Known Bot Check',
      passed: true,
      reason: 'No known bot detected',
      score: 0,
    };
  }
}

module.exports = FingerprintFilter;
