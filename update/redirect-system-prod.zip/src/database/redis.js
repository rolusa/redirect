/**
 * ============================================
 * Redis数据库连接和操作
 * ============================================
 * 功能：
 * 1. Redis连接管理
 * 2. 基础操作封装
 * 3. Token存储管理
 * 4. 错误处理
 * ============================================
 * 
 * 📝 修复说明：
 * - 修改为 redis v5 的 Promise API
 * - 使用 socket 配置替代旧的 host/port
 * - 使用 connect() 方法建立连接
 * - 所有操作改为 async/await 风格
 */

const redis = require('redis');
const { config } = require('../config');
const logger = require('../utils/logger');

/**
 * Redis操作类
 */
class Redis {
  static client = null;
  static isConnected = false;

  /**
   * 初始化Redis连接
   * @returns {Promise<void>}
   */
  static async init() {
    try {
      logger.info('Redis开始连接...');

      // ✅ 使用 redis v5 的新API
      const clientConfig = {
        socket: {
          host: config.redis.host || 'localhost',
          port: config.redis.port || 6379,
          reconnectStrategy: (retries) => {
            if (retries > 10) {
              logger.error('Redis重试次数超过10次');
              return new Error('Redis重试次数过多');
            }
            // 重连间隔：100ms * 重试次数，最大3秒
            return Math.min(retries * 100, 3000);
          }
        }
      };

      // 如果有密码，添加密码配置
      if (config.redis.password) {
        clientConfig.password = config.redis.password;
      }

      // 设置数据库编号
      if (config.redis.db) {
        clientConfig.database = config.redis.db;
      }

      // 创建Redis客户端
      this.client = redis.createClient(clientConfig);

      // 监听错误事件
      this.client.on('error', (err) => {
        this.isConnected = false;
        logger.error('Redis运行时错误', {
          error: err.message
        });
      });

      // 监听断开连接事件
      this.client.on('end', () => {
        this.isConnected = false;
        logger.warn('Redis连接已关闭');
      });

      // 监听重连事件
      this.client.on('reconnecting', () => {
        logger.info('Redis正在重新连接...');
      });

      // ✅ 使用 connect() 方法连接（redis v5）
      await this.client.connect();
      
      this.isConnected = true;
      logger.info('Redis连接成功', {
        host: config.redis.host || 'localhost',
        port: config.redis.port || 6379,
        db: config.redis.db || 0
      });

    } catch (error) {
      this.isConnected = false;
      logger.error('Redis初始化失败', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * 关闭Redis连接
   * @returns {Promise<void>}
   */
  static async close() {
    try {
      if (this.client) {
        await this.client.quit();
        this.isConnected = false;
        logger.info('Redis连接已关闭');
      }
    } catch (error) {
      logger.error('Redis关闭失败', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 检查连接状态
   * @returns {boolean}
   */
  static isReady() {
    return this.isConnected && this.client !== null && this.client.isOpen;
  }

  /**
   * 设置键值（带过期时间）
   * @param {string} key - 键名
   * @param {string} value - 值
   * @param {number} ttlSeconds - 过期时间（秒）
   * @returns {Promise<string>}
   */
  static async setWithExpiry(key, value, ttlSeconds) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      // ✅ 使用 setEx 方法（redis v5）
      const reply = await this.client.setEx(key, ttlSeconds, value);
      
      logger.debug('Redis设置成功（带过期）', {
        key,
        ttl: ttlSeconds
      });
      
      return reply;
    } catch (error) {
      logger.error('Redis设置失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取键值
   * @param {string} key - 键名
   * @returns {Promise<string|null>}
   */
  static async get(key) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      return await this.client.get(key);
    } catch (error) {
      logger.error('Redis获取失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 设置键值（无过期时间）
   * @param {string} key - 键名
   * @param {string} value - 值
   * @returns {Promise<string>}
   */
  static async set(key, value) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      const reply = await this.client.set(key, value);
      logger.debug('Redis设置成功', { key });
      return reply;
    } catch (error) {
      logger.error('Redis设置失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 删除键
   * @param {string} key - 键名
   * @returns {Promise<number>} - 删除的键数量
   */
  static async del(key) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      const reply = await this.client.del(key);
      logger.debug('Redis删除成功', { key });
      return reply;
    } catch (error) {
      logger.error('Redis删除失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 检查键是否存在
   * @param {string} key - 键名
   * @returns {Promise<boolean>}
   */
  static async exists(key) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      const reply = await this.client.exists(key);
      return reply === 1;
    } catch (error) {
      logger.error('Redis检查存在失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取键的剩余生存时间（TTL）
   * @param {string} key - 键名
   * @returns {Promise<number>} - 剩余秒数，-1表示永久，-2表示不存在
   */
  static async ttl(key) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      return await this.client.ttl(key);
    } catch (error) {
      logger.error('Redis获取TTL失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 设置键的过期时间
   * @param {string} key - 键名
   * @param {number} seconds - 过期秒数
   * @returns {Promise<boolean>} - true表示成功，false表示键不存在
   */
  static async expire(key, seconds) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      const reply = await this.client.expire(key, seconds);
      return reply === 1;
    } catch (error) {
      logger.error('Redis设置过期时间失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 批量获取键值
   * @param {Array<string>} keys - 键名数组
   * @returns {Promise<Array<string|null>>}
   */
  static async mget(keys) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      return await this.client.mGet(keys);
    } catch (error) {
      logger.error('Redis批量获取失败', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取匹配的所有键
   * @param {string} pattern - 匹配模式（如：token:*）
   * @returns {Promise<Array<string>>}
   */
  static async keys(pattern) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      return await this.client.keys(pattern);
    } catch (error) {
      logger.error('Redis查询键失败', {
        pattern,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 自增操作
   * @param {string} key - 键名
   * @returns {Promise<number>} - 自增后的值
   */
  static async incr(key) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      return await this.client.incr(key);
    } catch (error) {
      logger.error('Redis自增失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 自减操作
   * @param {string} key - 键名
   * @returns {Promise<number>} - 自减后的值
   */
  static async decr(key) {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      return await this.client.decr(key);
    } catch (error) {
      logger.error('Redis自减失败', {
        key,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Ping测试
   * @returns {Promise<string>}
   */
  static async ping() {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      return await this.client.ping();
    } catch (error) {
      throw error;
    }
  }

  /**
   * 清空当前数据库
   * ⚠️ 危险操作，仅用于开发/测试
   * @returns {Promise<string>}
   */
  static async flushdb() {
    try {
      if (!this.isReady()) {
        throw new Error('Redis未连接');
      }

      const reply = await this.client.flushDb();
      logger.warn('Redis数据库已清空');
      return reply;
    } catch (error) {
      logger.error('Redis清空失败', {
        error: error.message
      });
      throw error;
    }
  }
}

module.exports = Redis;
