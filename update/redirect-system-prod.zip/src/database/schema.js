/**
 * ============================================
 * 数据库表结构定义
 * ============================================
 * 功能：
 * 1. 定义所有表的创建SQL
 * 2. 自动初始化数据库表
 * 3. 支持索引和约束
 * ============================================
 */

const logger = require('../utils/logger');

/**
 * 数据库表定义
 */
const tables = {
  // 访问日志表
  access_logs: `
    CREATE TABLE IF NOT EXISTS access_logs (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      
      -- Token信息
      token_hash VARCHAR(64) NOT NULL,
      email_id VARCHAR(255),
      
      -- IP信息
      ip VARCHAR(45) NOT NULL,
      country_code VARCHAR(2),
      country_name VARCHAR(100),
      region VARCHAR(100),
      city VARCHAR(100),
      
      -- 设备信息
      user_agent TEXT,
      browser VARCHAR(100),
      browser_version VARCHAR(50),
      os VARCHAR(100),
      os_version VARCHAR(50),
      device_type VARCHAR(50),
      device_brand VARCHAR(100),
      
      -- 安全信息
      is_vpn BOOLEAN DEFAULT FALSE,
      is_proxy BOOLEAN DEFAULT FALSE,
      is_tor BOOLEAN DEFAULT FALSE,
      is_threat BOOLEAN DEFAULT FALSE,
      
      -- 过滤结果
      filter_decision VARCHAR(20) NOT NULL,
      filter_results JSON,
      rejection_reason VARCHAR(255),
      
      -- 重定向信息
      redirect_to VARCHAR(500),
      redirect_domain VARCHAR(255),
      
      -- 性能信息
      process_time_ms INT UNSIGNED,
      
      INDEX idx_token_hash (token_hash),
      INDEX idx_ip (ip),
      INDEX idx_created_at (created_at),
      INDEX idx_decision (filter_decision),
      INDEX idx_country (country_code),
      INDEX idx_email_id (email_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,

  // Token使用记录表
  token_usage: `
    CREATE TABLE IF NOT EXISTS token_usage (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      token_hash VARCHAR(64) NOT NULL UNIQUE,
      email_id VARCHAR(255),
      
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      first_used_at TIMESTAMP NULL,
      last_used_at TIMESTAMP NULL,
      
      use_count INT UNSIGNED DEFAULT 0,
      max_uses INT UNSIGNED DEFAULT 3,
      
      expires_at TIMESTAMP NULL,
      is_expired BOOLEAN DEFAULT FALSE,
      is_blocked BOOLEAN DEFAULT FALSE,
      
      INDEX idx_token_hash (token_hash),
      INDEX idx_email_id (email_id),
      INDEX idx_expires_at (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,

  // IP信誉表
  ip_reputation: `
    CREATE TABLE IF NOT EXISTS ip_reputation (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      ip VARCHAR(45) NOT NULL UNIQUE,
      
      reputation_score INT DEFAULT 50,
      
      total_visits INT UNSIGNED DEFAULT 0,
      successful_visits INT UNSIGNED DEFAULT 0,
      rejected_visits INT UNSIGNED DEFAULT 0,
      
      last_visit_at TIMESTAMP NULL,
      first_visit_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      
      is_whitelisted BOOLEAN DEFAULT FALSE,
      is_blacklisted BOOLEAN DEFAULT FALSE,
      blacklist_reason VARCHAR(255),
      blacklist_expires_at TIMESTAMP NULL,
      
      country_code VARCHAR(2),
      
      INDEX idx_ip (ip),
      INDEX idx_reputation (reputation_score),
      INDEX idx_blacklisted (is_blacklisted),
      INDEX idx_whitelisted (is_whitelisted)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,

  // 统计数据表（每小时汇总）
  statistics: `
    CREATE TABLE IF NOT EXISTS statistics (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      stat_hour TIMESTAMP NOT NULL,
      
      total_requests INT UNSIGNED DEFAULT 0,
      successful_requests INT UNSIGNED DEFAULT 0,
      rejected_requests INT UNSIGNED DEFAULT 0,
      
      rejection_rate DECIMAL(5,2),
      
      unique_ips INT UNSIGNED DEFAULT 0,
      unique_tokens INT UNSIGNED DEFAULT 0,
      
      avg_process_time_ms INT UNSIGNED,
      
      top_countries JSON,
      top_rejection_reasons JSON,
      
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      
      UNIQUE KEY unique_stat_hour (stat_hour),
      INDEX idx_stat_hour (stat_hour)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,
};

/**
 * 初始化数据库表
 * @param {Object} connection - MySQL连接对象
 * @returns {Promise<void>}
 */
async function initializeTables(connection) {
  try {
    logger.info('开始初始化数据库表...');

    for (const [tableName, sql] of Object.entries(tables)) {
      try {
        await connection.query(sql);
        logger.info(`表 ${tableName} 创建成功`);
      } catch (error) {
        logger.error(`表 ${tableName} 创建失败`, {
          error: error.message,
        });
        throw error;
      }
    }

    logger.info('数据库表初始化完成');
  } catch (error) {
    logger.error('数据库初始化失败', { error: error.message });
    throw error;
  }
}

/**
 * 删除所有表（危险操作！仅用于开发/测试）
 * @param {Object} connection - MySQL连接对象
 * @returns {Promise<void>}
 */
async function dropAllTables(connection) {
  try {
    logger.warn('开始删除所有表（危险操作）');

    // 禁用外键检查
    await connection.query('SET FOREIGN_KEY_CHECKS = 0');

    for (const tableName of Object.keys(tables)) {
      try {
        await connection.query(`DROP TABLE IF EXISTS ${tableName}`);
        logger.warn(`表 ${tableName} 已删除`);
      } catch (error) {
        logger.error(`表 ${tableName} 删除失败`, {
          error: error.message,
        });
      }
    }

    // 启用外键检查
    await connection.query('SET FOREIGN_KEY_CHECKS = 1');

    logger.warn('所有表已删除');
  } catch (error) {
    logger.error('删除表失败', { error: error.message });
    throw error;
  }
}

/**
 * 检查表是否存在
 * @param {Object} connection - MySQL连接对象
 * @param {string} tableName - 表名
 * @returns {Promise<boolean>}
 */
async function tableExists(connection, tableName) {
  try {
    const [rows] = await connection.query(
      'SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?',
      [tableName]
    );
    return rows[0].count > 0;
  } catch (error) {
    logger.error('检查表存在失败', { tableName, error: error.message });
    return false;
  }
}

module.exports = {
  tables,
  initializeTables,
  dropAllTables,
  tableExists,
};
