/**
 * ============================================
 * 系统管理API路由
 * ============================================
 */

const express = require('express');
const router = express.Router();
const Database = require('../../database/mysql');
const { asyncHandler } = require('../middleware/errorHandler');

/**
 * POST /api/system/backup
 * 创建配置备份
 */
router.post('/backup', asyncHandler(async (req, res) => {
  const { name, description } = req.body;
  const { username } = req.user;

  // 获取所有配置
  const configs = await Database.query(
    'SELECT category, key_name, value, data_type FROM config_items WHERE is_active = 1'
  );

  const backupData = {
    version: '1.0',
    createdAt: new Date().toISOString(),
    createdBy: username,
    configs
  };

  // 保存快照
  await Database.insert('config_snapshots', {
    name: name || `备份_${new Date().toISOString()}`,
    description: description || '',
    config_data: JSON.stringify(backupData),
    created_by: username
  });

  // 记录日志
  await Database.insert('admin_logs', {
    username,
    action: 'backup_created',
    details: `创建配置备份: ${name || '自动备份'}`,
    ip_address: req.ip,
    status: 'success'
  });

  res.json({
    success: true,
    message: '备份创建成功'
  });
}));

/**
 * GET /api/system/backups
 * 获取备份列表
 */
router.get('/backups', asyncHandler(async (req, res) => {
  const { limit = 10 } = req.query;

  const backups = await Database.query(
    `SELECT id, name, description, created_by, created_at,
     LENGTH(config_data) as size
     FROM config_snapshots
     ORDER BY created_at DESC
     LIMIT ?`,
    [parseInt(limit)]
  );

  res.json({
    success: true,
    data: backups
  });
}));

/**
 * POST /api/system/restore/:id
 * 恢复配置备份
 */
router.post('/restore/:id', asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { username } = req.user;

  const backup = await Database.queryOne(
    'SELECT * FROM config_snapshots WHERE id = ?',
    [id]
  );

  if (!backup) {
    return res.status(404).json({
      success: false,
      message: '备份不存在'
    });
  }

  const backupData = JSON.parse(backup.config_data);
  const configs = backupData.configs;

  let restoredCount = 0;

  for (const item of configs) {
    const { category, key_name, value } = item;

    const existing = await Database.queryOne(
      'SELECT id FROM config_items WHERE category = ? AND key_name = ?',
      [category, key_name]
    );

    if (existing) {
      await Database.update('config_items', {
        value,
        updated_by: username,
        updated_at: new Date()
      }, { id: existing.id });
      restoredCount++;
    }
  }

  // 记录日志
  await Database.insert('admin_logs', {
    username,
    action: 'backup_restored',
    details: `恢复配置备份: ${backup.name}`,
    ip_address: req.ip,
    status: 'success'
  });

  res.json({
    success: true,
    message: `成功恢复${restoredCount}个配置项`
  });
}));

/**
 * DELETE /api/system/backup/:id
 * 删除备份
 */
router.delete('/backup/:id', asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { username } = req.user;

  const deleted = await Database.delete('config_snapshots', { id });

  if (deleted === 0) {
    return res.status(404).json({
      success: false,
      message: '备份不存在'
    });
  }

  // 记录日志
  await Database.insert('admin_logs', {
    username,
    action: 'backup_deleted',
    details: `删除配置备份 ID: ${id}`,
    ip_address: req.ip,
    status: 'success'
  });

  res.json({
    success: true,
    message: '备份已删除'
  });
}));

/**
 * POST /api/system/cleanup
 * 清理旧数据
 */
router.post('/cleanup', asyncHandler(async (req, res) => {
  const { type, days = 30 } = req.body;
  const { username } = req.user;

  let deleted = 0;

  switch (type) {
    case 'access_logs':
      const result1 = await Database.query(
        'DELETE FROM access_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)',
        [parseInt(days)]
      );
      deleted = result1.affectedRows;
      break;

    case 'expired_tokens':
      const result2 = await Database.query(
        'DELETE FROM token_usage WHERE is_expired = 1 AND expires_at < DATE_SUB(NOW(), INTERVAL ? DAY)',
        [parseInt(days)]
      );
      deleted = result2.affectedRows;
      break;

    case 'old_backups':
      const result3 = await Database.query(
        'DELETE FROM config_snapshots WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)',
        [parseInt(days)]
      );
      deleted = result3.affectedRows;
      break;

    default:
      return res.status(400).json({
        success: false,
        message: '不支持的清理类型'
      });
  }

  // 记录日志
  await Database.insert('admin_logs', {
    username,
    action: 'data_cleanup',
    details: `清理${type}，删除${deleted}条记录`,
    ip_address: req.ip,
    status: 'success'
  });

  res.json({
    success: true,
    message: `成功清理${deleted}条记录`
  });
}));

/**
 * GET /api/system/info
 * 获取系统信息
 */
router.get('/info', asyncHandler(async (req, res) => {
  const info = {
    nodeVersion: process.version,
    platform: process.platform,
    arch: process.arch,
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    cpuUsage: process.cpuUsage(),
    env: process.env.NODE_ENV || 'development'
  };

  res.json({
    success: true,
    data: info
  });
}));


/**
 * POST /api/system/restart
 * 重启服务
 */
router.post('/restart', asyncHandler(async (req, res) => {
  const { exec } = require('child_process');
  
  // 记录操作日志
  await Database.query(
    'INSERT INTO admin_logs (username, action, details) VALUES (?, ?, ?)',
    [req.user?.username || 'admin', 'restart_service', '重启系统服务']
  );
  
  exec('pm2 restart all', (error, stdout, stderr) => {
    if (error) {
      logger.error('重启服务失败', { error: error.message });
    } else {
      logger.info('服务重启成功', { stdout });
    }
  });
  
  // 立即返回，不等待重启完成
  res.json({ 
    success: true, 
    message: '服务正在重启，请等待5-10秒...' 
  });
}));

module.exports = router;
