/**
 * 重定向域名管理 API
 * 路径: src/admin/routes/domains.js
 */

const express = require('express');
const router = express.Router();
const Database = require('../../database/mysql');
const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const util = require('util');
const execPromise = util.promisify(exec);

/**
 * 获取所有重定向域名列表
 */
router.get('/list', async (req, res) => {
    try {
        const domains = await Database.query(`
            SELECT 
                id,
                domain_name,
                domain_type,
                ssl_enabled,
                ssl_provider,
                ssl_issued_date,
                ssl_expiry_date,
                days_left,
                is_active,
                is_cloudflare,
                use_for_links,
                notes,
                created_at
            FROM redirect_domains
            ORDER BY created_at DESC
        `);

        // 计算剩余天数
        for (const domain of domains) {
            if (domain.ssl_expiry_date) {
                const daysLeft = Math.floor((new Date(domain.ssl_expiry_date) - Date.now()) / (1000 * 60 * 60 * 24));
                domain.days_left = daysLeft;
                
                // 更新数据库中的days_left
                await Database.update('redirect_domains', 
                    { days_left: daysLeft }, 
                    { id: domain.id }
                );
            }
        }

        res.json({
            success: true,
            domains
        });
    } catch (error) {
        console.error('获取域名列表失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 添加新域名
 */
router.post('/add', async (req, res) => {
    try {
        const {
            domain_name,
            domain_type,
            is_cloudflare,
            cloudflare_zone_id,
            notes
        } = req.body;

        // 验证域名格式
        if (!domain_name || domain_name.trim() === '') {
            return res.json({ success: false, message: '域名不能为空' });
        }

        // 检查域名是否已存在
        const existing = await Database.queryOne(
            'SELECT id FROM redirect_domains WHERE domain_name = ?',
            [domain_name]
        );

        if (existing) {
            return res.json({ success: false, message: '域名已存在' });
        }

        // 插入新域名
        const insertId = await Database.insert('redirect_domains', {
            domain_name: domain_name,
            domain_type: domain_type || 'main',
            is_cloudflare: is_cloudflare || false,
            cloudflare_zone_id: cloudflare_zone_id || null,
            notes: notes || ''
        });

        res.json({
            success: true,
            message: '域名添加成功',
            id: insertId
        });

    } catch (error) {
        console.error('添加域名失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 删除域名
 */
router.delete('/delete/:id', async (req, res) => {
    try {
        const { id } = req.params;

        // 获取域名信息
        const domain = await Database.queryOne(
            'SELECT domain_name, nginx_config_path FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        // 删除Nginx配置文件（如果存在）
        if (domain.nginx_config_path) {
            try {
                await fs.unlink(domain.nginx_config_path);
                console.log(`已删除Nginx配置: ${domain.nginx_config_path}`);
            } catch (error) {
                console.warn('删除Nginx配置失败:', error.message);
            }
        }

        // 从数据库删除
        await Database.delete('redirect_domains', { id: id });

        res.json({
            success: true,
            message: '域名删除成功'
        });

    } catch (error) {
        console.error('删除域名失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 生成Nginx配置
 */
router.post('/generate-nginx-config/:id', async (req, res) => {
    try {
        const { id } = req.params;

        // 获取域名信息
        const domain = await Database.queryOne(
            'SELECT domain_name, domain_type FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        // 生成Nginx配置内容
        const configContent = generateNginxConfig(domain.domain_name, domain.domain_type);
        
        // 配置文件路径
        const configFileName = domain.domain_name.replace(/\*/g, 'wildcard').replace(/\./g, '_');
        const configPath = `/etc/nginx/sites-available/${configFileName}.conf`;

        // 保存配置文件（需要sudo权限）
        const tempPath = `/tmp/${configFileName}.conf`;
        await fs.writeFile(tempPath, configContent);

        // 移动到nginx目录（需要sudo）
        try {
            await execPromise(`sudo mv ${tempPath} ${configPath}`);
            await execPromise(`sudo ln -sf ${configPath} /etc/nginx/sites-enabled/${configFileName}.conf`);
            
            // 测试Nginx配置
            const { stdout, stderr } = await execPromise('sudo nginx -t');
            
            if (stderr && !stderr.includes('syntax is ok') && !stderr.includes('test is successful')) {
                throw new Error('Nginx配置测试失败: ' + stderr);
            }

            // 重载Nginx
            await execPromise('sudo systemctl reload nginx');

            // 更新数据库
            await Database.update('redirect_domains',
                { nginx_config_path: configPath },
                { id: id }
            );

            res.json({
                success: true,
                message: 'Nginx配置生成成功',
                configPath,
                configContent
            });

        } catch (error) {
            // 如果没有sudo权限，只返回配置内容
            console.warn('无sudo权限，返回配置内容:', error.message);
            res.json({
                success: true,
                needManualSetup: true,
                message: '请手动将以下配置保存到Nginx',
                configContent,
                suggestedPath: configPath
            });
        }

    } catch (error) {
        console.error('生成Nginx配置失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 申请SSL证书 - 改进版本
 * 使用更可靠的证书申请策略：
 * 1. 优先使用 webroot 方式（不依赖Nginx配置）
 * 2. 如果失败，降级到 standalone 方式（自动处理Nginx）
 * 3. 自动处理配置冲突问题
 */
router.post('/apply-ssl/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { email, useCloudflare } = req.body;

        // 检测操作系统
        const isWindows = process.platform === 'win32';
        
        if (isWindows) {
            return res.json({
                success: false,
                isWindows: true,
                message: '❌ SSL证书申请功能仅在Linux服务器上可用',
                details: 'Windows环境不支持Certbot和Nginx，请在Ubuntu 22.04服务器上使用此功能。',
                requirements: [
                    '✅ Ubuntu 22.04 或更高版本',
                    '✅ 已安装 Nginx',
                    '✅ 已安装 Certbot',
                    '✅ 域名已解析到服务器IP',
                    '✅ 端口 80 和 443 已开放'
                ]
            });
        }

        // 获取域名信息
        const domain = await Database.queryOne(
            'SELECT domain_name, domain_type, is_cloudflare FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        const domainName = domain.domain_name;
        const isWildcard = domain.domain_type === 'wildcard';
        const isCloudflare = useCloudflare || domain.is_cloudflare;
        const emailAddress = email || `admin@${domainName.replace('*.', '')}`;

        // 通配符证书需要DNS验证
        if (isWildcard) {
            let certbotCommand;
            
            if (isCloudflare) {
                // 使用CloudFlare DNS验证
                certbotCommand = `sudo certbot certonly --dns-cloudflare --dns-cloudflare-credentials /root/.secrets/cloudflare.ini -d "${domainName}" --non-interactive --agree-tos --email ${emailAddress}`;
            } else {
                // 手动DNS验证
                return res.json({
                    success: false,
                    needManualDNS: true,
                    message: '通配符证书需要DNS验证',
                    instructions: `
通配符证书（*.${domainName.replace('*.', '')}）需要手动DNS验证：

1. SSH连接到服务器
2. 运行命令：
   sudo certbot certonly --manual --preferred-challenges dns -d "${domainName}" --agree-tos --email ${emailAddress}

3. 按照提示添加DNS TXT记录
4. 等待DNS生效后按回车完成验证

或者启用Cloudflare DNS验证功能。
                    `.trim()
                });
            }

            try {
                console.log('执行Certbot命令 (通配符):', certbotCommand);
                const { stdout, stderr } = await execPromise(certbotCommand, { timeout: 120000 });
                
                console.log('Certbot输出:', stdout);
                if (stderr) console.log('Certbot stderr:', stderr);

                // 证书申请成功，继续处理
                await updateCertificateInfo(domainName, id, isCloudflare);
                
                res.json({
                    success: true,
                    message: 'SSL证书申请成功',
                    provider: isCloudflare ? 'cloudflare' : 'letsencrypt'
                });

            } catch (error) {
                console.error('通配符证书申请失败:', error);
                throw error;
            }
            
            return;
        }

        // ============================================
        // 主域名证书申请 - 使用智能策略
        // ============================================

        console.log(`开始为域名 ${domainName} 申请SSL证书`);

        // 策略1: 尝试 Webroot 方式（推荐，不依赖Nginx配置）
        try {
            console.log('策略1: 尝试 Webroot 方式...');
            
            // 确保webroot目录存在
            await execPromise('sudo mkdir -p /var/www/html/.well-known/acme-challenge');
            
            const webrootCommand = `sudo certbot certonly --webroot -w /var/www/html -d "${domainName}" --non-interactive --agree-tos --email ${emailAddress} --force-renewal`;
            
            console.log('执行命令:', webrootCommand);
            const { stdout, stderr } = await execPromise(webrootCommand, { timeout: 120000 });
            
            console.log('Webroot方式成功!');
            console.log('输出:', stdout);
            if (stderr) console.log('stderr:', stderr);

            // 更新证书信息
            await updateCertificateInfo(domainName, id, isCloudflare);
            
            return res.json({
                success: true,
                message: 'SSL证书申请成功（Webroot方式）',
                method: 'webroot'
            });

        } catch (webrootError) {
            console.log('Webroot方式失败:', webrootError.message);
            console.log('尝试策略2...');
        }

        // 策略2: 使用 Standalone 方式（最可靠，但需要临时停止Nginx）
        try {
            console.log('策略2: 尝试 Standalone 方式...');
            
            // 检查80端口是否被占用
            const portCheck = await execPromise('sudo netstat -tlnp | grep ":80 " || sudo ss -tlnp | grep ":80 " || echo "ok"').catch(() => ({ stdout: 'ok' }));
            const isPort80Used = !portCheck.stdout.includes('ok');
            
            let needRestartNginx = false;
            
            if (isPort80Used) {
                console.log('端口80被占用，临时停止Nginx...');
                await execPromise('sudo systemctl stop nginx');
                needRestartNginx = true;
                
                // 等待端口释放
                await new Promise(resolve => setTimeout(resolve, 2000));
            }

            try {
                const standaloneCommand = `sudo certbot certonly --standalone -d "${domainName}" --non-interactive --agree-tos --email ${emailAddress} --force-renewal`;
                
                console.log('执行命令:', standaloneCommand);
                const { stdout, stderr } = await execPromise(standaloneCommand, { timeout: 120000 });
                
                console.log('Standalone方式成功!');
                console.log('输出:', stdout);
                if (stderr) console.log('stderr:', stderr);

                // 更新证书信息
                await updateCertificateInfo(domainName, id, isCloudflare);
                
                return res.json({
                    success: true,
                    message: 'SSL证书申请成功（Standalone方式）',
                    method: 'standalone'
                });

            } finally {
                // 无论成功失败，都要重启Nginx
                if (needRestartNginx) {
                    console.log('重启Nginx...');
                    await execPromise('sudo systemctl start nginx').catch(err => {
                        console.error('重启Nginx失败:', err);
                    });
                }
            }

        } catch (standaloneError) {
            console.error('Standalone方式也失败:', standaloneError.message);
            
            // 两种方式都失败了，返回详细错误信息
            const errorMsg = standaloneError.stderr || standaloneError.message || standaloneError.toString();
            
            // 分析错误原因
            let troubleshooting = [];
            
            if (errorMsg.includes('DNS') || errorMsg.includes('domain')) {
                troubleshooting.push('❌ 域名解析问题：请确认域名已正确解析到服务器IP');
            }
            
            if (errorMsg.includes('port') || errorMsg.includes('80')) {
                troubleshooting.push('❌ 端口80被占用或无法访问：检查防火墙和安全组');
            }
            
            if (errorMsg.includes('timeout') || errorMsg.includes('connection')) {
                troubleshooting.push('❌ 网络连接问题：确保服务器可以访问Let\'s Encrypt服务器');
            }
            
            if (errorMsg.includes('rate limit')) {
                troubleshooting.push('❌ 请求频率限制：Let\'s Encrypt有申请频率限制，请稍后再试');
            }
            
            if (troubleshooting.length === 0) {
                troubleshooting.push('请检查服务器日志：sudo tail -50 /var/log/letsencrypt/letsencrypt.log');
            }

            return res.json({
                success: false,
                message: 'SSL证书申请失败',
                error: errorMsg.split('\n').slice(0, 5).join('\n'), // 只返回前5行错误
                troubleshooting
            });
        }

    } catch (error) {
        console.error('申请SSL证书失败:', error);
        
        return res.json({
            success: false,
            message: error.message || 'SSL证书申请失败',
            error: error.toString()
        });
    }
});

/**
 * 更新证书信息到数据库
 */
async function updateCertificateInfo(domainName, domainId, isCloudflare) {
    try {
        const certPath = `/etc/letsencrypt/live/${domainName.replace('*.', '')}/fullchain.pem`;
        const keyPath = `/etc/letsencrypt/live/${domainName.replace('*.', '')}/privkey.pem`;

        // 获取证书过期时间
        const { stdout: certInfo } = await execPromise(`sudo openssl x509 -in ${certPath} -noout -enddate`);
        const expiryMatch = certInfo.match(/notAfter=(.+)/);
        const expiryDate = expiryMatch ? new Date(expiryMatch[1]) : null;
        const daysLeft = expiryDate ? Math.floor((expiryDate - Date.now()) / (1000 * 60 * 60 * 24)) : null;

        // 更新数据库
        await Database.query(`
            UPDATE redirect_domains 
            SET ssl_enabled = TRUE,
                ssl_provider = ?,
                ssl_issued_date = NOW(),
                ssl_expiry_date = ?,
                days_left = ?,
                cert_path = ?,
                key_path = ?
            WHERE id = ?
        `, [
            isCloudflare ? 'cloudflare' : 'letsencrypt',
            expiryDate,
            daysLeft,
            certPath,
            keyPath,
            domainId
        ]);

        console.log(`证书信息已更新到数据库: ${domainName}, 过期时间: ${expiryDate}, 剩余天数: ${daysLeft}`);
        
        return {
            certPath,
            keyPath,
            expiryDate,
            daysLeft
        };
        
    } catch (error) {
        console.error('更新证书信息失败:', error);
        throw error;
    }
}

/**
 * 检查SSL证书状态
 */
router.get('/check-ssl/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const domain = await Database.queryOne(
            'SELECT domain_name, cert_path FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain || !domain.cert_path) {
            return res.json({ success: false, message: '未找到证书' });
        }

        // 检查证书过期时间
        const { stdout } = await execPromise(`sudo openssl x509 -in ${domain.cert_path} -noout -enddate`);
        const expiryMatch = stdout.match(/notAfter=(.+)/);
        const expiryDate = expiryMatch ? new Date(expiryMatch[1]) : null;
        const daysLeft = expiryDate ? Math.floor((expiryDate - Date.now()) / (1000 * 60 * 60 * 24)) : null;

        // 更新数据库
        await Database.update('redirect_domains',
            { ssl_expiry_date: expiryDate, days_left: daysLeft },
            { id: id }
        );

        res.json({
            success: true,
            domain: domain.domain_name,
            expiryDate,
            daysLeft,
            status: daysLeft > 30 ? 'healthy' : daysLeft > 7 ? 'warning' : 'critical'
        });

    } catch (error) {
        console.error('检查SSL证书失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 切换域名激活状态
 */
router.post('/toggle/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const domain = await Database.queryOne(
            'SELECT is_active FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        const newStatus = !domain.is_active;
        await Database.update('redirect_domains',
            { is_active: newStatus },
            { id: id }
        );

        res.json({
            success: true,
            message: `域名已${newStatus ? '激活' : '停用'}`,
            is_active: newStatus
        });

    } catch (error) {
        console.error('切换域名状态失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 生成Nginx配置内容
 */
function generateNginxConfig(domainName, domainType) {
    const serverName = domainName;
    const certDomain = domainName.replace('*.', '');
    
    return `# Nginx配置 - ${domainName}
# 自动生成时间: ${new Date().toISOString()}

# HTTP to HTTPS 重定向
server {
    listen 80;
    listen [::]:80;
    server_name ${serverName};
    
    # Let's Encrypt 验证
    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }
    
    # 重定向到HTTPS
    location / {
        return 301 https://$host$request_uri;
    }
}

# HTTPS 服务
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name ${serverName};
    
    # SSL 证书配置
    ssl_certificate /etc/letsencrypt/live/${certDomain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${certDomain}/privkey.pem;
    
    # SSL 安全配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # 反向代理到Node.js服务
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # 超时设置
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # 日志
    access_log /var/log/nginx/${certDomain}_access.log;
    error_log /var/log/nginx/${certDomain}_error.log;
}
`;
}

/**
 * 切换域名的"用于生成链接"状态
 */
router.post('/toggle-use-for-links/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const domain = await Database.queryOne(
            'SELECT use_for_links FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        const newStatus = !domain.use_for_links;
        await Database.update('redirect_domains',
            { use_for_links: newStatus },
            { id: id }
        );

        res.json({
            success: true,
            message: `域名已${newStatus ? '启用' : '禁用'}用于生成链接`,
            use_for_links: newStatus
        });

    } catch (error) {
        console.error('切换域名用于生成链接状态失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 获取可用于生成链接的域名列表
 */
router.get('/available-for-links', async (req, res) => {
    try {
        const domains = await Database.query(`
            SELECT 
                id,
                domain_name,
                domain_type,
                ssl_enabled,
                is_active,
                use_for_links
            FROM redirect_domains
            WHERE is_active = TRUE AND use_for_links = TRUE
            ORDER BY created_at ASC
        `);

        res.json({
            success: true,
            domains: domains.map(d => d.domain_name),
            details: domains
        });

    } catch (error) {
        console.error('获取可用域名列表失败:', error);
        res.json({
            success: false,
            message: error.message,
            domains: []
        });
    }
});

module.exports = router;
