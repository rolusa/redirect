/**
 * ============================================
 * IP信息采集服务
 * ============================================
 * 功能：
 * 1. 调用ipregistry API获取IP详细信息
 * 2. 缓存IP信息减少API调用
 * 3. 解析和格式化IP数据
 * 4. 错误处理和降级策略
 * ============================================
 */

const axios = require('axios');
const { config } = require('../config');
const logger = require('../utils/logger');
const Cache = require('../utils/cache');

/**
 * IP信息采集服务类
 */
class IPRegistryService {
  /**
   * 获取IP信息（带缓存）
   * @param {string} ip - IP地址
   * @returns {Promise<Object|null>} - IP信息对象
   */
  static async getIPInfo(ip) {
    try {
      // 1. 检查缓存
      const cacheKey = `ip_info:${ip}`;
      const cached = await Cache.get(cacheKey);
      if (cached) {
        logger.debug('IP信息命中缓存', { ip });
        return cached;
      }

      // 2. 调用API
      logger.debug('调用ipregistry API', { ip });
      console.log('🔍 准备查询IP:', ip);  // ← 添加
      console.log('🔍 API Key:', config.ipregistry.apiKey ? '已配置' : '未配置');  // ← 添加
      const ipInfo = await this._fetchFromAPI(ip);
      console.log('🔍 API返回结果:', ipInfo ? '成功' : '失败');  // ← 添加

      if (!ipInfo) {
        logger.warn('无法获取IP信息', { ip });
        return this._getDefaultIPInfo(ip);
      }

      // 3. 格式化数据
      const formatted = this._formatIPInfo(ipInfo);

      // 4. 保存到缓存
      await Cache.set(cacheKey, formatted, config.cache.ipInfoTTL);

      logger.info('IP信息获取成功', {
        ip,
        country: formatted.country.code,
        city: formatted.location.city,
      });

      return formatted;
    } catch (error) {
      logger.error('获取IP信息失败', {
        ip,
        error: error.message,
      });
      return this._getDefaultIPInfo(ip);
    }
  }

  /**
   * 从API获取IP信息
   * @param {string} ip - IP地址
   * @returns {Promise<Object|null>}
   * @private
   */
  static async _fetchFromAPI(ip) {
    try {
      const url = `${config.ipregistry.baseURL}/${ip}`;
      const params = {
        key: config.ipregistry.apiKey,
      };

      const response = await axios.get(url, {
        params,
        timeout: config.ipregistry.timeout,
        headers: {
          'User-Agent': 'RedirectSystem/1.0',
        },
      });

      if (response.status === 200 && response.data) {
        return response.data;
      }

      return null;
    } catch (error) {
      // 处理不同类型的错误
      if (error.response) {
        // API返回错误状态码
        logger.error('ipregistry API错误', {
          ip,
          status: error.response.status,
          message: error.response.data?.error?.message || 'Unknown error',
        });

        // 如果是401（API Key无效），记录警告
        if (error.response.status === 401) {
          logger.error('ipregistry API Key无效！请检查配置');
        }

        // 如果是429（超限），记录警告
        if (error.response.status === 429) {
          logger.warn('ipregistry API调用超限');
        }
      } else if (error.request) {
        // 请求发送但没有响应
        logger.error('ipregistry API无响应', { ip, error: error.message });
      } else {
        // 其他错误
        logger.error('ipregistry API请求失败', { ip, error: error.message });
      }

      return null;
    }
  }

  /**
   * 格式化IP信息
   * @param {Object} rawData - API返回的原始数据
   * @returns {Object} - 格式化后的数据
   * @private
   */
  static _formatIPInfo(rawData) {
    return {
      // IP地址
      ip: rawData.ip || '',

      // 地理位置
      location: {
        country: rawData.location?.country?.name || '',
        countryCode: rawData.location?.country?.code || '',
        region: rawData.location?.region?.name || '',
        city: rawData.location?.city || '',
        postalCode: rawData.location?.postal || '',
        latitude: rawData.location?.latitude || null,
        longitude: rawData.location?.longitude || null,
        timezone: rawData.time_zone?.id || '',
      },

      // 国家信息
      country: {
        name: rawData.location?.country?.name || '',
        code: rawData.location?.country?.code || '',
        flag: rawData.location?.country?.flag?.emoji || '',
      },

      // 连接信息
      connection: {
        type: rawData.connection?.type || 'unknown',
        organization: rawData.connection?.organization || '',
        asn: rawData.connection?.asn || null,
        domain: rawData.connection?.domain || '',
      },

      // 安全信息
      security: {
        isVPN: rawData.security?.is_vpn || false,
        isProxy: rawData.security?.is_proxy || false,
        isTor: rawData.security?.is_tor || false,
        isTorExit: rawData.security?.is_tor_exit || false,
        isCloudProvider: rawData.security?.is_cloud_provider || false,
        isAnonymous: rawData.security?.is_anonymous || false,
        isAbuser: rawData.security?.is_abuser || false,
        isAttacker: rawData.security?.is_attacker || false,
        isBogon: rawData.security?.is_bogon || false,
        isRelay: rawData.security?.is_relay || false,
        isThreat: rawData.security?.is_threat || false,
      },

      // 货币信息
      currency: {
        code: rawData.currency?.code || '',
        name: rawData.currency?.name || '',
        symbol: rawData.currency?.symbol || '',
      },

      // 时区信息
      timeZone: {
        id: rawData.time_zone?.id || '',
        abbreviation: rawData.time_zone?.abbreviation || '',
        currentTime: rawData.time_zone?.current_time || '',
        offset: rawData.time_zone?.offset || 0,
      },

      // 原始数据（用于调试）
      _raw: config.debug.verbose ? rawData : null,
    };
  }

  /**
   * 获取默认IP信息（降级处理）
   * @param {string} ip - IP地址
   * @returns {Object}
   * @private
   */
  static _getDefaultIPInfo(ip) {
    return {
      ip,
      location: {
        country: 'Unknown',
        countryCode: 'XX',
        region: '',
        city: '',
        postalCode: '',
        latitude: null,
        longitude: null,
        timezone: '',
      },
      country: {
        name: 'Unknown',
        code: 'XX',
        flag: '',
      },
      connection: {
        type: 'unknown',
        organization: '',
        asn: null,
        domain: '',
      },
      security: {
        isVPN: false,
        isProxy: false,
        isTor: false,
        isTorExit: false,
        isCloudProvider: false,
        isAnonymous: false,
        isAbuser: false,
        isAttacker: false,
        isBogon: false,
        isRelay: false,
        isThreat: false,
      },
      currency: { code: '', name: '', symbol: '' },
      timeZone: { id: '', abbreviation: '', currentTime: '', offset: 0 },
      _raw: null,
      _fallback: true, // 标记为降级数据
    };
  }

  /**
   * 批量获取IP信息
   * @param {string[]} ips - IP地址数组
   * @returns {Promise<Object>} - IP信息映射对象
   */
  static async getIPInfoBatch(ips) {
    const results = {};

    // 并发请求（最多10个）
    const chunkSize = 10;
    for (let i = 0; i < ips.length; i += chunkSize) {
      const chunk = ips.slice(i, i + chunkSize);
      const promises = chunk.map(ip => this.getIPInfo(ip));
      const chunkResults = await Promise.all(promises);

      chunk.forEach((ip, index) => {
        results[ip] = chunkResults[index];
      });
    }

    return results;
  }

  /**
   * 清除IP信息缓存
   * @param {string} ip - IP地址，如果不提供则清除所有
   * @returns {Promise<boolean>}
   */
  static async clearCache(ip = null) {
    try {
      if (ip) {
        await Cache.del(`ip_info:${ip}`);
        logger.info('IP缓存已清除', { ip });
      } else {
        await Cache.delPattern('ip_info:*');
        logger.info('所有IP缓存已清除');
      }
      return true;
    } catch (error) {
      logger.error('清除IP缓存失败', { error: error.message });
      return false;
    }
  }

  /**
   * 获取缓存统计
   * @returns {Promise<Object>}
   */
  static async getCacheStats() {
    try {
      const redis = Cache.getClient();
      const keys = await redis.keys(config.redis.keyPrefix + 'ip_info:*');

      return {
        totalCached: keys.length,
        keyPrefix: config.redis.keyPrefix + 'ip_info:',
      };
    } catch (error) {
      logger.error('获取缓存统计失败', { error: error.message });
      return { totalCached: 0, keyPrefix: '' };
    }
  }

  /**
   * 测试API连接
   * @returns {Promise<Object>} - 测试结果
   */
  static async testAPIConnection() {
    try {
      const testIP = '8.8.8.8'; // Google DNS
      const startTime = Date.now();
      const result = await this._fetchFromAPI(testIP);
      const duration = Date.now() - startTime;

      if (result) {
        logger.info('ipregistry API测试成功', {
          duration: `${duration}ms`,
          ip: testIP,
        });
        return {
          success: true,
          duration,
          message: 'API连接正常',
        };
      } else {
        return {
          success: false,
          message: 'API返回空数据',
        };
      }
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }
}

module.exports = IPRegistryService;
