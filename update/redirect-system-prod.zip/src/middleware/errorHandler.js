/**
 * ============================================
 * 错误处理中间件
 * ============================================
 * 功能：
 * 1. 捕获所有未处理的错误
 * 2. 记录错误日志
 * 3. 返回友好的错误响应
 * 4. 根据环境显示不同级别的错误信息
 * ============================================
 */

const logger = require('../utils/logger');
const { config } = require('../config');

/**
 * 404错误处理
 * @param {Object} req - Express请求对象
 * @param {Object} res - Express响应对象
 */
function notFoundHandler(req, res) {
  logger.warn('404 Not Found', {
    method: req.method,
    url: req.url,
    ip: req.ip,
  });

  res.status(404).json({
    error: 'Not Found',
    message: 'The requested resource was not found',
    path: req.url,
  });
}

/**
 * 全局错误处理中间件
 * @param {Error} err - 错误对象
 * @param {Object} req - Express请求对象
 * @param {Object} res - Express响应对象
 * @param {Function} next - Next函数
 */
function errorHandler(err, req, res, next) {
  // 记录错误日志
  logger.error('应用错误', {
    error: err.message,
    stack: err.stack,
    method: req.method,
    url: req.url,
    ip: req.ip,
    userAgent: req.headers['user-agent'],
  });

  // 确定HTTP状态码
  const statusCode = err.statusCode || err.status || 500;

  // 准备错误响应
  const errorResponse = {
    error: err.name || 'Internal Server Error',
    message: err.message || 'An unexpected error occurred',
  };

  // 开发环境显示详细错误信息
  if (config.server.env === 'development' || config.debug.enabled) {
    errorResponse.stack = err.stack;
    errorResponse.details = err.details || null;
  }

  // 生产环境隐藏敏感信息
  if (config.server.env === 'production' && statusCode === 500) {
    errorResponse.message = 'Internal server error';
  }

  // 发送错误响应
  res.status(statusCode).json(errorResponse);
}

/**
 * 异步错误包装器
 * 用于包装异步路由处理器，自动捕获错误
 * @param {Function} fn - 异步函数
 * @returns {Function} - 包装后的函数
 */
function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * 验证错误处理
 * @param {Object} err - Joi验证错误对象
 * @param {Object} req - Express请求对象
 * @param {Object} res - Express响应对象
 * @param {Function} next - Next函数
 */
function validationErrorHandler(err, req, res, next) {
  if (err.isJoi) {
    logger.warn('验证错误', {
      details: err.details,
      url: req.url,
      ip: req.ip,
    });

    return res.status(400).json({
      error: 'Validation Error',
      message: err.details[0].message,
      details: err.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message,
      })),
    });
  }

  next(err);
}

/**
 * 数据库错误处理
 * @param {Error} err - 错误对象
 * @param {Object} req - Express请求对象
 * @param {Object} res - Express响应对象
 * @param {Function} next - Next函数
 */
function databaseErrorHandler(err, req, res, next) {
  // MySQL错误
  if (err.code && err.code.startsWith('ER_')) {
    logger.error('数据库错误', {
      code: err.code,
      message: err.message,
      sql: err.sql,
    });

    return res.status(500).json({
      error: 'Database Error',
      message: config.server.env === 'development'
        ? err.message
        : 'A database error occurred',
    });
  }

  next(err);
}

/**
 * 请求超时处理
 * @param {number} timeout - 超时时间（毫秒）
 * @returns {Function} - 中间件函数
 */
function timeoutHandler(timeout = 30000) {
  return (req, res, next) => {
    // 设置请求超时
    req.setTimeout(timeout, () => {
      logger.error('请求超时', {
        method: req.method,
        url: req.url,
        ip: req.ip,
        timeout,
      });

      if (!res.headersSent) {
        res.status(408).json({
          error: 'Request Timeout',
          message: 'The request took too long to process',
        });
      }
    });

    next();
  };
}

/**
 * 速率限制错误处理
 * @param {Object} req - Express请求对象
 * @param {Object} res - Express响应对象
 */
function rateLimitHandler(req, res) {
  logger.warn('速率限制触发', {
    ip: req.ip,
    url: req.url,
  });

  res.status(429).json({
    error: 'Too Many Requests',
    message: 'Rate limit exceeded, please try again later',
    retryAfter: 60, // 秒
  });
}

/**
 * CORS错误处理
 * @param {Error} err - 错误对象
 * @param {Object} req - Express请求对象
 * @param {Object} res - Express响应对象
 * @param {Function} next - Next函数
 */
function corsErrorHandler(err, req, res, next) {
  if (err.message === 'Not allowed by CORS') {
    logger.warn('CORS错误', {
      origin: req.headers.origin,
      method: req.method,
      url: req.url,
    });

    return res.status(403).json({
      error: 'CORS Error',
      message: 'Cross-Origin Request Blocked',
    });
  }

  next(err);
}

module.exports = {
  notFoundHandler,
  errorHandler,
  asyncHandler,
  validationErrorHandler,
  databaseErrorHandler,
  timeoutHandler,
  rateLimitHandler,
  corsErrorHandler,
};
