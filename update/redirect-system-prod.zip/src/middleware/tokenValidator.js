/**
 * ============================================
 * Token验证中间件（短Token版本）
 * ============================================
 * 功能：
 * 1. 验证10位短Token的有效性
 * 2. 从Redis获取Token数据
 * 3. 检查Token是否过期
 * 4. 检查Token使用次数
 * 5. 将Token数据附加到请求对象
 * 
 * ⚠️ URL格式：https://domain.com/xxxxxxxxxx（10位Token作为路径参数）
 * ============================================
 */

const TokenGenerator = require('../utils/tokenGenerator');
const Database = require('../database/mysql');
const logger = require('../utils/logger');
const { config } = require('../config');
const crypto = require('crypto');

/**
 * 生成友好的404错误页面
 * @returns {string} HTML页面
 */
function generate404Page() {
  return `
    <!DOCTYPE html>
    <html lang="ja">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>404 - お探しのページは見つかりませんでした</title>
      <style>
        * { 
          margin: 0; 
          padding: 0; 
          box-sizing: border-box; 
        }
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Hiragino Sans", "Hiragino Kaku Gothic ProN", "Yu Gothic", Meiryo, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 20px;
          padding: 70px 50px;
          max-width: 550px;
          width: 100%;
          text-align: center;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          animation: fadeIn 0.6s ease-out;
        }
        @keyframes fadeIn {
          from { 
            opacity: 0; 
            transform: translateY(30px); 
          }
          to { 
            opacity: 1; 
            transform: translateY(0); 
          }
        }
        .error-code {
          font-size: 120px;
          font-weight: 700;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          line-height: 1;
          margin-bottom: 20px;
          letter-spacing: -2px;
        }
        .icon {
          font-size: 60px;
          margin-bottom: 25px;
          animation: bounce 2s infinite ease-in-out;
          display: inline-block;
        }
        @keyframes bounce {
          0%, 100% { 
            transform: translateY(0); 
          }
          50% { 
            transform: translateY(-15px); 
          }
        }
        h1 {
          font-size: 28px;
          color: #2c3e50;
          margin-bottom: 18px;
          font-weight: 600;
          line-height: 1.4;
        }
        p {
          font-size: 16px;
          color: #7f8c8d;
          line-height: 1.8;
          margin-bottom: 40px;
          max-width: 450px;
          margin-left: auto;
          margin-right: auto;
          text-align: left;
        }
        .btn {
          display: inline-block;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 16px 45px;
          border-radius: 12px;
          text-decoration: none;
          font-size: 16px;
          font-weight: 600;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 8px 20px rgba(102, 126, 234, 0.35);
          letter-spacing: 0.5px;
        }
        .btn:hover {
          transform: translateY(-3px);
          box-shadow: 0 12px 28px rgba(102, 126, 234, 0.45);
        }
        .btn:active {
          transform: translateY(-1px);
          box-shadow: 0 6px 16px rgba(102, 126, 234, 0.35);
        }
        
        /* 额外的装饰元素 */
        .divider {
          width: 100%;
          max-width: 450px;
          height: 5px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          margin: 20px auto;
          border-radius: 2px;
        }
        
        @media (max-width: 600px) {
          .container {
            padding: 50px 30px;
          }
          .error-code {
            font-size: 90px;
          }
          h1 {
            font-size: 22px;
          }
          p {
            font-size: 15px;
            margin-bottom: 35px;
          }
          .icon {
            font-size: 50px;
          }
          .btn {
            padding: 14px 35px;
            font-size: 15px;
          }
          .divider {
            max-width: 280px;
          }
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="error-code">404</div>
        <div class="icon">🔍</div>
        <h2>お探しのページは見つかりませんでした</h2>
        <div class="divider"></div>
        <p>該当のページはアドレスが変更されたか、ページが削除された可能性があります。</p>
        <a href="/" class="btn">トップページへ戻る</a>
      </div>
    </body>
    </html>
  `;
}

/**
 * Token验证中间件
 */
async function tokenValidator(req, res, next) {
  // ✅ 从路径参数获取Token（URL格式：/xxxxxxxxxx）
  const token = req.params.token;

  try {
    // 1. 检查Token是否存在
    if (!token) {
      logger.warn('缺少Token参数', {
        ip: req.ip,
        url: req.url,
      });

      // ✅ 返回友好的404页面
      return res.status(404).send(generate404Page());
    }

    // 2. 检查Token格式（必须是10位）
    if (token.length !== 10) {
      logger.warn('Token格式错误', {
        ip: req.ip,
        tokenLength: token.length,
        expectedLength: 10
      });

      // ✅ 返回友好的404页面
      return res.status(404).send(generate404Page());
    }

    // 3. 验证Token（从Redis获取数据）
    const verifyResult = await TokenGenerator.verify(token);

    if (!verifyResult.valid) {
      logger.warn('Token验证失败', {
        ip: req.ip,
        reason: verifyResult.reason,
        token: token.substring(0, 4) + '****',
      });

      // ✅ 所有Token验证失败都返回友好的404页面
      return res.status(404).send(generate404Page());
    }

    // 4. 获取Token数据
    const tokenData = verifyResult.data;

    // 5. 生成Token哈希（用于数据库记录）
    const tokenHash = crypto
      .createHash('sha256')
      .update(token)
      .digest('hex')
      .substring(0, 16); // 哈希值取前16位，与Token长度无关

    // 6. 检查Token使用次数
    const usageCheck = await checkTokenUsage(tokenHash, tokenData);

    if (!usageCheck.allowed) {
      logger.warn('Token使用次数超限', {
        ip: req.ip,
        emailId: tokenData.eid,
        useCount: usageCheck.useCount,
        maxUses: usageCheck.maxUses,
      });

      // ✅ Token使用超限也返回友好的404页面
      return res.status(404).send(generate404Page());
    }

    // 7. Token验证通过，附加数据到请求对象
    req.tokenData = tokenData;
    req.tokenHash = tokenHash;
    req.shortToken = token;

    logger.debug('Token验证通过', {
      ip: req.ip,
      emailId: tokenData.eid,
    });

    next();

  } catch (error) {
    logger.error('Token验证过程出错', {
      ip: req.ip,
      error: error.message,
      stack: error.stack
    });

    // ✅ 服务器错误也返回友好的404页面
    return res.status(404).send(generate404Page());
  }
}

/**
 * 检查Token使用次数
 * @param {string} tokenHash - Token哈希
 * @param {Object} tokenData - Token数据
 * @returns {Promise<Object>} - 检查结果
 */
async function checkTokenUsage(tokenHash, tokenData) {
  try {
    // 查询Token使用记录
    const usage = await Database.getTokenUsage(tokenHash);

    if (!usage) {
      // Token首次使用，允许通过
      return {
        allowed: true,
        useCount: 0,
        maxUses: config.token.maxUses || 999999,
      };
    }

    // 检查是否超过最大使用次数
    const maxUses = usage.max_uses || config.token.maxUses || 999999;
    const allowed = usage.use_count < maxUses;

    return {
      allowed,
      useCount: usage.use_count,
      maxUses,
    };
  } catch (error) {
    logger.error('查询Token使用失败', {
      error: error.message,
      tokenHash: tokenHash.substring(0, 8) + '...',
    });

    // 出错时允许通过（保守策略）
    return {
      allowed: true,
      useCount: 0,
      maxUses: config.token.maxUses || 999999,
      error: error.message,
    };
  }
}

/**
 * 记录Token使用（在请求处理完成后调用）
 * @param {string} tokenHash - Token哈希
 * @param {Object} tokenData - Token数据
 * @param {string} ip - IP地址
 * @returns {Promise<void>}
 */
async function recordTokenUsage(tokenHash, tokenData, ip) {
  try {
    const expiresAt = new Date(tokenData.exp);
    await Database.recordTokenUsage(
      tokenHash,
      tokenData.eid,
      config.token.maxUses || 999999,
      expiresAt
    );
    
    logger.debug('Token使用已记录', {
      tokenHash: tokenHash.substring(0, 8) + '...',
      emailId: tokenData.eid,
      ip: ip
    });
  } catch (error) {
    logger.error('记录Token使用失败', {
      error: error.message,
      emailId: tokenData.eid,
    });
  }
}

module.exports = {
  tokenValidator,
  checkTokenUsage,
  recordTokenUsage,
};
