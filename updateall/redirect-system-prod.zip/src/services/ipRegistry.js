/**
 * ============================================
 * IP信息采集服务
 * ============================================
 * 功能：
 * 1. 调用ipregistry API获取IP详细信息
 * 2. 缓存IP信息减少API调用
 * 3. 解析和格式化IP数据
 * 4. 错误处理和降级策略
 * 5. 支持从数据库动态读取API Key（优先级高于.env）
 * ============================================
 */

const axios = require('axios');
const { config } = require('../config');
const logger = require('../utils/logger');
const Cache = require('../utils/cache');
const Database = require('../database/mysql');

/**
 * IP信息采集服务类
 */
class IPRegistryService {
  // 缓存的API Key（避免每次请求都查数据库）
  static _cachedApiKey = null;
  static _apiKeyCacheTime = 0;
  static _apiKeyCacheTTL = 60000; // API Key缓存60秒

  /**
   * 获取API Key（优先从数据库读取，其次从.env读取）
   * @returns {Promise<string>} - API Key
   * @private
   */
  static async _getApiKey() {
    const now = Date.now();
    
    // 如果缓存的API Key还有效，直接返回
    if (this._cachedApiKey && (now - this._apiKeyCacheTime) < this._apiKeyCacheTTL) {
      return this._cachedApiKey;
    }

    try {
      // 从数据库读取API Key
      const dbConfig = await Database.queryOne(
        'SELECT value FROM config_items WHERE key_name = ? AND category = ? AND is_active = 1',
        ['IPREGISTRY_API_KEY', 'api']
      );

      if (dbConfig && dbConfig.value && dbConfig.value.trim()) {
        this._cachedApiKey = dbConfig.value.trim();
        this._apiKeyCacheTime = now;
        logger.debug('从数据库读取API Key成功', { 
          keyPrefix: this._cachedApiKey.substring(0, 10) + '...' 
        });
        return this._cachedApiKey;
      }
    } catch (error) {
      logger.warn('从数据库读取API Key失败，使用.env配置', { error: error.message });
    }

    // 回退到.env配置
    this._cachedApiKey = config.ipregistry.apiKey;
    this._apiKeyCacheTime = now;
    return this._cachedApiKey;
  }

  /**
   * 清除API Key缓存（当后台修改配置后调用）
   */
  static clearApiKeyCache() {
    this._cachedApiKey = null;
    this._apiKeyCacheTime = 0;
    logger.info('API Key缓存已清除');
  }

  /**
   * 获取IP信息（带缓存）
   * @param {string} ip - IP地址
   * @returns {Promise<Object|null>} - IP信息对象
   */
  static async getIPInfo(ip) {
    try {
      // 1. 检查缓存
      const cacheKey = `ip_info:${ip}`;
      const cached = await Cache.get(cacheKey);
      if (cached) {
        logger.debug('IP信息命中缓存', { ip });
        return cached;
      }

      // 2. 获取API Key
      const apiKey = await this._getApiKey();
      if (!apiKey) {
        logger.error('未配置 IPRegistry API Key');
        return this._getDefaultIPInfo(ip);
      }

      // 3. 调用API
      logger.debug('调用ipregistry API', { ip });
      
      const ipInfo = await this._fetchFromAPI(ip, apiKey);
      
      if (!ipInfo) {
        logger.warn('无法获取IP信息，使用降级数据', { ip });
        return this._getDefaultIPInfo(ip);
      }

      // 4. 格式化数据
      const formatted = this._formatIPInfo(ipInfo);

      // 5. 保存到缓存
      await Cache.set(cacheKey, formatted, config.cache.ipInfoTTL);

      logger.info('IP信息获取成功', {
        ip,
        country: formatted.country.code,
        city: formatted.location.city,
      });

      return formatted;
    } catch (error) {
      logger.error('获取IP信息失败', {
        ip,
        error: error.message,
        stack: error.stack,
      });
      return this._getDefaultIPInfo(ip);
    }
  }

  /**
   * 从API获取IP信息
   * @param {string} ip - IP地址
   * @param {string} apiKey - API密钥
   * @returns {Promise<Object|null>}
   * @private
   */
  static async _fetchFromAPI(ip, apiKey) {
    try {
      const url = `${config.ipregistry.baseURL}/${ip}`;
      const params = {
        key: apiKey,
      };

      logger.debug('发送API请求', { url, timeout: config.ipregistry.timeout });

      const response = await axios.get(url, {
        params,
        timeout: config.ipregistry.timeout,
        headers: {
          'User-Agent': 'RedirectSystem/1.0',
        },
      });

      if (response.status === 200 && response.data) {
        // 检查是否返回了错误（如额度不足）
        if (response.data.code && response.data.message) {
          logger.error('IPRegistry API返回错误', {
            code: response.data.code,
            message: response.data.message,
          });
          return null;
        }
        
        logger.debug('API响应成功', { 
          ip, 
          country: response.data.location?.country?.code 
        });
        return response.data;
      }

      logger.warn('API返回非预期响应', { status: response.status });
      return null;
    } catch (error) {
      // 处理不同类型的错误
      if (error.response) {
        // API返回错误状态码
        const status = error.response.status;
        const errorData = error.response.data;
        const errorMessage = errorData?.message || errorData?.error?.message || 'Unknown error';
        const errorCode = errorData?.code || 'UNKNOWN';
        
        logger.error('ipregistry API错误', {
          ip,
          status,
          code: errorCode,
          message: errorMessage,
        });

        // 如果是额度不足，清除API Key缓存（可能用户会去后台更换Key）
        if (errorCode === 'INSUFFICIENT_CREDITS') {
          logger.error('❌ IPRegistry API额度不足！请更换API Key或充值');
          this.clearApiKeyCache();
        }

        // 如果是401（API Key无效），记录警告
        if (status === 401) {
          logger.error('❌ ipregistry API Key无效！请检查配置', {
            keyPrefix: apiKey?.substring(0, 10) + '...'
          });
          this.clearApiKeyCache();
        }

        // 如果是429（超限），记录警告
        if (status === 429) {
          logger.warn('⚠️ ipregistry API调用超限，请稍后重试');
        }

        // 如果是403（禁止访问）
        if (status === 403) {
          logger.error('❌ ipregistry API访问被禁止，可能是IP被封或账户问题');
        }
      } else if (error.code === 'ECONNABORTED') {
        // 超时
        logger.error('ipregistry API请求超时', { 
          ip, 
          timeout: config.ipregistry.timeout 
        });
      } else if (error.code === 'ENOTFOUND' || error.code === 'EAI_AGAIN') {
        // DNS解析失败
        logger.error('ipregistry API域名解析失败，请检查网络连接', { 
          ip, 
          code: error.code 
        });
      } else if (error.request) {
        // 请求发送但没有响应
        logger.error('ipregistry API无响应', { 
          ip, 
          error: error.message,
          code: error.code 
        });
      } else {
        // 其他错误
        logger.error('ipregistry API请求失败', { 
          ip, 
          error: error.message 
        });
      }

      return null;
    }
  }

  /**
   * 格式化IP信息
   * ⚠️ 重要：security字段使用下划线命名，与securityFilter.js匹配
   * @param {Object} rawData - API返回的原始数据
   * @returns {Object} - 格式化后的数据
   * @private
   */
  static _formatIPInfo(rawData) {
    return {
      // IP地址
      ip: rawData.ip || '',

      // 地理位置
      location: {
        country: rawData.location?.country?.name || '',
        countryCode: rawData.location?.country?.code || '',
        region: rawData.location?.region?.name || '',
        city: rawData.location?.city || '',
        postalCode: rawData.location?.postal || '',
        latitude: rawData.location?.latitude || null,
        longitude: rawData.location?.longitude || null,
        timezone: rawData.time_zone?.id || '',
        continent: {
          code: rawData.location?.continent?.code || '',
          name: rawData.location?.continent?.name || '',
        },
      },

      // 国家信息
      country: {
        name: rawData.location?.country?.name || '',
        code: rawData.location?.country?.code || '',
        flag: rawData.location?.country?.flag?.emoji || '',
      },

      // 连接信息
      connection: {
        type: rawData.connection?.type || 'unknown',
        organization: rawData.connection?.organization || '',
        asn: rawData.connection?.asn || null,
        domain: rawData.connection?.domain || '',
      },

      // ⭐ 安全信息 - 使用下划线命名，与 securityFilter.js 匹配
      security: {
        is_vpn: rawData.security?.is_vpn || false,
        is_proxy: rawData.security?.is_proxy || false,
        is_tor: rawData.security?.is_tor || false,
        is_tor_exit: rawData.security?.is_tor_exit || false,
        is_cloud_provider: rawData.security?.is_cloud_provider || false,
        is_anonymous: rawData.security?.is_anonymous || false,
        is_abuser: rawData.security?.is_abuser || false,
        is_attacker: rawData.security?.is_attacker || false,
        is_bogon: rawData.security?.is_bogon || false,
        is_relay: rawData.security?.is_relay || false,
        is_threat: rawData.security?.is_threat || false,
        is_hosting: rawData.security?.is_hosting || false,
      },

      // 货币信息
      currency: {
        code: rawData.currency?.code || '',
        name: rawData.currency?.name || '',
        symbol: rawData.currency?.symbol || '',
      },

      // 时区信息
      timeZone: {
        id: rawData.time_zone?.id || '',
        abbreviation: rawData.time_zone?.abbreviation || '',
        currentTime: rawData.time_zone?.current_time || '',
        offset: rawData.time_zone?.offset || 0,
      },

      // 原始数据（用于调试）
      _raw: config.debug.verbose ? rawData : null,
    };
  }

  /**
   * 获取默认IP信息（降级处理）
   * ⚠️ 重要：security字段使用下划线命名，与securityFilter.js匹配
   * @param {string} ip - IP地址
   * @returns {Object}
   * @private
   */
  static _getDefaultIPInfo(ip) {
    return {
      ip,
      location: {
        country: 'Unknown',
        countryCode: 'XX',
        region: '',
        city: '',
        postalCode: '',
        latitude: null,
        longitude: null,
        timezone: '',
        continent: {
          code: '',
          name: '',
        },
      },
      country: {
        name: 'Unknown',
        code: 'XX',
        flag: '',
      },
      connection: {
        type: 'unknown',
        organization: '',
        asn: null,
        domain: '',
      },
      // ⭐ 安全信息 - 使用下划线命名
      security: {
        is_vpn: false,
        is_proxy: false,
        is_tor: false,
        is_tor_exit: false,
        is_cloud_provider: false,
        is_anonymous: false,
        is_abuser: false,
        is_attacker: false,
        is_bogon: false,
        is_relay: false,
        is_threat: false,
        is_hosting: false,
      },
      currency: { code: '', name: '', symbol: '' },
      timeZone: { id: '', abbreviation: '', currentTime: '', offset: 0 },
      _raw: null,
      _fallback: true, // 标记为降级数据
    };
  }

  /**
   * 批量获取IP信息
   * @param {string[]} ips - IP地址数组
   * @returns {Promise<Object>} - IP信息映射对象
   */
  static async getIPInfoBatch(ips) {
    const results = {};

    // 并发请求（最多10个）
    const chunkSize = 10;
    for (let i = 0; i < ips.length; i += chunkSize) {
      const chunk = ips.slice(i, i + chunkSize);
      const promises = chunk.map(ip => this.getIPInfo(ip));
      const chunkResults = await Promise.all(promises);

      chunk.forEach((ip, index) => {
        results[ip] = chunkResults[index];
      });
    }

    return results;
  }

  /**
   * 清除IP信息缓存
   * @param {string} ip - IP地址，如果不提供则清除所有
   * @returns {Promise<boolean>}
   */
  static async clearCache(ip = null) {
    try {
      if (ip) {
        await Cache.del(`ip_info:${ip}`);
        logger.info('IP缓存已清除', { ip });
      } else {
        await Cache.delPattern('ip_info:*');
        logger.info('所有IP缓存已清除');
      }
      return true;
    } catch (error) {
      logger.error('清除IP缓存失败', { error: error.message });
      return false;
    }
  }

  /**
   * 获取缓存统计
   * @returns {Promise<Object>}
   */
  static async getCacheStats() {
    try {
      const redis = Cache.getClient();
      const keys = await redis.keys(config.redis.keyPrefix + 'ip_info:*');

      return {
        totalCached: keys.length,
        keyPrefix: config.redis.keyPrefix + 'ip_info:',
      };
    } catch (error) {
      logger.error('获取缓存统计失败', { error: error.message });
      return { totalCached: 0, keyPrefix: '' };
    }
  }

  /**
   * 测试API连接
   * @returns {Promise<Object>} - 测试结果
   */
  static async testAPIConnection() {
    try {
      const testIP = '8.8.8.8'; // Google DNS
      const apiKey = await this._getApiKey();
      
      if (!apiKey) {
        return {
          success: false,
          message: '未配置API Key',
        };
      }

      const startTime = Date.now();
      const result = await this._fetchFromAPI(testIP, apiKey);
      const duration = Date.now() - startTime;

      if (result) {
        logger.info('ipregistry API测试成功', {
          duration: `${duration}ms`,
          ip: testIP,
          country: result.location?.country?.code,
        });
        return {
          success: true,
          duration,
          message: 'API连接正常',
          country: result.location?.country?.code,
        };
      } else {
        return {
          success: false,
          message: 'API返回空数据或错误',
        };
      }
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }
}

module.exports = IPRegistryService;
