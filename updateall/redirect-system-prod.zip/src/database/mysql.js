/**
 * ============================================
 * MySQL数据库连接管理
 * ============================================
 * 功能：
 * 1. 创建和管理MySQL连接池
 * 2. 提供数据库操作的包装方法
 * 3. 自动初始化表结构
 * 4. 错误处理和连接管理
 * ============================================
 */

const mysql = require('mysql2/promise');
const { config } = require('../config');
const logger = require('../utils/logger');
const { initializeTables } = require('./schema');
const { initializeAdminTables, insertDefaultAdmin, initializeDefaultConfig } = require('./admin-schema');
const { initializeTokenBatchTables } = require('./token-batch-schema');

/**
 * MySQL连接池
 */
let pool = null;

/**
 * 数据库操作类
 */
class Database {
  /**
   * 初始化数据库连接池
   * @returns {Promise<void>}
   */
  static async initialize() {
    try {
      // 创建连接池
      pool = mysql.createPool({
        host: config.database.host,
        port: config.database.port,
        database: config.database.name,
        user: config.database.user,
        password: config.database.password,
        connectionLimit: config.database.connectionLimit,
        queueLimit: config.database.queueLimit,
        waitForConnections: true,
        enableKeepAlive: true,
        keepAliveInitialDelay: 0,
      });

      // 测试连接
      const connection = await pool.getConnection();
      logger.info('MySQL连接成功', {
        host: config.database.host,
        port: config.database.port,
        database: config.database.name,
      });

      // 初始化表结构
      await initializeTables(connection);
      
      // 初始化管理后台表
      await initializeAdminTables(connection);
      
      // 插入默认管理员
      await insertDefaultAdmin(connection);
      
      // 初始化默认配置
      await initializeDefaultConfig(connection);

      // 初始化Token批次表
      await initializeTokenBatchTables(connection);

      connection.release();
    } catch (error) {
      logger.error('MySQL初始化失败', {
        error: error.message,
        host: config.database.host,
      });
      throw error;
    }
  }

  /**
   * 获取连接池
   * @returns {Pool}
   */
  static getPool() {
    if (!pool) {
      throw new Error('数据库未初始化，请先调用 Database.initialize()');
    }
    return pool;
  }

  /**
   * 执行查询
   * @param {string} sql - SQL语句
   * @param {Array} params - 参数
   * @returns {Promise<Array>} - 查询结果
   */
  static async query(sql, params = []) {
    try {
      const [rows] = await pool.query(sql, params);
      return rows;
    } catch (error) {
      logger.error('数据库查询失败', {
        sql: sql.substring(0, 100),
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * 执行单条记录查询
   * @param {string} sql - SQL语句
   * @param {Array} params - 参数
   * @returns {Promise<Object|null>} - 单条记录或null
   */
  static async queryOne(sql, params = []) {
    const rows = await this.query(sql, params);
    return rows.length > 0 ? rows[0] : null;
  }

  /**
   * 插入数据
   * @param {string} table - 表名
   * @param {Object} data - 数据对象
   * @returns {Promise<number>} - 插入的ID
   */
  static async insert(table, data) {
    try {
      const keys = Object.keys(data);
      const values = Object.values(data);
      const placeholders = keys.map(() => '?').join(', ');

      const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders})`;
      const [result] = await pool.query(sql, values);

      return result.insertId;
    } catch (error) {
      logger.error('数据插入失败', {
        table,
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * 更新数据
   * @param {string} table - 表名
   * @param {Object} data - 要更新的数据
   * @param {Object} where - WHERE条件
   * @returns {Promise<number>} - 影响的行数
   */
  static async update(table, data, where) {
    try {
      const setClause = Object.keys(data)
        .map(key => `${key} = ?`)
        .join(', ');

      const whereClause = Object.keys(where)
        .map(key => `${key} = ?`)
        .join(' AND ');

      const sql = `UPDATE ${table} SET ${setClause} WHERE ${whereClause}`;
      const params = [...Object.values(data), ...Object.values(where)];

      const [result] = await pool.query(sql, params);
      return result.affectedRows;
    } catch (error) {
      logger.error('数据更新失败', {
        table,
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * 删除数据
   * @param {string} table - 表名
   * @param {Object} where - WHERE条件
   * @returns {Promise<number>} - 影响的行数
   */
  static async delete(table, where) {
    try {
      const whereClause = Object.keys(where)
        .map(key => `${key} = ?`)
        .join(' AND ');

      const sql = `DELETE FROM ${table} WHERE ${whereClause}`;
      const [result] = await pool.query(sql, Object.values(where));

      return result.affectedRows;
    } catch (error) {
      logger.error('数据删除失败', {
        table,
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * 记录访问日志
   * @param {Object} logData - 日志数据
   * @returns {Promise<number>} - 插入的ID
   */
  static async logAccess(logData) {
    try {
      return await this.insert('access_logs', logData);
    } catch (error) {
      logger.error('记录访问日志失败', { error: error.message });
      // 不抛出错误，避免影响主流程
      return null;
    }
  }

  /**
   * 记录Token使用
   * @param {string} tokenHash - Token哈希
   * @param {string} emailId - 邮件ID
   * @param {number} maxUses - 最大使用次数
   * @param {Date} expiresAt - 过期时间
   * @returns {Promise<boolean>}
   */
  static async recordTokenUsage(tokenHash, emailId, maxUses, expiresAt) {
    try {
      // 检查Token是否已存在
      const existing = await this.queryOne(
        'SELECT * FROM token_usage WHERE token_hash = ?',
        [tokenHash]
      );

      if (existing) {
        // 更新使用次数
        await this.query(
          `UPDATE token_usage 
           SET use_count = use_count + 1,
               last_used_at = NOW()
           WHERE token_hash = ?`,
          [tokenHash]
        );
      } else {
        // 插入新记录
        await this.insert('token_usage', {
          token_hash: tokenHash,
          email_id: emailId,
          first_used_at: new Date(),
          last_used_at: new Date(),
          use_count: 1,
          max_uses: maxUses,
          expires_at: expiresAt,
        });
      }

      return true;
    } catch (error) {
      logger.error('记录Token使用失败', { error: error.message });
      return false;
    }
  }

  /**
   * 检查Token使用次数
   * @param {string} tokenHash - Token哈希
   * @returns {Promise<Object|null>} - Token使用信息
   */
  static async getTokenUsage(tokenHash) {
    try {
      return await this.queryOne(
        'SELECT * FROM token_usage WHERE token_hash = ?',
        [tokenHash]
      );
    } catch (error) {
      logger.error('查询Token使用失败', { error: error.message });
      return null;
    }
  }

  /**
   * 更新IP信誉
   * @param {string} ip - IP地址
   * @param {Object} data - 更新数据
   * @param {boolean} data.allowed - 是否允许访问（替代success字段）
   * @param {string} data.countryCode - 国家代码
   * @returns {Promise<boolean>}
   */
  static async updateIPReputation(ip, data) {
    try {
      const existing = await this.queryOne(
        'SELECT * FROM ip_reputation WHERE ip = ?',
        [ip]
      );

      // ✅ 修复：使用 allowed 字段替代 success 字段
      const allowed = data.allowed !== undefined ? data.allowed : true;

      if (existing) {
        // 更新现有记录
        const updates = {
          total_visits: existing.total_visits + 1,
          last_visit_at: new Date(),
        };

        // 更新成功/拒绝计数
        if (allowed) {
          updates.successful_visits = existing.successful_visits + 1;
        } else {
          updates.rejected_visits = existing.rejected_visits + 1;
        }

        // 重新计算信誉分数
        updates.reputation_score = this._calculateReputationScore(
          existing.reputation_score,
          allowed
        );

        // 添加国家代码（如果提供）
        if (data.countryCode) {
          updates.country_code = data.countryCode;
        }

        await this.update('ip_reputation', updates, { ip });
      } else {
        // 插入新记录
        await this.insert('ip_reputation', {
          ip,
          reputation_score: allowed ? 52 : 48,
          total_visits: 1,
          successful_visits: allowed ? 1 : 0,
          rejected_visits: allowed ? 0 : 1,
          last_visit_at: new Date(),
          country_code: data.countryCode || null,
        });
      }

      return true;
    } catch (error) {
      logger.error('更新IP信誉失败', { error: error.message });
      return false;
    }
  }

  /**
   * 计算信誉分数
   * @param {number} currentScore - 当前分数
   * @param {boolean} success - 是否成功
   * @returns {number} - 新分数
   * @private
   */
  static _calculateReputationScore(currentScore, success) {
    if (success) {
      return Math.min(100, currentScore + 2);
    } else {
      return Math.max(-100, currentScore - 5);
    }
  }

  /**
   * 获取IP信誉
   * @param {string} ip - IP地址
   * @returns {Promise<Object|null>}
   */
  static async getIPReputation(ip) {
    try {
      return await this.queryOne(
        'SELECT * FROM ip_reputation WHERE ip = ?',
        [ip]
      );
    } catch (error) {
      logger.error('查询IP信誉失败', { error: error.message });
      return null;
    }
  }

  /**
   * 关闭数据库连接池
   * @returns {Promise<void>}
   */
  static async close() {
    if (pool) {
      try {
        await pool.end();
        logger.info('MySQL连接池已关闭');
      } catch (error) {
        logger.error('关闭MySQL连接池失败', { error: error.message });
      }
    }
  }

  /**
   * 获取数据库统计信息
   * @returns {Promise<Object>}
   */
  static async getStats() {
    try {
      const stats = {};

      // 访问日志统计
      const accessStats = await this.queryOne(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN filter_decision = 'allow' THEN 1 END) as allowed,
          COUNT(CASE WHEN filter_decision = 'reject' THEN 1 END) as rejected,
          AVG(process_time_ms) as avg_process_time
        FROM access_logs
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
      `);

      stats.last24Hours = accessStats;

      // IP信誉统计
      const ipStats = await this.queryOne(`
        SELECT 
          COUNT(*) as total_ips,
          COUNT(CASE WHEN is_blacklisted = 1 THEN 1 END) as blacklisted,
          COUNT(CASE WHEN is_whitelisted = 1 THEN 1 END) as whitelisted
        FROM ip_reputation
      `);

      stats.ipReputation = ipStats;

      return stats;
    } catch (error) {
      logger.error('获取统计信息失败', { error: error.message });
      return null;
    }
  }
}

// 优雅退出时关闭连接
process.on('SIGINT', async () => {
  await Database.close();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await Database.close();
  process.exit(0);
});

module.exports = Database;
