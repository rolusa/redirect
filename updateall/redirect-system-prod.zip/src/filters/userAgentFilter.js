/**
 * UserAgent 过滤器
 * 用于过滤基于浏览器、设备、操作系统的访问
 * 
 * 功能：
 * - Browser浏览器过滤（包含Bot检测）
 * - Device设备类型过滤
 * - OS操作系统过滤
 * 
 * 版本: 1.0 (方案B：核心功能)
 * 日期: 2025-11-22
 */

const logger = require('../utils/logger');
const Database = require('../database/mysql');

class UserAgentFilter {
  constructor() {
    // 配置缓存
    this.configCache = null;
    this.cacheExpiry = 0;
    this.cacheTTL = 10000; // 缓存10秒

    // 常见浏览器列表
    this.commonBrowsers = [
      'Chrome', 'Firefox', 'Safari', 'Edge', 'Opera', 
      'IE', 'Samsung Browser', 'UC Browser', 'Brave'
    ];

    // 常见设备类型
    this.deviceTypes = [
      'desktop', 'mobile', 'tablet', 'tv', 'console', 
      'wearable', 'car', 'bot'
    ];

    // 常见操作系统
    this.commonOS = [
      'Windows', 'macOS', 'iOS', 'Android', 'Linux',
      'Chrome OS', 'Ubuntu', 'Debian', 'CentOS'
    ];
  }

  /**
   * 获取UserAgent配置（带缓存）
   * @returns {Promise<Object>} UserAgent配置对象
   */
  async getConfig() {
    const now = Date.now();
    
    // 使用缓存
    if (this.configCache && now < this.cacheExpiry) {
      return this.configCache;
    }

    try {
      const config = {
        // Browser配置
        browserMode: 'off',
        allowedBrowsers: [],
        blockedBrowsers: [],
        blockBots: false,
        allowedUATypes: [],
        
        // Device配置
        deviceMode: 'off',
        allowedDeviceTypes: [],
        blockedDeviceTypes: [],
        
        // OS配置
        osMode: 'off',
        allowedOS: [],
        blockedOS: [],
        allowedOSTypes: []
      };

      // 从数据库读取Browser配置
      const browserConfigs = await Database.query(
        'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
        ['browser']
      );

      browserConfigs.forEach(item => {
        const value = item.value || '';
        switch (item.key_name) {
          case 'BROWSER_MODE':
            config.browserMode = value;
            break;
          case 'ALLOWED_BROWSERS':
            config.allowedBrowsers = value.split(',').map(b => b.trim()).filter(b => b);
            break;
          case 'BLOCKED_BROWSERS':
            config.blockedBrowsers = value.split(',').map(b => b.trim()).filter(b => b);
            break;
          case 'BLOCK_BOTS':
            config.blockBots = value === 'true';
            break;
          case 'ALLOWED_UA_TYPES':
            config.allowedUATypes = value.split(',').map(t => t.trim()).filter(t => t);
            break;
        }
      });

      // 从数据库读取Device配置
      const deviceConfigs = await Database.query(
        'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
        ['device']
      );

      deviceConfigs.forEach(item => {
        const value = item.value || '';
        switch (item.key_name) {
          case 'DEVICE_MODE':
            config.deviceMode = value;
            break;
          case 'ALLOWED_TYPES':
            config.allowedDeviceTypes = value.split(',').map(t => t.trim()).filter(t => t);
            break;
          case 'BLOCKED_TYPES':
            config.blockedDeviceTypes = value.split(',').map(t => t.trim()).filter(t => t);
            break;
        }
      });

      // 从数据库读取OS配置
      const osConfigs = await Database.query(
        'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
        ['os']
      );

      osConfigs.forEach(item => {
        const value = item.value || '';
        switch (item.key_name) {
          case 'OS_MODE':
            config.osMode = value;
            break;
          case 'ALLOWED_OS':
            config.allowedOS = value.split(',').map(o => o.trim()).filter(o => o);
            break;
          case 'BLOCKED_OS':
            config.blockedOS = value.split(',').map(o => o.trim()).filter(o => o);
            break;
          case 'ALLOWED_OS_TYPES':
            config.allowedOSTypes = value.split(',').map(t => t.trim()).filter(t => t);
            break;
        }
      });

      // 更新缓存
      this.configCache = config;
      this.cacheExpiry = now + this.cacheTTL;

      logger.debug('UserAgent Filter: Loaded config', { config });
      return config;

    } catch (error) {
      logger.error('UserAgent Filter: Failed to load config', { error: error.message });
      
      // 降级到默认配置（全部关闭）
      return {
        browserMode: 'off',
        allowedBrowsers: [],
        blockedBrowsers: [],
        blockBots: false,
        allowedUATypes: [],
        deviceMode: 'off',
        allowedDeviceTypes: [],
        blockedDeviceTypes: [],
        osMode: 'off',
        allowedOS: [],
        blockedOS: [],
        allowedOSTypes: []
      };
    }
  }

  /**
   * 执行UserAgent过滤
   * @param {Object} ipInfo - IP信息对象
   * @param {Object} request - Express请求对象
   * @returns {Promise<Object>} { passed: boolean, reason: string, details: object }
   */
  async filter(ipInfo, request) {
    try {
      const config = await this.getConfig();
      const ua = ipInfo?.user_agent || {};
      const uaHeader = request.headers['user-agent'] || '';

      logger.debug('UserAgent Filter: Processing', {
        ip: ipInfo.ip,
        browser: ua.name,
        device: ua.device?.type,
        os: ua.os?.name
      });

      // ========== 1. Browser浏览器过滤 ==========
      if (config.browserMode !== 'off') {
        const browserName = ua.name || 'Unknown';
        const uaType = ua.type || 'unknown';

        // 检查UA类型白名单
        if (config.allowedUATypes.length > 0) {
          if (!config.allowedUATypes.includes(uaType)) {
            logger.info('UserAgent Filter: UA type not allowed', {
              ip: ipInfo.ip,
              type: uaType
            });
            return {
              passed: false,
              reason: `UA type "${uaType}" not in whitelist`,
              details: {
                type: 'ua_type_not_allowed',
                uaType: uaType
              }
            };
          }
        }

        // 检查Bot
        if (config.blockBots && uaType === 'bot') {
          logger.warn('UserAgent Filter: Bot detected', {
            ip: ipInfo.ip,
            browser: browserName
          });
          return {
            passed: false,
            reason: 'Bot detected and blocked',
            details: {
              type: 'bot_blocked',
              browser: browserName
            }
          };
        }

        // 白名单模式 - 检查浏览器
        if (config.browserMode === 'whitelist') {
          // 不区分大小写比较
          const isAllowed = config.allowedBrowsers.some(allowed => 
            browserName.toLowerCase().includes(allowed.toLowerCase()) ||
            allowed.toLowerCase().includes(browserName.toLowerCase())
          );

          if (!isAllowed) {
            logger.info('UserAgent Filter: Browser not in whitelist', {
              ip: ipInfo.ip,
              browser: browserName
            });
            return {
              passed: false,
              reason: `Browser "${browserName}" not in whitelist`,
              details: {
                type: 'browser_not_allowed',
                browser: browserName
              }
            };
          }
        }

        // 黑名单模式 - 检查浏览器
        if (config.browserMode === 'blacklist') {
          const isBlocked = config.blockedBrowsers.some(blocked => 
            browserName.toLowerCase().includes(blocked.toLowerCase()) ||
            blocked.toLowerCase().includes(browserName.toLowerCase())
          );

          if (isBlocked) {
            logger.warn('UserAgent Filter: Browser in blacklist', {
              ip: ipInfo.ip,
              browser: browserName
            });
            return {
              passed: false,
              reason: `Browser "${browserName}" is in blacklist`,
              details: {
                type: 'browser_blocked',
                browser: browserName
              }
            };
          }
        }
      }

      // ========== 2. Device设备过滤 ==========
      if (config.deviceMode !== 'off') {
        const deviceType = ua.device?.type || 'unknown';

        // 白名单模式 - 检查设备类型
        if (config.deviceMode === 'whitelist') {
          if (!config.allowedDeviceTypes.includes(deviceType)) {
            logger.info('UserAgent Filter: Device type not in whitelist', {
              ip: ipInfo.ip,
              device: deviceType
            });
            return {
              passed: false,
              reason: `Device type "${deviceType}" not in whitelist`,
              details: {
                type: 'device_not_allowed',
                deviceType: deviceType
              }
            };
          }
        }

        // 黑名单模式 - 检查设备类型
        if (config.deviceMode === 'blacklist') {
          if (config.blockedDeviceTypes.includes(deviceType)) {
            logger.warn('UserAgent Filter: Device type in blacklist', {
              ip: ipInfo.ip,
              device: deviceType
            });
            return {
              passed: false,
              reason: `Device type "${deviceType}" is in blacklist`,
              details: {
                type: 'device_blocked',
                deviceType: deviceType
              }
            };
          }
        }
      }

      // ========== 3. OS操作系统过滤 ==========
      if (config.osMode !== 'off') {
        const osName = ua.os?.name || 'Unknown';
        const osType = ua.os?.type || 'unknown';

        // 检查OS类型白名单（如果配置了）
        if (config.allowedOSTypes.length > 0) {
          if (!config.allowedOSTypes.includes(osType)) {
            logger.info('UserAgent Filter: OS type not allowed', {
              ip: ipInfo.ip,
              osType: osType
            });
            return {
              passed: false,
              reason: `OS type "${osType}" not in whitelist`,
              details: {
                type: 'os_type_not_allowed',
                osType: osType
              }
            };
          }
        }

        // 白名单模式 - 检查OS
        if (config.osMode === 'whitelist') {
          const isAllowed = config.allowedOS.some(allowed => 
            osName.toLowerCase().includes(allowed.toLowerCase()) ||
            allowed.toLowerCase().includes(osName.toLowerCase())
          );

          if (!isAllowed) {
            logger.info('UserAgent Filter: OS not in whitelist', {
              ip: ipInfo.ip,
              os: osName
            });
            return {
              passed: false,
              reason: `OS "${osName}" not in whitelist`,
              details: {
                type: 'os_not_allowed',
                os: osName
              }
            };
          }
        }

        // 黑名单模式 - 检查OS
        if (config.osMode === 'blacklist') {
          const isBlocked = config.blockedOS.some(blocked => 
            osName.toLowerCase().includes(blocked.toLowerCase()) ||
            blocked.toLowerCase().includes(osName.toLowerCase())
          );

          if (isBlocked) {
            logger.warn('UserAgent Filter: OS in blacklist', {
              ip: ipInfo.ip,
              os: osName
            });
            return {
              passed: false,
              reason: `OS "${osName}" is in blacklist`,
              details: {
                type: 'os_blocked',
                os: osName
              }
            };
          }
        }
      }

      // 全部检查通过
      logger.debug('UserAgent Filter: Passed', {
        ip: ipInfo.ip,
        browser: ua.name,
        device: ua.device?.type,
        os: ua.os?.name
      });

      return {
        passed: true,
        reason: 'UserAgent filter passed',
        details: {
          browser: ua.name,
          browserVersion: ua.version,
          deviceType: ua.device?.type,
          deviceBrand: ua.device?.brand,
          os: ua.os?.name,
          osVersion: ua.os?.version
        }
      };

    } catch (error) {
      logger.error('UserAgent Filter: Error during filtering', {
        error: error.message,
        stack: error.stack,
        ip: ipInfo?.ip
      });

      // 出错时采取保守策略：允许通过
      return {
        passed: true,
        reason: 'UserAgent filter error - allowing by default',
        details: {
          error: error.message
        }
      };
    }
  }

  /**
   * 清除配置缓存
   */
  clearCache() {
    this.configCache = null;
    this.cacheExpiry = 0;
    logger.info('UserAgent Filter: Cache cleared');
  }

  /**
   * 获取配置摘要（用于管理后台显示）
   * @returns {Promise<Object>} 配置摘要
   */
  async getConfigSummary() {
    const config = await this.getConfig();
    
    return {
      browser: {
        mode: config.browserMode,
        allowedCount: config.allowedBrowsers.length,
        blockedCount: config.blockedBrowsers.length,
        blockBots: config.blockBots
      },
      device: {
        mode: config.deviceMode,
        allowedCount: config.allowedDeviceTypes.length,
        blockedCount: config.blockedDeviceTypes.length
      },
      os: {
        mode: config.osMode,
        allowedCount: config.allowedOS.length,
        blockedCount: config.blockedOS.length
      },
      config: config
    };
  }
}

module.exports = new UserAgentFilter();
