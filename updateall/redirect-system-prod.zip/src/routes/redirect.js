/**
 * ============================================
 * 重定向路由
 * ============================================
 * 功能：
 * 1. 处理/:token路由（主要的重定向端点）
 * 2. 调用过滤引擎进行验证
 * 3. 根据验证结果进行重定向
 * 4. 提供测试和管理端点
 * 
 * ⚠️ 重要：路由定义顺序
 * - 具体路径（/health, /generate-token等）必须在动态路由（/:token）之前定义
 * - 根路径 / 也需要单独处理
 * - 动态路由 /:token 必须放在最后
 * ============================================
 */

const express = require('express');
const router = express.Router();
const { tokenValidator, recordTokenUsage } = require('../middleware/tokenValidator');
const { asyncHandler } = require('../middleware/errorHandler');
const IPRegistryService = require('../services/ipRegistry');
const FilterEngine = require('../services/filterEngine');
const TokenGenerator = require('../utils/tokenGenerator');
const BehaviorFilter = require('../filters/behaviorFilter');
const logger = require('../utils/logger');
const { config } = require('../config');

/**
 * 生成友好的404错误页面（日文）
 * @returns {string} HTML页面
 */
function generate404Page() {
  return `
    <!DOCTYPE html>
    <html lang="ja">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>404 - お探しのページは見つかりませんでした</title>
      <style>
        * { 
          margin: 0; 
          padding: 0; 
          box-sizing: border-box; 
        }
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Hiragino Sans", "Hiragino Kaku Gothic ProN", "Yu Gothic", Meiryo, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 20px;
          padding: 70px 50px;
          max-width: 550px;
          width: 100%;
          text-align: center;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          animation: fadeIn 0.6s ease-out;
        }
        @keyframes fadeIn {
          from { 
            opacity: 0; 
            transform: translateY(30px); 
          }
          to { 
            opacity: 1; 
            transform: translateY(0); 
          }
        }
        .error-code {
          font-size: 120px;
          font-weight: 700;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          line-height: 1;
          margin-bottom: 20px;
          letter-spacing: -2px;
        }
        .icon {
          font-size: 60px;
          margin-bottom: 25px;
          animation: bounce 2s infinite ease-in-out;
          display: inline-block;
        }
        @keyframes bounce {
          0%, 100% { 
            transform: translateY(0); 
          }
          50% { 
            transform: translateY(-15px); 
          }
        }
        h1 {
          font-size: 28px;
          color: #2c3e50;
          margin-bottom: 18px;
          font-weight: 600;
          line-height: 1.4;
        }
        p {
          font-size: 16px;
          color: #7f8c8d;
          line-height: 1.8;
          margin-bottom: 40px;
          max-width: 450px;
          margin-left: auto;
          margin-right: auto;
          text-align: left;
        }
        .btn {
          display: inline-block;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 16px 45px;
          border-radius: 12px;
          text-decoration: none;
          font-size: 16px;
          font-weight: 600;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 8px 20px rgba(102, 126, 234, 0.35);
          letter-spacing: 0.5px;
        }
        .btn:hover {
          transform: translateY(-3px);
          box-shadow: 0 12px 28px rgba(102, 126, 234, 0.45);
        }
        .btn:active {
          transform: translateY(-1px);
          box-shadow: 0 6px 16px rgba(102, 126, 234, 0.35);
        }

        .divider {
          width: 100%;
          max-width: 450px;
          height: 5px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          margin: 20px auto;
          border-radius: 2px;
        }
        
        @media (max-width: 600px) {
          .container {
            padding: 50px 30px;
          }
          .error-code {
            font-size: 90px;
          }
          h1 {
            font-size: 22px;
          }
          p {
            font-size: 15px;
            margin-bottom: 35px;
          }
          .icon {
            font-size: 50px;
          }
          .btn {
            padding: 14px 35px;
            font-size: 15px;
          }
          .divider {
            max-width: 280px;
          }
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="error-code">404</div>
        <div class="icon">🔍</div>
        <h2>お探しのページは見つかりませんでした</h2>
        <div class="divider"></div>
        <p>該当のページはアドレスが変更されたか、ページが削除された可能性があります。</p>
        <a href="/" class="btn">トップページへ戻る</a>
      </div>
    </body>
    </html>
  `;
}

// ============================================
// 📌 具体路径路由（必须在动态路由之前定义）
// ============================================

/**
 * 健康检查端点
 * GET /health
 */
router.get('/health', asyncHandler(async (req, res) => {
  const health = {
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: config.server.env,
  };

  // 检查关键服务
  try {
    // 测试Redis
    const Cache = require('../utils/cache');
    await Cache.get('health_check');
    health.redis = 'ok';
  } catch (error) {
    health.redis = 'error';
    health.status = 'degraded';
  }

  try {
    // 测试MySQL
    const Database = require('../database/mysql');
    await Database.query('SELECT 1');
    health.database = 'ok';
  } catch (error) {
    health.database = 'error';
    health.status = 'degraded';
  }

  const statusCode = health.status === 'ok' ? 200 : 503;
  res.status(statusCode).json(health);
}));

/**
 * 生成Token测试端点（仅开发环境）
 * GET /generate-token?email=xxx
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.get('/generate-token', asyncHandler(async (req, res) => {
    const email = req.query.email || 'test@example.com';

    try {
      const tokenResult = await TokenGenerator.generate({
        emailId: `email-${Date.now()}`,
        recipientEmail: email,
      });

      const token = tokenResult.token;
      const verifyResult = await TokenGenerator.verify(token);
      const ttl = await TokenGenerator.getTimeToLive(token);

      res.json({
        success: true,
        token,
        // ✅ 新格式：使用路径参数
        testURL: `${req.protocol}://${req.get('host')}/${token}`,
        tokenInfo: {
          emailId: verifyResult.data.eid,
          expiresAt: new Date(verifyResult.data.exp).toISOString(),
          timeToLive: `${Math.floor(ttl / 3600)} hours`,
          createdAt: new Date(verifyResult.data.ts).toISOString(),
        },
      });
    } catch (error) {
      logger.error('生成Token失败', {
        error: error.message,
        stack: error.stack
      });
      res.status(500).json({
        error: 'Failed to generate token',
        message: error.message,
      });
    }
  }));
}

/**
 * 统计信息端点（仅开发环境）
 * GET /stats
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.get('/stats', asyncHandler(async (req, res) => {
    const stats = await FilterEngine.getStats();
    const cacheStats = await require('../services/ipRegistry').getCacheStats();

    res.json({
      success: true,
      data: {
        ...stats,
        cache: cacheStats,
      },
    });
  }));
}

/**
 * 测试过滤器端点（仅开发环境）
 * POST /test-filter
 * Body: { ip, userAgent, language, isVPN, etc... }
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.post('/test-filter', asyncHandler(async (req, res) => {
    const result = await FilterEngine.test(req.body);
    res.json({
      success: true,
      result,
    });
  }));
}

/**
 * 清除IP记录端点（仅开发环境）
 * POST /clear-ip
 * Body: { ip }
 */
if (config.server.env === 'development' || config.debug.enabled) {
  router.post('/clear-ip', asyncHandler(async (req, res) => {
    const { ip } = req.body;

    if (!ip) {
      return res.status(400).json({
        error: 'Missing ip parameter',
      });
    }

    await BehaviorFilter.clearIPRecords(ip);
    await require('../services/ipRegistry').clearCache(ip);

    res.json({
      success: true,
      message: `Records cleared for IP: ${ip}`,
    });
  }));
}

// ============================================
// 📌 根路径处理（返回友好的404页面）
// ============================================

/**
 * 根路径处理
 * GET /
 * 
 * 访问根路径时返回友好的日文404页面
 */
router.get('/', (req, res) => {
  res.status(404).send(generate404Page());
});

// ============================================
// 📌 动态路由（必须放在最后，否则会匹配所有请求）
// ============================================

/**
 * 主重定向端点
 * GET /:token
 * 
 * URL格式：https://domain.com/xxxxxxxxxx（10位Token）
 */
router.get('/:token', tokenValidator, asyncHandler(async (req, res) => {
  const startTime = Date.now();
  const ip = req.ip || req.connection.remoteAddress;

  try {
    // 1. 获取IP信息
    logger.info('处理重定向请求', {
      ip,
      emailId: req.tokenData.eid,
    });

    const ipInfo = await IPRegistryService.getIPInfo(ip);

    // 2. 执行过滤
    const filterResult = await FilterEngine.filter(ipInfo, req, req.tokenData);

    // 3. 记录Token使用（异步，不阻塞）
    recordTokenUsage(req.tokenHash, req.tokenData).catch(err => {
      logger.error('记录Token使用失败', { error: err.message });
    });

    // 4. 根据过滤结果重定向
    const redirectURL = filterResult.redirectTo;
    
    // ========== 调试日志 ==========
    console.log('🔍 [DEBUG] filterResult:', JSON.stringify(filterResult, null, 2));
    console.log('🔍 [DEBUG] redirectURL 类型:', typeof redirectURL);
    console.log('🔍 [DEBUG] redirectURL 值:', redirectURL);
    console.log('🔍 [DEBUG] redirectURL === undefined:', redirectURL === undefined);
    console.log('🔍 [DEBUG] redirectURL === null:', redirectURL === null);
    console.log('🔍 [DEBUG] redirectURL === "":', redirectURL === '');
    // ========== 调试日志结束 ==========

    if (filterResult.decision === 'allow') {
      logger.info('访问允许，重定向到目标', {
        ip,
        emailId: req.tokenData.eid,
        redirectTo: redirectURL,
        processTime: filterResult.processTime,
      });
    } else {
      logger.warn('访问被拒绝', {
        ip,
        emailId: req.tokenData.eid,
        reason: filterResult.reason,
        score: filterResult.score,
        redirectTo: redirectURL,
      });
    }

    // 5. 执行重定向
    res.redirect(302, redirectURL);

  } catch (error) {
    logger.error('重定向处理失败', {
      ip,
      error: error.message,
      stack: error.stack,
    });

    // 出错时重定向到备用URL
    res.redirect(302, config.domains.fallback.medium);
  }
}));

module.exports = router;
