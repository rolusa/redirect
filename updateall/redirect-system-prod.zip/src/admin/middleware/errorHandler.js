/**
 * ============================================
 * 管理后台错误处理中间件
 * ============================================
 */

const logger = require('../../utils/logger');

/**
 * 统一错误处理中间件
 */
function errorHandler(err, req, res, next) {
  logger.error('管理后台错误', {
    error: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method
  });

  // 开发环境返回详细错误，生产环境返回通用错误
  const isDev = process.env.NODE_ENV === 'development';

  res.status(err.status || 500).json({
    success: false,
    message: err.message || '服务器内部错误',
    ...(isDev && { stack: err.stack })
  });
}

/**
 * 异步路由包装器
 * 自动捕获异步函数中的错误
 */
function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = {
  errorHandler,
  asyncHandler
};
