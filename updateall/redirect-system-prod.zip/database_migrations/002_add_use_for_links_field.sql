-- 添加"用于生成链接"字段
-- 执行时间：部署时手动执行

ALTER TABLE redirect_domains 
ADD COLUMN use_for_links BOOLEAN DEFAULT TRUE COMMENT '是否用于生成链接' 
AFTER is_active;

-- 添加索引
ALTER TABLE redirect_domains 
ADD INDEX idx_use_for_links (use_for_links);

-- 说明：
-- use_for_links = TRUE: 该域名会出现在"批量生成链接"的域名列表中
-- use_for_links = FALSE: 该域名不会用于生成链接（但仍然可以正常访问）
