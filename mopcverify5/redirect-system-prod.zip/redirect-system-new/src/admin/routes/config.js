/**
 * ============================================
 * 配置管理API路由
 * ============================================
 */

const express = require('express');
const router = express.Router();
const Database = require('../../database/mysql');
const Redis = require('../../database/redis');
const logger = require('../../utils/logger');
const { asyncHandler } = require('../middleware/errorHandler');
const fs = require('fs').promises;
const path = require('path');

/**
 * GET /api/config/all
 * 获取所有配置
 */
router.get('/all', asyncHandler(async (req, res) => {
  const { showSensitive } = req.query;
  
  const configs = await Database.query(
    'SELECT id, category, key_name, value, data_type, description, is_sensitive, updated_at FROM config_items WHERE is_active = 1 ORDER BY category, key_name'
  );

  // 按分类组织配置
  const grouped = configs.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    
    // 如果不要求显示敏感信息，则脱敏
    if (showSensitive !== 'true' && item.is_sensitive && item.value) {
      item.value = '••••••••';
    }
    
    acc[item.category].push(item);
    return acc;
  }, {});

  res.json({
    success: true,
    data: grouped
  });
}));

/**
 * GET /api/config/:category
 * 获取某个分类的配置
 */
router.get('/:category', asyncHandler(async (req, res) => {
  const { category } = req.params;
  const { showSensitive } = req.query;

  const configs = await Database.query(
    'SELECT * FROM config_items WHERE category = ? AND is_active = 1 ORDER BY key_name',
    [category]
  );

  // 如果不要求显示敏感信息，则脱敏
  if (showSensitive !== 'true') {
    configs.forEach(item => {
      if (item.is_sensitive && item.value) {
        item.value = '••••••••';
      }
    });
  }

  res.json({
    success: true,
    data: configs
  });
}));

/**
 * PUT /api/config/:category/:key
 * 更新单个配置项
 */
router.put('/:category/:key', asyncHandler(async (req, res) => {
  const { category, key } = req.params;
  const { value } = req.body;
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  if (value === undefined) {
    return res.status(400).json({
      success: false,
      message: '配置值不能为空'
    });
  }

  // 查询当前配置
  const config = await Database.queryOne(
    'SELECT * FROM config_items WHERE category = ? AND key_name = ?',
    [category, key]
  );

  if (!config) {
    // 配置项不存在，自动创建（支持新增配置项如IPREGISTRY_API_KEYS）
    try {
      await Database.insert('config_items', {
        category,
        key_name: key,
        value: String(value),
        data_type: 'string',
        description: '',
        is_sensitive: false,
        is_active: true,
        updated_by: username
      });

      // 记录操作日志
      await Database.insert('admin_logs', {
        username,
        action: 'config_create',
        resource: `${category}.${key}`,
        details: `新建配置: ${key}`,
        ip_address: ip,
        status: 'success'
      });

      logger.info('配置已新建', { category, key, username });

      return res.json({
        success: true,
        message: '配置创建成功'
      });
    } catch (insertError) {
      logger.error('新建配置失败', { error: insertError.message });
      return res.status(500).json({
        success: false,
        message: '新建配置失败: ' + insertError.message
      });
    }
  }

  const oldValue = config.value;

  // 更新配置
  await Database.update('config_items', {
    value: String(value),
    updated_by: username,
    updated_at: new Date()
  }, { id: config.id });

  // 尝试记录历史（如果表结构不匹配则跳过）
  try {
    await Database.insert('config_history', {
      config_id: config.id,
      category,
      key_name: key,
      old_value: oldValue,
      new_value: String(value),
      changed_by: username
    });
  } catch (historyError) {
    logger.warn('记录配置历史失败（已跳过）', { error: historyError.message });
  }

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_update',
    resource: `${category}.${key}`,
    details: `修改配置: ${key}`,
    ip_address: ip,
    status: 'success'
  });

  logger.info('配置已更新', { category, key, username });

  res.json({
    success: true,
    message: '配置更新成功'
  });
}));

/**
 * POST /api/config/batch
 * 批量更新配置
 */
router.post('/batch', asyncHandler(async (req, res) => {
  const { configs } = req.body;
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  if (!Array.isArray(configs) || configs.length === 0) {
    return res.status(400).json({
      success: false,
      message: '配置列表不能为空'
    });
  }

  let updatedCount = 0;

  for (const item of configs) {
    const { category, key, value } = item;

    // 查询配置
    const config = await Database.queryOne(
      'SELECT * FROM config_items WHERE category = ? AND key_name = ?',
      [category, key]
    );

    if (config) {
      const oldValue = config.value;

      // 更新配置
      await Database.update('config_items', {
        value: String(value),
        updated_by: username,
        updated_at: new Date()
      }, { id: config.id });

      // 尝试记录历史（如果表结构不匹配则跳过）
      try {
        await Database.insert('config_history', {
          config_id: config.id,
          category,
          key_name: key,
          old_value: oldValue,
          new_value: String(value),
          changed_by: username
        });
      } catch (historyError) {
        logger.warn('记录配置历史失败（已跳过）', { error: historyError.message });
      }

      updatedCount++;
    }
  }

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_batch_update',
    details: `批量更新${updatedCount}个配置项`,
    ip_address: ip,
    status: 'success'
  });

  logger.info('批量配置已更新', { count: updatedCount, username });

  res.json({
    success: true,
    message: `成功更新${updatedCount}个配置项`
  });
}));

/**
 * POST /api/config/test-database
 * 测试数据库连接
 */
router.post('/test-database', asyncHandler(async (req, res) => {
  const { host, port, database, user, password } = req.body;

  try {
    const mysql = require('mysql2/promise');
    
    const connection = await mysql.createConnection({
      host,
      port: parseInt(port),
      database,
      user,
      password,
      connectTimeout: 5000
    });

    const [rows] = await connection.query('SELECT VERSION() as version');
    const version = rows[0].version;

    await connection.end();

    res.json({
      success: true,
      message: '数据库连接成功',
      data: {
        version,
        status: 'connected'
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: '数据库连接失败',
      error: error.message
    });
  }
}));

/**
 * POST /api/config/test-redis
 * 测试Redis连接
 */
router.post('/test-redis', asyncHandler(async (req, res) => {
  const { host, port, password, db } = req.body;

  try {
    const redis = require('redis');
    
    const clientConfig = {
      socket: {
        host: host || '127.0.0.1',
        port: parseInt(port) || 6379,
        connectTimeout: 5000
      }
    };

    if (password) {
      clientConfig.password = password;
    }

    if (db !== undefined) {
      clientConfig.database = parseInt(db);
    }

    const testClient = redis.createClient(clientConfig);

    await testClient.connect();

    const info = await testClient.info('server');
    const version = info.match(/redis_version:([^\r\n]+)/)?.[1] || 'unknown';

    await testClient.quit();

    res.json({
      success: true,
      message: 'Redis连接成功',
      data: {
        version,
        status: 'connected'
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Redis连接失败',
      error: error.message
    });
  }
}));

/**
 * POST /api/config/reload
 * 热重载配置（重启主服务）
 */
router.post('/reload', asyncHandler(async (req, res) => {
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_reload',
    details: '触发配置热重载',
    ip_address: ip,
    status: 'success'
  });

  logger.info('配置热重载请求', { username });

  // 发送重载信号（这里简单返回，实际需要PM2或其他工具配合）
  res.json({
    success: true,
    message: '配置重载请求已发送，系统将在几秒内生效',
    note: '如使用PM2，请执行: pm2 restart redirect-system'
  });

  // 可以在这里触发主服务重载
  // 例如: 向主进程发送信号，或通过Redis发布消息
}));

/**
 * GET /api/config/history
 * 获取配置修改历史
 */
router.get('/history/:category?/:key?', asyncHandler(async (req, res) => {
  const { category, key } = req.params;
  const { limit = 50, offset = 0 } = req.query;

  let sql = `
    SELECT ch.*, ci.description
    FROM config_history ch
    LEFT JOIN config_items ci ON ch.config_id = ci.id
    WHERE 1=1
  `;
  const params = [];

  if (category) {
    sql += ' AND ch.category = ?';
    params.push(category);
  }

  if (key) {
    sql += ' AND ch.key_name = ?';
    params.push(key);
  }

  sql += ' ORDER BY ch.changed_at DESC LIMIT ? OFFSET ?';
  params.push(parseInt(limit), parseInt(offset));

  const history = await Database.query(sql, params);

  res.json({
    success: true,
    data: history
  });
}));

/**
 * POST /api/config/export
 * 导出配置
 */
router.post('/export', asyncHandler(async (req, res) => {
  const { username } = req.user;

  const configs = await Database.query(
    'SELECT category, key_name, value, data_type, description FROM config_items WHERE is_active = 1'
  );

  const exportData = {
    exportedAt: new Date().toISOString(),
    exportedBy: username,
    version: '1.0',
    configs
  };

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_export',
    details: `导出${configs.length}个配置项`,
    ip_address: req.ip,
    status: 'success'
  });

  res.json({
    success: true,
    data: exportData
  });
}));

/**
 * POST /api/config/import
 * 导入配置
 */
router.post('/import', asyncHandler(async (req, res) => {
  const { configs } = req.body;
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  if (!Array.isArray(configs)) {
    return res.status(400).json({
      success: false,
      message: '配置格式错误'
    });
  }

  let importedCount = 0;

  for (const item of configs) {
    const { category, key_name, value } = item;

    const existing = await Database.queryOne(
      'SELECT id FROM config_items WHERE category = ? AND key_name = ?',
      [category, key_name]
    );

    if (existing) {
      await Database.update('config_items', {
        value,
        updated_by: username,
        updated_at: new Date()
      }, { id: existing.id });
      importedCount++;
    }
  }

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_import',
    details: `导入${importedCount}个配置项`,
    ip_address: ip,
    status: 'success'
  });

  res.json({
    success: true,
    message: `成功导入${importedCount}个配置项`
  });
}));

// ============================================
// IPRegistry 多Key管理API
// ============================================

/**
 * GET /api/config/ipregistry-keys-status
 * 获取所有Key的状态（可用/禁用/原因）
 */
router.get('/ipregistry-keys-status', asyncHandler(async (req, res) => {
  const IPRegistryService = require('../../services/ipRegistry');
  const keysStatus = await IPRegistryService.getAllKeysStatus();

  const totalKeys = keysStatus.length;
  const disabledKeys = keysStatus.filter(k => k.disabled).length;
  const availableKeys = totalKeys - disabledKeys;

  res.json({
    success: true,
    data: {
      keys: keysStatus,
      total: totalKeys,
      available: availableKeys,
      disabled: disabledKeys,
      estimatedDailyQuota: availableKeys * 10000
    }
  });
}));

/**
 * POST /api/config/ipregistry-check-quotas
 * 批量查询所有Key的剩余额度
 */
router.post('/ipregistry-check-quotas', asyncHandler(async (req, res) => {
  const IPRegistryService = require('../../services/ipRegistry');
  const keysStatus = await IPRegistryService.getAllKeysStatus();
  const results = [];

  for (const keyInfo of keysStatus) {
    if (keyInfo.disabled) {
      results.push({
        key: keyInfo.key,
        keyPrefix: keyInfo.keyPrefix,
        disabled: true,
        disableReason: keyInfo.disableReason,
        disabledAt: keyInfo.disabledAt,
        remaining: null,
        consumed: null
      });
      continue;
    }

    try {
      const response = await require('axios').get(
        'https://api.ipregistry.co/?key=' + keyInfo.key,
        { timeout: 10000 }
      );
      const headers = response.headers;
      const remaining = headers['ipregistry-credits-remaining']
        ? parseInt(headers['ipregistry-credits-remaining'])
        : null;
      const consumed = headers['ipregistry-credits-consumed']
        ? parseInt(headers['ipregistry-credits-consumed'])
        : null;

      results.push({
        key: keyInfo.key,
        keyPrefix: keyInfo.keyPrefix,
        disabled: false,
        remaining: remaining,
        consumed: consumed,
        total: remaining !== null && consumed !== null ? remaining + consumed : null,
        status: remaining !== null ? (remaining > 1000 ? 'ok' : remaining > 100 ? 'low' : 'critical') : 'unknown'
      });
    } catch (error) {
      const msg = error.response?.data?.message || error.message || '查询失败';
      results.push({
        key: keyInfo.key,
        keyPrefix: keyInfo.keyPrefix,
        disabled: false,
        remaining: null,
        consumed: null,
        status: 'error',
        error: msg
      });
    }
  }

  const totalRemaining = results.reduce((sum, r) => sum + (r.remaining || 0), 0);

  res.json({
    success: true,
    data: {
      keys: results,
      totalRemaining: totalRemaining,
      checkedAt: new Date().toISOString()
    }
  });
}));

/**
 * POST /api/config/ipregistry-restore-key
 * 恢复指定被禁用的Key
 */
router.post('/ipregistry-restore-key', asyncHandler(async (req, res) => {
  const { key } = req.body;
  if (!key) {
    return res.status(400).json({ success: false, message: '请提供要恢复的Key' });
  }

  const IPRegistryService = require('../../services/ipRegistry');
  const restored = await IPRegistryService.restoreKey(key);

  if (restored) {
    // 记录操作日志
    await Database.insert('admin_logs', {
      username: req.user?.username || 'admin',
      action: 'ipregistry_restore_key',
      details: '恢复IPRegistry Key: ' + key.substring(0, 15) + '...',
      ip_address: req.ip,
      status: 'success'
    });
    res.json({ success: true, message: 'Key已恢复' });
  } else {
    res.json({ success: false, message: '该Key未被禁用' });
  }
}));

/**
 * POST /api/config/ipregistry-restore-all
 * 恢复所有被禁用的Key
 */
router.post('/ipregistry-restore-all', asyncHandler(async (req, res) => {
  const IPRegistryService = require('../../services/ipRegistry');
  await IPRegistryService.restoreAllKeys();

  await Database.insert('admin_logs', {
    username: req.user?.username || 'admin',
    action: 'ipregistry_restore_all',
    details: '恢复所有IPRegistry Key',
    ip_address: req.ip,
    status: 'success'
  });

  res.json({ success: true, message: '所有Key已恢复' });
}));

module.exports = router;
