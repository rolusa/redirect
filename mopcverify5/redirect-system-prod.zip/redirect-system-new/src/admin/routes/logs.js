/**
 * ============================================
 * 日志查询API路由
 * ============================================
 */

const express = require('express');
const router = express.Router();
const Database = require('../../database/mysql');
const { asyncHandler } = require('../middleware/errorHandler');

/**
 * GET /api/logs/access
 * 查询访问日志
 */
router.get('/access', asyncHandler(async (req, res) => {
  const {
    page = 1,
    pageSize = 20,
    ip,
    country,
    decision,
    dateFrom,
    dateTo,
    token
  } = req.query;

  let sql = 'SELECT * FROM access_logs WHERE 1=1';
  const params = [];

  // 构建查询条件
  if (ip) {
    sql += ' AND ip LIKE ?';
    params.push(`%${ip}%`);
  }

  if (country) {
    sql += ' AND country_code = ?';
    params.push(country);
  }

  if (decision) {
    sql += ' AND filter_decision = ?';
    params.push(decision);
  }

  if (dateFrom) {
    sql += ' AND created_at >= ?';
    params.push(dateFrom);
  }

  if (dateTo) {
    sql += ' AND created_at <= ?';
    params.push(dateTo);
  }

  if (token) {
    sql += ' AND token_hash = ?';
    params.push(token);
  }

  // 计算总数
  const countSql = sql.replace('SELECT *', 'SELECT COUNT(*) as total');
  const [countResult] = await Database.query(countSql, params);
  const total = countResult.total;

  // 分页查询
  sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  const offset = (parseInt(page) - 1) * parseInt(pageSize);
  params.push(parseInt(pageSize), offset);

  const logs = await Database.query(sql, params);

  res.json({
    success: true,
    data: {
      logs,
      pagination: {
        page: parseInt(page),
        pageSize: parseInt(pageSize),
        total,
        totalPages: Math.ceil(total / parseInt(pageSize))
      }
    }
  });
}));

/**
 * GET /api/logs/admin
 * 查询管理员操作日志
 */
router.get('/admin', asyncHandler(async (req, res) => {
  const {
    page = 1,
    pageSize = 20,
    username,
    action,
    dateFrom,
    dateTo
  } = req.query;

  let sql = 'SELECT * FROM admin_logs WHERE 1=1';
  const params = [];

  if (username) {
    sql += ' AND username = ?';
    params.push(username);
  }

  if (action) {
    sql += ' AND action = ?';
    params.push(action);
  }

  if (dateFrom) {
    sql += ' AND created_at >= ?';
    params.push(dateFrom);
  }

  if (dateTo) {
    sql += ' AND created_at <= ?';
    params.push(dateTo);
  }

  // 计算总数
  const countSql = sql.replace('SELECT *', 'SELECT COUNT(*) as total');
  const [countResult] = await Database.query(countSql, params);
  const total = countResult.total;

  // 分页查询
  sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  const offset = (parseInt(page) - 1) * parseInt(pageSize);
  params.push(parseInt(pageSize), offset);

  const logs = await Database.query(sql, params);

  res.json({
    success: true,
    data: {
      logs,
      pagination: {
        page: parseInt(page),
        pageSize: parseInt(pageSize),
        total,
        totalPages: Math.ceil(total / parseInt(pageSize))
      }
    }
  });
}));

/**
 * GET /api/logs/detail/:id
 * 获取日志详情
 */
router.get('/detail/:id', asyncHandler(async (req, res) => {
  const { id } = req.params;

  const log = await Database.queryOne(
    'SELECT * FROM access_logs WHERE id = ?',
    [id]
  );

  if (!log) {
    return res.status(404).json({
      success: false,
      message: '日志不存在'
    });
  }

  // 解析JSON字段
  if (log.filter_results) {
    try {
      log.filter_results = JSON.parse(log.filter_results);
    } catch (e) {
      // 保持原样
    }
  }

  res.json({
    success: true,
    data: log
  });
}));

/**
 * GET /api/logs/stats
 * 获取日志统计信息（各表记录数）
 */
router.get('/stats', asyncHandler(async (req, res) => {
  const tables = [
    { name: 'access_logs', label: '访问日志' },
    { name: 'admin_logs', label: '管理员日志' },
    { name: 'url_safety_logs', label: 'URL安全监控日志' },
    { name: 'config_history', label: '配置修改历史' }
  ];

  const stats = [];
  for (const table of tables) {
    try {
      const result = await Database.queryOne(
        'SELECT COUNT(*) as count FROM ' + table.name
      );
      stats.push({
        table: table.name,
        label: table.label,
        count: result?.count || 0
      });
    } catch (e) {
      stats.push({ table: table.name, label: table.label, count: 0, error: e.message });
    }
  }

  const totalCount = stats.reduce((sum, s) => sum + s.count, 0);

  res.json({
    success: true,
    data: { stats, totalCount }
  });
}));

/**
 * POST /api/logs/cleanup
 * 按天数清理日志（保留最近N天）
 */
router.post('/cleanup', asyncHandler(async (req, res) => {
  const { days } = req.body;
  const keepDays = parseInt(days);

  if (!keepDays || keepDays < 1) {
    return res.status(400).json({ success: false, message: '请输入有效的天数（至少1天）' });
  }

  const results = [];
  const tables = ['access_logs', 'admin_logs', 'url_safety_logs', 'config_history'];

  for (const table of tables) {
    try {
      const countBefore = await Database.queryOne('SELECT COUNT(*) as cnt FROM ' + table);
      const before = countBefore?.cnt || 0;

      await Database.query(
        'DELETE FROM ' + table + ' WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)',
        [keepDays]
      );

      const countAfter = await Database.queryOne('SELECT COUNT(*) as cnt FROM ' + table);
      const after = countAfter?.cnt || 0;
      const deleted = before - after;

      results.push({ table, before, after, deleted });
    } catch (e) {
      results.push({ table, error: e.message, deleted: 0 });
    }
  }

  const totalDeleted = results.reduce((sum, r) => sum + (r.deleted || 0), 0);

  // 记录操作日志
  try {
    await Database.insert('admin_logs', {
      username: req.user?.username || 'admin',
      action: 'logs_cleanup',
      details: '清理' + keepDays + '天前的日志，共删除' + totalDeleted + '条',
      ip_address: req.ip,
      status: 'success'
    });
  } catch (e) { /* ignore */ }

  res.json({
    success: true,
    message: '清理完成，共删除 ' + totalDeleted.toLocaleString() + ' 条记录',
    data: { keepDays, totalDeleted, results }
  });
}));

/**
 * POST /api/logs/cleanup-all
 * 清空全部日志
 */
router.post('/cleanup-all', asyncHandler(async (req, res) => {
  const results = [];
  const tables = ['access_logs', 'url_safety_logs', 'config_history'];

  for (const table of tables) {
    try {
      const countBefore = await Database.queryOne('SELECT COUNT(*) as cnt FROM ' + table);
      const before = countBefore?.cnt || 0;

      await Database.query('TRUNCATE TABLE ' + table);

      results.push({ table, deleted: before });
    } catch (e) {
      results.push({ table, error: e.message, deleted: 0 });
    }
  }

  // admin_logs 不用TRUNCATE，用DELETE保留最近的操作记录
  try {
    const countBefore = await Database.queryOne('SELECT COUNT(*) as cnt FROM admin_logs');
    const before = countBefore?.cnt || 0;

    // 保留最近10条管理员日志（包括这次清理操作本身）
    await Database.query(
      'DELETE FROM admin_logs WHERE id NOT IN (SELECT id FROM (SELECT id FROM admin_logs ORDER BY created_at DESC LIMIT 10) as tmp)'
    );

    const countAfter = await Database.queryOne('SELECT COUNT(*) as cnt FROM admin_logs');
    const after = countAfter?.cnt || 0;

    results.push({ table: 'admin_logs', deleted: before - after, kept: after });
  } catch (e) {
    results.push({ table: 'admin_logs', error: e.message, deleted: 0 });
  }

  const totalDeleted = results.reduce((sum, r) => sum + (r.deleted || 0), 0);

  // 记录操作日志
  try {
    await Database.insert('admin_logs', {
      username: req.user?.username || 'admin',
      action: 'logs_cleanup_all',
      details: '清空全部日志，共删除' + totalDeleted + '条',
      ip_address: req.ip,
      status: 'success'
    });
  } catch (e) { /* ignore */ }

  res.json({
    success: true,
    message: '清空完成，共删除 ' + totalDeleted.toLocaleString() + ' 条记录',
    data: { totalDeleted, results }
  });
}));

module.exports = router;
