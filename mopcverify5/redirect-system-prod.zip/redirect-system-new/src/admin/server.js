/**
 * ============================================
 * 管理后台服务器
 * ============================================
 * 端口: 3001
 * 功能: 提供Web管理界面和配置API
 * ============================================
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const { config } = require('../config');
const logger = require('../utils/logger');

const authRoutes = require('./routes/auth');
const configRoutes = require('./routes/config');
const statsRoutes = require('./routes/stats');
const logsRoutes = require('./routes/logs');
const systemRoutes = require('./routes/system');
const tokensRoutes = require('./routes/tokens');
const domainsRoutes = require('./routes/domains');
const safeBrowsingRoutes = require('./routes/safeBrowsing'); // ← URL安全监控路由

const { authMiddleware } = require('./middleware/auth');
const { errorHandler } = require('./middleware/errorHandler');

// 创建Express应用
const app = express();

// 中间件配置
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 静态文件服务（前端页面）
app.use(express.static(path.join(__dirname, 'public')));

// API路由
app.use('/api/auth', authRoutes);
app.use('/api/config', authMiddleware, configRoutes);
app.use('/api/stats', authMiddleware, statsRoutes);
app.use('/api/logs', authMiddleware, logsRoutes);
app.use('/api/system', authMiddleware, systemRoutes);
app.use('/api/tokens', authMiddleware, tokensRoutes);
app.use('/api/domains', authMiddleware, domainsRoutes);
app.use('/api/safety-monitor', authMiddleware, safeBrowsingRoutes); // ← URL安全监控

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'admin',
    timestamp: new Date().toISOString()
  });
});

// 所有其他请求返回index.html（SPA路由）
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 错误处理
app.use(errorHandler);

/**
 * 启动管理后台服务器
 */
async function startAdminServer() {
  const port = process.env.ADMIN_PORT || 3001;
  const host = '0.0.0.0';

  try {
    // 初始化数据库连接
    const Database = require('../database/mysql');
    const Redis = require('../database/redis'); // ← 添加Redis引用
    
    // ✅ 先初始化Redis（TokenGenerator等依赖Redis）
    await Redis.init();
    logger.info('管理后台Redis连接初始化成功');
    
    await Database.initialize();
    logger.info('管理后台数据库连接初始化成功');

    // 初始化URL安全监控服务
    try {
      const SafeBrowsingService = require('../services/safeBrowsingService');
      await SafeBrowsingService.init();
      logger.info('URL安全监控服务初始化完成');
    } catch (safetyError) {
      logger.warn('URL安全监控服务初始化失败（不影响主服务）', { error: safetyError.message });
    }

    const server = app.listen(port, host, () => {
      logger.info('='.repeat(60));
      logger.info('管理后台服务器启动成功');
      logger.info(`访问地址: http://127.0.0.1:${port}`);
      logger.info(`访问地址: http://localhost:${port}`);
      logger.info(`访问地址: http://0.0.0.0:${port}`);
      logger.info(`默认账号: admin / admin123`);
      logger.info('⚠️  请立即登录后修改默认密码！');
      logger.info('='.repeat(60));

      console.log('\n✅ 管理后台已启动！');
      console.log(`📍 访问地址: http://127.0.0.1:${port}`);
      console.log(`👤 默认账号: admin / admin123\n`);
    });

    // 优雅关闭
    process.on('SIGTERM', () => gracefulShutdown(server));
    process.on('SIGINT', () => gracefulShutdown(server));

    return server;
  } catch (error) {
    logger.error('管理后台启动失败', { error: error.message });
    process.exit(1);
  }
}

/**
 * 优雅关闭
 */
async function gracefulShutdown(server) {
  logger.info('收到关闭信号，开始优雅关闭管理后台...');
  
  // 停止安全监控定时器
  try {
    const SafeBrowsingService = require('../services/safeBrowsingService');
    SafeBrowsingService.stopTimer();
  } catch (e) { /* ignore */ }

  // 关闭Redis连接
  try {
    const Redis = require('../database/redis');
    await Redis.close();
  } catch (e) { /* ignore */ }

  server.close(() => {
    logger.info('管理后台服务器已关闭');
    process.exit(0);
  });

  setTimeout(() => {
    logger.error('强制关闭超时');
    process.exit(1);
  }, 10000);
}

// 如果直接运行此文件
if (require.main === module) {
  startAdminServer();
}

module.exports = { app, startAdminServer };
