/**
 * ============================================
 * Google Safe Browsing URL安全监控服务 v3
 * ============================================
 * 功能：
 * 1. 定时检查B输入框URL的安全性（Google Safe Browsing API）
 * 2. 定时检查B输入框URL的可访问性（DNS+HTTP 3层检查）
 * 3. 任一检查不通过即自动替换
 * 4. 替换前预检：新URL也要通过安全性+可访问性双重检查
 * 5. API Key轮换重试、永久禁用检测
 * 6. 可访问性检查：临时错误重试2次间隔2秒，明确错误不重试
 * ============================================
 */

const axios = require('axios');
const dns = require('dns');
const { URL } = require('url');
const Database = require('../database/mysql');
const logger = require('../utils/logger');

const CATEGORY = 'safety_monitor';
const API_URL = 'https://safebrowsing.googleapis.com/v4/threatMatches:find';

class SafeBrowsingService {
  static timer = null;
  static isChecking = false;
  static consecutiveFailures = 0;
  static MAX_CONSECUTIVE_FAILURES = 5;

  // ============================================
  // 配置读写
  // ============================================

  static async getConfig(key, defaultValue = '') {
    try {
      const row = await Database.queryOne(
        'SELECT value FROM config_items WHERE category = ? AND key_name = ? AND is_active = 1',
        [CATEGORY, key]
      );
      return row ? row.value : defaultValue;
    } catch (e) {
      logger.error('SafeBrowsing: 读取配置失败', { key, error: e.message });
      return defaultValue;
    }
  }

  static async setConfig(key, value, description = '', dataType = 'string') {
    try {
      const existing = await Database.queryOne(
        'SELECT id FROM config_items WHERE category = ? AND key_name = ?',
        [CATEGORY, key]
      );
      if (existing) {
        await Database.update('config_items',
          { value: String(value), updated_by: 'system', updated_at: new Date() },
          { id: existing.id }
        );
      } else {
        await Database.insert('config_items', {
          category: CATEGORY, key_name: key, value: String(value),
          data_type: dataType, description: description,
          is_sensitive: false, is_active: true, updated_by: 'system'
        });
      }
    } catch (e) {
      logger.error('SafeBrowsing: 写入配置失败', { key, error: e.message });
    }
  }

  static async getAllConfig() {
    const enabled = await this.getConfig('ENABLED', 'false');
    const checkInterval = parseInt(await this.getConfig('CHECK_INTERVAL_MINUTES', '5')) || 5;
    const activeUrlCount = parseInt(await this.getConfig('ACTIVE_URL_COUNT', '1')) || 1;
    const maxUrlAgeHours = parseInt(await this.getConfig('MAX_URL_AGE_HOURS', '0')) || 0;
    const poolUrls = (await this.getConfig('POOL_URLS', '')).split('\n').map(u => u.trim()).filter(u => u.startsWith('http'));
    const apiKeys = (await this.getConfig('API_KEYS', '')).split('\n').map(k => k.trim()).filter(k => k.length > 0);
    const lastCheckTime = await this.getConfig('LAST_CHECK_TIME', '');
    const lastCheckResult = await this.getConfig('LAST_CHECK_RESULT', '');
    const lastCheckError = await this.getConfig('LAST_CHECK_ERROR', '');
    const urlActivatedAt = this._parseJSON(await this.getConfig('URL_ACTIVATED_AT', '{}'), {});
    const retiredUrls = this._parseJSON(await this.getConfig('RETIRED_URLS', '[]'), []);
    const urlSafetySnapshot = this._parseJSON(await this.getConfig('URL_SAFETY_SNAPSHOT', '{}'), {});

    let activeUrls = [];
    try {
      const targetConfig = await Database.queryOne(
        'SELECT value FROM config_items WHERE key_name = ? AND category = ?',
        ['TARGET_URL', 'domains']
      );
      if (targetConfig && targetConfig.value) {
        activeUrls = targetConfig.value.split('\n').map(u => u.trim()).filter(u => u.startsWith('http'));
      }
    } catch (e) {
      logger.error('SafeBrowsing: 读取TARGET_URL失败', { error: e.message });
    }

    return {
      enabled: enabled === 'true', checkInterval, activeUrlCount, maxUrlAgeHours,
      poolUrls, activeUrls, apiKeys, lastCheckTime, lastCheckResult, lastCheckError,
      urlActivatedAt, retiredUrls, urlSafetySnapshot
    };
  }

  // ============================================
  // 定时器管理
  // ============================================

  static async init() {
    try {
      const config = await this.getAllConfig();
      if (config.enabled && config.apiKeys.length > 0) {
        this.startTimer(config.checkInterval);
        logger.info('SafeBrowsing: 安全监控已自动启动', { interval: config.checkInterval });
      } else {
        logger.info('SafeBrowsing: 安全监控未启用或缺少API Key');
      }
    } catch (e) {
      logger.error('SafeBrowsing: 初始化失败', { error: e.message });
    }
  }

  static startTimer(intervalMinutes) {
    this.stopTimer();
    const ms = Math.max(1, intervalMinutes) * 60 * 1000;
    this.timer = setInterval(() => this.checkNow(), ms);
    logger.info('SafeBrowsing: 定时器已启动', { intervalMinutes });
  }

  static stopTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      logger.info('SafeBrowsing: 定时器已停止');
    }
  }

  static async start() {
    const config = await this.getAllConfig();
    if (config.apiKeys.length === 0) {
      throw new Error('请先配置至少一个Google Safe Browsing API Key');
    }
    await this.setConfig('ENABLED', 'true');
    this.consecutiveFailures = 0;
    await this.setConfig('LAST_CHECK_RESULT', '');
    await this.setConfig('LAST_CHECK_ERROR', '');
    this.startTimer(config.checkInterval);
    return { success: true, message: '监控已启动' };
  }

  static async stop() {
    this.stopTimer();
    await this.setConfig('ENABLED', 'false');
    return { success: true, message: '监控已停止' };
  }

  // ============================================
  // URL可访问性检查（3层：DNS → HTTP HEAD → GET回退）
  // ============================================

  /**
   * 检查单个URL是否可访问
   * @param {string} url - 完整URL
   * @returns {Promise<{alive: boolean, reason: string|null}>}
   */
  static async checkURLAccessibility(url) {
    try {
      // 从URL提取域名
      const parsedUrl = new URL(url);
      const hostname = parsedUrl.hostname;

      // ═══ 第1层：DNS解析（带重试）═══
      const dnsResult = await this._dnsResolveWithRetry(hostname);
      if (!dnsResult.ok) {
        return { alive: false, reason: 'DNS解析失败(' + hostname + ')' };
      }

      // ═══ 第2层：HTTP HEAD请求（带重试）═══
      const headResult = await this._httpCheckWithRetry(url, 'HEAD');

      // HEAD成功
      if (headResult.alive) {
        return { alive: true, reason: null };
      }

      // HEAD返回405 → 进入第3层
      if (headResult.statusCode === 405) {
        // ═══ 第3层：GET回退（带重试）═══
        const getResult = await this._httpCheckWithRetry(url, 'GET');
        return getResult;
      }

      // HEAD明确失败
      return headResult;

    } catch (error) {
      return { alive: false, reason: '检查异常: ' + error.message };
    }
  }

  /**
   * DNS解析（带2次重试，间隔2秒）
   */
  static async _dnsResolveWithRetry(hostname) {
    const maxRetries = 2;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        await this._dnsResolve(hostname);
        return { ok: true };
      } catch (e) {
        if (attempt < maxRetries) {
          logger.debug('DNS解析失败，' + (2 - attempt) + '秒后重试', { hostname, attempt: attempt + 1 });
          await this._sleep(2000);
        } else {
          logger.warn('DNS解析最终失败', { hostname, error: e.message });
          return { ok: false, error: e.message };
        }
      }
    }
    return { ok: false, error: 'DNS解析失败' };
  }

  /**
   * DNS解析（单次）
   */
  static _dnsResolve(hostname) {
    return new Promise((resolve, reject) => {
      dns.resolve(hostname, (err, addresses) => {
        if (err) reject(err);
        else resolve(addresses);
      });
    });
  }

  /**
   * HTTP检查（带2次重试，间隔2秒）
   * 明确错误（404/SSL）不重试，临时错误（超时/5xx/连接拒绝）重试
   */
  static async _httpCheckWithRetry(url, method) {
    const maxRetries = 2;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      const result = await this._httpCheck(url, method);

      // 成功
      if (result.alive) return result;

      // 不可重试的错误：直接返回
      if (result.noRetry) return result;

      // 可重试的错误
      if (attempt < maxRetries) {
        logger.debug('HTTP检查失败，2秒后重试', { url, method, attempt: attempt + 1, reason: result.reason });
        await this._sleep(2000);
      } else {
        logger.warn('HTTP检查最终失败', { url, method, reason: result.reason });
        return result;
      }
    }
    return { alive: false, reason: '检查失败' };
  }

  /**
   * HTTP检查（单次）
   * @returns { alive, reason, statusCode, noRetry }
   */
  static async _httpCheck(url, method) {
    try {
      const config = {
        method: method,
        url: url,
        timeout: 5000,
        maxRedirects: 5,
        validateStatus: () => true, // 不抛出HTTP错误，返回所有状态码
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      };

      // GET回退时只下载前1KB
      if (method === 'GET') {
        config.maxContentLength = 1024;
        config.responseType = 'text';
      }

      const response = await axios(config);
      const status = response.status;

      // 2xx / 3xx / 403 → 活着
      if ((status >= 200 && status < 400) || status === 403) {
        return { alive: true, reason: null, statusCode: status };
      }

      // 404 → 死了（不重试）
      if (status === 404) {
        return { alive: false, reason: 'HTTP 404 页面不存在', statusCode: 404, noRetry: true };
      }

      // 405 → HEAD不支持（不重试，但标记让上层进第3层）
      if (status === 405 && method === 'HEAD') {
        return { alive: false, reason: 'HEAD不支持', statusCode: 405, noRetry: true };
      }

      // 5xx → 服务器错误（可重试）
      if (status >= 500) {
        return { alive: false, reason: 'HTTP ' + status + ' 服务器错误', statusCode: status, noRetry: false };
      }

      // 其他4xx（如401/410等）→ 活着（服务器在运行，只是拒绝访问）
      if (status >= 400 && status < 500) {
        return { alive: true, reason: null, statusCode: status };
      }

      return { alive: false, reason: 'HTTP ' + status, statusCode: status, noRetry: false };

    } catch (error) {
      // SSL证书错误 → 不重试
      if (error.code === 'CERT_HAS_EXPIRED' || error.code === 'ERR_TLS_CERT_ALTNAME_INVALID' ||
          error.code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE' || error.code === 'DEPTH_ZERO_SELF_SIGNED_CERT' ||
          error.code === 'ERR_SSL_PROTOCOL_ERROR' ||
          (error.message && error.message.includes('SSL') || error.message && error.message.includes('certificate'))) {
        return { alive: false, reason: 'SSL证书错误', noRetry: true };
      }

      // 连接超时 → 可重试
      if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') {
        return { alive: false, reason: '连接超时', noRetry: false };
      }

      // 连接被拒绝 → 可重试
      if (error.code === 'ECONNREFUSED') {
        return { alive: false, reason: '连接被拒绝', noRetry: false };
      }

      // 连接重置 → 可重试
      if (error.code === 'ECONNRESET' || error.code === 'EPIPE') {
        return { alive: false, reason: '连接被重置', noRetry: false };
      }

      // DNS解析失败（理论上第1层已过滤，但以防万一）→ 不重试
      if (error.code === 'ENOTFOUND' || error.code === 'EAI_AGAIN') {
        return { alive: false, reason: 'DNS解析失败', noRetry: true };
      }

      // 其他错误 → 可重试
      return { alive: false, reason: error.message || '未知错误', noRetry: false };
    }
  }

  // ============================================
  // 核心检查逻辑（v3：安全性 + 可访问性双重检查）
  // ============================================

  static async checkNow() {
    if (this.isChecking) {
      logger.warn('SafeBrowsing: 上一次检查尚未完成，跳过本次');
      return { skipped: true, reason: '上一次检查尚未完成' };
    }

    this.isChecking = true;
    const startTime = Date.now();

    try {
      await this.setConfig('LAST_CHECK_TIME', new Date().toISOString());
      const config = await this.getAllConfig();

      if (config.apiKeys.length === 0) {
        await this._saveCheckResult('error', '未配置API Key');
        return { success: false, error: '未配置API Key' };
      }

      if (config.activeUrls.length === 0) {
        await this._saveCheckResult('success', 'B输入框为空，无需检查');
        return { success: true, message: 'B输入框为空，无需检查' };
      }

      logger.info('SafeBrowsing: 开始双重检查（可访问性+安全性）', {
        activeUrls: config.activeUrls.length,
        poolUrls: config.poolUrls.length
      });

      // ═══ 步骤1：可访问性检查（不消耗API额度）═══
      const deadUrls = []; // { url, reason }
      const aliveUrls = [];
      const accessResults = {}; // url → { alive, reason }

      for (const url of config.activeUrls) {
        const result = await this.checkURLAccessibility(url);
        accessResults[url] = result;
        if (result.alive) {
          aliveUrls.push(url);
        } else {
          deadUrls.push({ url, reason: '无法访问(' + result.reason + ')' });
          logger.warn('SafeBrowsing: URL无法访问', { url: url.substring(0, 60), reason: result.reason });
        }
      }

      // ═══ 步骤2：对存活的URL做Safe Browsing安全检查（消耗API额度）═══
      let unsafeResults = [];
      if (aliveUrls.length > 0) {
        unsafeResults = await this.checkURLsSafetyWithRetry(aliveUrls, config.apiKeys);
      }

      // ═══ 步骤3：检查URL年龄 ═══
      let ageExpiredUrls = [];
      if (config.maxUrlAgeHours > 0) {
        ageExpiredUrls = this._getAgeExpiredUrls(config.activeUrls, config.urlActivatedAt, config.maxUrlAgeHours);
      }

      // ═══ 步骤4：存储快照（包含可访问性+安全性）═══
      const snapshot = {};
      for (const url of config.activeUrls) {
        const acc = accessResults[url] || { alive: null, reason: null };
        const unsafeItem = unsafeResults.find(r => r.url === url);
        snapshot[url] = {
          alive: acc.alive,
          aliveReason: acc.reason,
          safe: unsafeItem ? false : (acc.alive ? true : null),
          threatType: unsafeItem ? unsafeItem.threatType : null,
          checkedAt: new Date().toISOString()
        };
      }
      await this.setConfig('URL_SAFETY_SNAPSHOT', JSON.stringify(snapshot));

      // ═══ 步骤5：合并需要替换的URL（去重）═══
      const toReplaceMap = {}; // url → reason

      // 无法访问的URL
      for (const item of deadUrls) {
        toReplaceMap[item.url] = item.reason;
      }
      // 不安全的URL
      for (const item of unsafeResults) {
        if (!toReplaceMap[item.url]) {
          toReplaceMap[item.url] = '不安全(' + item.threatType + ')';
        } else {
          toReplaceMap[item.url] += ' + 不安全(' + item.threatType + ')';
        }
      }
      // 超龄URL
      for (const url of ageExpiredUrls) {
        if (!toReplaceMap[url]) {
          toReplaceMap[url] = 'URL使用时长超限';
        }
      }

      const toReplaceUrls = Object.keys(toReplaceMap);

      if (toReplaceUrls.length === 0) {
        this.consecutiveFailures = 0;
        const elapsed = Date.now() - startTime;
        await this._saveCheckResult('success',
          '所有URL正常（可访问+安全）(' + elapsed + 'ms)');
        logger.info('SafeBrowsing: 所有URL正常', { elapsed: elapsed + 'ms' });
        return { success: true, allSafe: true, checkedCount: config.activeUrls.length, elapsed };
      }

      // ═══ 步骤6：执行替换 ═══
      logger.warn('SafeBrowsing: 发现需要替换的URL', {
        dead: deadUrls.length,
        unsafe: unsafeResults.length,
        ageExpired: ageExpiredUrls.length,
        totalReplace: toReplaceUrls.length
      });

      const replaceResult = await this.replaceURLs(
        toReplaceUrls, toReplaceMap,
        config.activeUrls, config.poolUrls, config.apiKeys,
        config.urlActivatedAt, config.retiredUrls
      );

      this.consecutiveFailures = 0;
      const elapsed = Date.now() - startTime;
      await this._saveCheckResult('success',
        '替换了' + replaceResult.replacedCount + '个URL (无法访问:' + deadUrls.length +
        ' 不安全:' + unsafeResults.length + ') (' + elapsed + 'ms)');

      return {
        success: true, allSafe: false,
        checkedCount: config.activeUrls.length,
        replacedCount: replaceResult.replacedCount,
        deadCount: deadUrls.length,
        unsafeCount: unsafeResults.length,
        elapsed, details: replaceResult
      };

    } catch (error) {
      this.consecutiveFailures++;
      logger.error('SafeBrowsing: 检查失败', {
        error: error.message, consecutiveFailures: this.consecutiveFailures
      });
      await this._saveCheckResult('error', error.message);

      if (this.consecutiveFailures >= this.MAX_CONSECUTIVE_FAILURES) {
        logger.error('SafeBrowsing: 连续失败已达' + this.MAX_CONSECUTIVE_FAILURES + '次，暂停监控');
        this.stopTimer();
        await this.setConfig('ENABLED', 'false');
      }

      return { success: false, error: error.message };
    } finally {
      this.isChecking = false;
    }
  }

  static async _saveCheckResult(result, message) {
    try {
      await this.setConfig('LAST_CHECK_RESULT', result);
      await this.setConfig('LAST_CHECK_ERROR', result === 'error' ? message : '');
      await this.setConfig('LAST_CHECK_MESSAGE', message || '');
    } catch (e) {
      logger.error('SafeBrowsing: 保存检查结果失败', { error: e.message });
    }
  }

  // ============================================
  // Safe Browsing API 调用（带Key轮换重试）
  // ============================================

  static async checkURLsSafetyWithRetry(urls, apiKeys) {
    if (!urls || urls.length === 0) return [];
    if (!apiKeys || apiKeys.length === 0) throw new Error('未配置API Key');

    const shuffledKeys = [...apiKeys].sort(() => Math.random() - 0.5);
    const errors = [];

    for (let i = 0; i < shuffledKeys.length; i++) {
      const apiKey = shuffledKeys[i];
      try {
        const result = await this._callSafeBrowsingAPI(urls, apiKey);
        if (errors.length > 0) {
          logger.info('SafeBrowsing: 第' + (i + 1) + '个Key成功（前' + errors.length + '个Key失败）');
        }
        return result;
      } catch (e) {
        errors.push({ keyIndex: i + 1, keyPrefix: apiKey.substring(0, 15), error: e.message });
        logger.warn('SafeBrowsing: 第' + (i + 1) + '个Key失败，' +
          (i < shuffledKeys.length - 1 ? '尝试下一个...' : '全部Key已用完'), {
          keyPrefix: apiKey.substring(0, 15) + '...', error: e.message
        });
      }
    }

    const summary = errors.map(e => 'Key' + e.keyIndex + '(' + e.keyPrefix + '...): ' + e.error).join('; ');
    throw new Error('所有API Key均失败: ' + summary);
  }

  static async _callSafeBrowsingAPI(urls, apiKey) {
    try {
      const response = await axios.post(
        API_URL + '?key=' + apiKey,
        {
          client: { clientId: 'redirect-system-safety-monitor', clientVersion: '3.0.0' },
          threatInfo: {
            threatTypes: ['MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE', 'POTENTIALLY_HARMFUL_APPLICATION'],
            platformTypes: ['ANY_PLATFORM'],
            threatEntryTypes: ['URL'],
            threatEntries: urls.map(url => ({ url: url }))
          }
        },
        { timeout: 20000 }
      );
      const matches = response.data.matches || [];
      return matches.map(match => ({
        url: match.threat.url, threatType: match.threatType, platformType: match.platformType
      }));
    } catch (error) {
      if (error.response) {
        const status = error.response.status;
        const msg = error.response.data?.error?.message || '';
        if (status === 400 && msg.includes('API key not valid')) throw new Error('API Key无效');
        if (status === 429) throw new Error('配额耗尽(429)');
        if (status === 403) throw new Error('访问被拒绝(403)');
        throw new Error('HTTP ' + status + ': ' + (msg || 'Unknown'));
      }
      if (error.code === 'ECONNABORTED') throw new Error('请求超时(20s)');
      if (error.code === 'ENOTFOUND' || error.code === 'EAI_AGAIN') throw new Error('DNS解析失败');
      throw new Error(error.message);
    }
  }

  // ============================================
  // 替换逻辑（v3：预检增加可访问性检查）
  // ============================================

  static async replaceURLs(toReplaceUrls, toReplaceReasons, currentActiveUrls, currentPoolUrls, apiKeys, urlActivatedAt, retiredUrls) {
    let newActiveUrls = [...currentActiveUrls];
    let newPoolUrls = [...currentPoolUrls];
    let newActivatedAt = { ...urlActivatedAt };
    let newRetiredUrls = [...retiredUrls];
    let replacedCount = 0;
    const logEntries = [];

    for (const badUrl of toReplaceUrls) {
      const idx = newActiveUrls.indexOf(badUrl);
      if (idx === -1) continue;

      const reason = toReplaceReasons[badUrl] || '未知原因';

      // 从池中取一个通过双重预检的URL
      let replacementUrl = null;
      let preCheckAttempts = 0;
      const maxPreCheckAttempts = Math.min(newPoolUrls.length, 10);

      while (newPoolUrls.length > 0 && preCheckAttempts < maxPreCheckAttempts) {
        preCheckAttempts++;
        const candidate = newPoolUrls.shift();

        // 预检1：可访问性检查
        const accessResult = await this.checkURLAccessibility(candidate);
        if (!accessResult.alive) {
          logger.warn('SafeBrowsing: 备用URL预检无法访问，丢弃', {
            url: candidate.substring(0, 50), reason: accessResult.reason
          });
          newRetiredUrls.push({
            url: candidate,
            reason: '预检无法访问(' + accessResult.reason + ')',
            retiredAt: new Date().toISOString()
          });
          continue;
        }

        // 预检2：安全性检查
        try {
          const safetyResult = await this.checkURLsSafetyWithRetry([candidate], apiKeys);
          if (safetyResult.length === 0) {
            // 双重预检通过
            replacementUrl = candidate;
            break;
          } else {
            logger.warn('SafeBrowsing: 备用URL预检不安全，丢弃', {
              url: candidate.substring(0, 50), threat: safetyResult[0].threatType
            });
            newRetiredUrls.push({
              url: candidate,
              reason: '预检不安全(' + safetyResult[0].threatType + ')',
              retiredAt: new Date().toISOString()
            });
          }
        } catch (e) {
          // 安全检查API失败，放回池尾
          logger.warn('SafeBrowsing: 备用URL安全预检失败，放回池尾', {
            url: candidate.substring(0, 50), error: e.message
          });
          newPoolUrls.push(candidate);
          break;
        }
      }

      if (replacementUrl) {
        newActiveUrls[idx] = replacementUrl;
        newActivatedAt[replacementUrl] = new Date().toISOString();
        delete newActivatedAt[badUrl];
        replacedCount++;

        newRetiredUrls.push({
          url: badUrl, reason: reason, replacedBy: replacementUrl,
          retiredAt: new Date().toISOString()
        });
        logEntries.push({ oldUrl: badUrl, newUrl: replacementUrl, reason: reason });

        logger.warn('SafeBrowsing: URL已替换', {
          old: badUrl.substring(0, 50), new: replacementUrl.substring(0, 50), reason
        });
      } else {
        logger.error('SafeBrowsing: 备用URL池耗尽或预检全部失败', { badUrl: badUrl.substring(0, 50) });
        logEntries.push({ oldUrl: badUrl, newUrl: null, reason: reason + ' (无可用替换URL)' });
      }
    }

    // 保存
    if (replacedCount > 0) {
      const targetValue = newActiveUrls.join('\n');
      const targetConfig = await Database.queryOne(
        'SELECT id FROM config_items WHERE key_name = ? AND category = ?',
        ['TARGET_URL', 'domains']
      );
      if (targetConfig) {
        await Database.update('config_items',
          { value: targetValue, updated_by: 'safety_monitor', updated_at: new Date() },
          { id: targetConfig.id }
        );
      }
    }

    await this.setConfig('POOL_URLS', newPoolUrls.join('\n'));
    await this.setConfig('URL_ACTIVATED_AT', JSON.stringify(newActivatedAt));
    if (newRetiredUrls.length > 200) newRetiredUrls = newRetiredUrls.slice(-200);
    await this.setConfig('RETIRED_URLS', JSON.stringify(newRetiredUrls));

    for (const entry of logEntries) {
      try {
        await Database.insert('url_safety_logs', {
          action: 'replace', old_url: entry.oldUrl, new_url: entry.newUrl,
          reason: entry.reason, created_by: 'safety_monitor'
        });
      } catch (e) {
        logger.error('SafeBrowsing: 写入日志失败', { error: e.message });
      }
    }

    return { replacedCount, logEntries, remainingPool: newPoolUrls.length };
  }

  // ============================================
  // 获取监控状态
  // ============================================

  static async getStatus() {
    const config = await this.getAllConfig();

    let nextCheckTime = null;
    if (config.enabled && config.lastCheckTime) {
      const lastCheck = new Date(config.lastCheckTime);
      nextCheckTime = new Date(lastCheck.getTime() + config.checkInterval * 60 * 1000).toISOString();
    }

    let todayReplaces = 0;
    try {
      const r = await Database.queryOne(
        "SELECT COUNT(*) as cnt FROM url_safety_logs WHERE action = 'replace' AND DATE(created_at) = CURDATE()"
      );
      todayReplaces = r?.cnt || 0;
    } catch (e) { /* ignore */ }

    const urlStatuses = config.activeUrls.map(url => {
      const snap = config.urlSafetySnapshot[url];
      return {
        url,
        alive: snap ? snap.alive : null,
        aliveReason: snap ? snap.aliveReason : null,
        safe: snap ? snap.safe : null,
        threatType: snap ? snap.threatType : null,
        checkedAt: snap ? snap.checkedAt : null,
        activatedAt: config.urlActivatedAt[url] || null
      };
    });

    return {
      enabled: config.enabled, timerRunning: this.timer !== null,
      isChecking: this.isChecking, checkInterval: config.checkInterval,
      activeUrlCount: config.activeUrlCount, maxUrlAgeHours: config.maxUrlAgeHours,
      lastCheckTime: config.lastCheckTime || null, nextCheckTime,
      lastCheckResult: config.lastCheckResult || null,
      lastCheckError: config.lastCheckError || null,
      lastCheckMessage: await this.getConfig('LAST_CHECK_MESSAGE', ''),
      consecutiveFailures: this.consecutiveFailures,
      maxConsecutiveFailures: this.MAX_CONSECUTIVE_FAILURES,
      poolUrlsCount: config.poolUrls.length, activeUrls: config.activeUrls,
      poolUrls: config.poolUrls, apiKeysCount: config.apiKeys.length,
      apiKeys: config.apiKeys, urlStatuses, todayReplaces,
      retiredUrls: config.retiredUrls.slice(-50),
      poolWarning: config.poolUrls.length <= 5 && config.poolUrls.length > 0
        ? '备用URL池仅剩' + config.poolUrls.length + '个' : null,
      poolEmpty: config.poolUrls.length === 0
    };
  }

  // ============================================
  // 工具方法
  // ============================================

  static _sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  static _getRandomItem(arr) {
    if (!arr || arr.length === 0) return null;
    return arr[Math.floor(Math.random() * arr.length)];
  }

  static _parseJSON(str, defaultVal) {
    try { return JSON.parse(str); }
    catch { return defaultVal; }
  }

  static _getAgeExpiredUrls(activeUrls, activatedAt, maxHours) {
    const now = Date.now();
    const maxMs = maxHours * 60 * 60 * 1000;
    const expired = [];
    for (const url of activeUrls) {
      const t = activatedAt[url];
      if (t && (now - new Date(t).getTime()) > maxMs) expired.push(url);
    }
    return expired;
  }
}

module.exports = SafeBrowsingService;
