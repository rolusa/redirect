/**
 * ============================================
 * IP信息采集服务 v2 - 多Key轮换版
 * ============================================
 * 功能：
 * 1. 支持多个 IPRegistry API Key，随机轮换使用
 * 2. Key失败后自动重试下一个Key
 * 3. 额度不足/无效/被封的Key永久标记为不可用
 * 4. 网络超时等临时错误只跳过不标记
 * 5. 向后兼容旧的单Key配置
 * 6. 缓存IP信息减少API调用
 * ============================================
 */

const axios = require('axios');
const { config } = require('../config');
const logger = require('../utils/logger');
const Cache = require('../utils/cache');
const Database = require('../database/mysql');

class IPRegistryService {
  // Key列表内存缓存
  static _cachedKeys = null;
  static _cachedDisabledKeys = null;
  static _keyCacheTime = 0;
  static _keyCacheTTL = 60000; // 60秒缓存

  // ============================================
  // Key管理：读取、禁用、恢复
  // ============================================

  /**
   * 获取所有可用的API Keys（排除已禁用的）
   * 优先读 IPREGISTRY_API_KEYS（复数），回退读 IPREGISTRY_API_KEY（单数）
   * @returns {Promise<string[]>} 可用Key数组
   */
  static async _getAvailableKeys() {
    const now = Date.now();

    // 内存缓存有效，直接返回
    if (this._cachedKeys && (now - this._keyCacheTime) < this._keyCacheTTL) {
      return this._cachedKeys;
    }

    try {
      let allKeys = [];

      // 1. 优先读新字段（复数，多Key）
      const multiConfig = await Database.queryOne(
        'SELECT value FROM config_items WHERE key_name = ? AND category = ? AND is_active = 1',
        ['IPREGISTRY_API_KEYS', 'api']
      );

      if (multiConfig && multiConfig.value && multiConfig.value.trim()) {
        allKeys = multiConfig.value.split('\n').map(k => k.trim()).filter(k => k.length > 10);
      }

      // 2. 如果新字段为空，回退读旧字段（单数，单Key）
      if (allKeys.length === 0) {
        const singleConfig = await Database.queryOne(
          'SELECT value FROM config_items WHERE key_name = ? AND category = ? AND is_active = 1',
          ['IPREGISTRY_API_KEY', 'api']
        );
        if (singleConfig && singleConfig.value && singleConfig.value.trim()) {
          allKeys = [singleConfig.value.trim()];
        }
      }

      // 3. 如果数据库都没有，回退到.env
      if (allKeys.length === 0 && config.ipregistry.apiKey) {
        allKeys = [config.ipregistry.apiKey];
      }

      // 4. 读取禁用列表
      const disabledMap = await this._getDisabledKeysMap();

      // 5. 过滤掉已禁用的Key
      const availableKeys = allKeys.filter(key => !disabledMap[key]);

      // 缓存
      this._cachedKeys = availableKeys;
      this._keyCacheTime = now;

      logger.debug('IPRegistry: Key列表已加载', {
        total: allKeys.length,
        disabled: allKeys.length - availableKeys.length,
        available: availableKeys.length
      });

      return availableKeys;

    } catch (error) {
      logger.error('IPRegistry: 读取Key列表失败', { error: error.message });
      // 出错时尝试用.env中的Key
      if (config.ipregistry.apiKey) {
        return [config.ipregistry.apiKey];
      }
      return [];
    }
  }

  /**
   * 获取禁用Key的Map
   * @returns {Promise<Object>} { "ira_xxx": { reason, disabledAt } }
   */
  static async _getDisabledKeysMap() {
    try {
      const row = await Database.queryOne(
        'SELECT value FROM config_items WHERE key_name = ? AND category = ? AND is_active = 1',
        ['IPREGISTRY_DISABLED_KEYS', 'api']
      );
      if (row && row.value) {
        return JSON.parse(row.value);
      }
    } catch (e) { /* ignore */ }
    return {};
  }

  /**
   * 永久禁用一个Key
   * @param {string} apiKey - 要禁用的Key
   * @param {string} reason - 禁用原因
   */
  static async _disableKey(apiKey, reason) {
    try {
      const disabledMap = await this._getDisabledKeysMap();
      disabledMap[apiKey] = {
        reason: reason,
        disabledAt: new Date().toISOString()
      };
      await this._saveDisabledKeys(disabledMap);

      // 立即清除Key列表缓存
      this._clearKeyCache();

      logger.warn('IPRegistry: Key已永久禁用', {
        keyPrefix: apiKey.substring(0, 15) + '...',
        reason
      });
    } catch (e) {
      logger.error('IPRegistry: 禁用Key失败', { error: e.message });
    }
  }

  /**
   * 保存禁用Key列表到数据库
   */
  static async _saveDisabledKeys(disabledMap) {
    const value = JSON.stringify(disabledMap);
    const existing = await Database.queryOne(
      'SELECT id FROM config_items WHERE key_name = ? AND category = ?',
      ['IPREGISTRY_DISABLED_KEYS', 'api']
    );
    if (existing) {
      await Database.update('config_items',
        { value: value, updated_by: 'system', updated_at: new Date() },
        { id: existing.id }
      );
    } else {
      await Database.insert('config_items', {
        category: 'api',
        key_name: 'IPREGISTRY_DISABLED_KEYS',
        value: value,
        data_type: 'json',
        description: 'IPRegistry已禁用的API Key列表',
        is_sensitive: false,
        is_active: true,
        updated_by: 'system'
      });
    }
  }

  /**
   * 恢复一个被禁用的Key
   * @param {string} apiKey - 要恢复的Key
   */
  static async restoreKey(apiKey) {
    const disabledMap = await this._getDisabledKeysMap();
    if (disabledMap[apiKey]) {
      delete disabledMap[apiKey];
      await this._saveDisabledKeys(disabledMap);
      this._clearKeyCache();
      logger.info('IPRegistry: Key已恢复', { keyPrefix: apiKey.substring(0, 15) + '...' });
      return true;
    }
    return false;
  }

  /**
   * 恢复所有被禁用的Key
   */
  static async restoreAllKeys() {
    await this._saveDisabledKeys({});
    this._clearKeyCache();
    logger.info('IPRegistry: 所有Key已恢复');
    return true;
  }

  /**
   * 获取所有Key的状态（供前端展示）
   */
  static async getAllKeysStatus() {
    let allKeys = [];

    // 读取所有Key
    const multiConfig = await Database.queryOne(
      'SELECT value FROM config_items WHERE key_name = ? AND category = ? AND is_active = 1',
      ['IPREGISTRY_API_KEYS', 'api']
    );
    if (multiConfig && multiConfig.value && multiConfig.value.trim()) {
      allKeys = multiConfig.value.split('\n').map(k => k.trim()).filter(k => k.length > 10);
    }

    // 回退旧字段
    if (allKeys.length === 0) {
      const singleConfig = await Database.queryOne(
        'SELECT value FROM config_items WHERE key_name = ? AND category = ? AND is_active = 1',
        ['IPREGISTRY_API_KEY', 'api']
      );
      if (singleConfig && singleConfig.value && singleConfig.value.trim()) {
        allKeys = [singleConfig.value.trim()];
      }
    }

    const disabledMap = await this._getDisabledKeysMap();

    return allKeys.map(key => ({
      key: key,
      keyPrefix: key.substring(0, 15) + '...' + key.substring(key.length - 4),
      disabled: !!disabledMap[key],
      disableReason: disabledMap[key]?.reason || null,
      disabledAt: disabledMap[key]?.disabledAt || null
    }));
  }

  /**
   * 清除Key列表内存缓存
   */
  static _clearKeyCache() {
    this._cachedKeys = null;
    this._keyCacheTime = 0;
  }

  /** 兼容旧代码调用 */
  static clearApiKeyCache() {
    this._clearKeyCache();
    logger.info('API Key缓存已清除');
  }

  // ============================================
  // 核心：获取IP信息（带缓存）
  // ============================================

  static async getIPInfo(ip) {
    try {
      // 1. 检查Redis缓存
      const cacheKey = `ip_info:${ip}`;
      const cached = await Cache.get(cacheKey);
      if (cached) {
        logger.debug('IP信息命中缓存', { ip });
        return cached;
      }

      // 2. 获取可用Key列表
      const availableKeys = await this._getAvailableKeys();
      if (availableKeys.length === 0) {
        logger.error('IPRegistry: 没有可用的API Key');
        return this._getDefaultIPInfo(ip);
      }

      // 3. 带轮换重试调用API
      const ipInfo = await this._fetchWithKeyRotation(ip, availableKeys);

      if (!ipInfo) {
        logger.warn('无法获取IP信息，使用降级数据', { ip });
        return this._getDefaultIPInfo(ip);
      }

      // 4. 格式化
      const formatted = this._formatIPInfo(ipInfo);

      // 5. 缓存
      await Cache.set(cacheKey, formatted, config.cache.ipInfoTTL);

      logger.info('IP信息获取成功', {
        ip,
        country: formatted.country.code,
        city: formatted.location.city,
      });

      return formatted;

    } catch (error) {
      logger.error('获取IP信息失败', { ip, error: error.message });
      return this._getDefaultIPInfo(ip);
    }
  }

  /**
   * 带Key轮换重试的API调用
   * 随机选Key → 失败 → 换下一个 → 全部失败 → 返回null
   */
  static async _fetchWithKeyRotation(ip, availableKeys) {
    // 随机打乱Key顺序
    const shuffled = [...availableKeys].sort(() => Math.random() - 0.5);

    for (let i = 0; i < shuffled.length; i++) {
      const apiKey = shuffled[i];
      try {
        const result = await this._fetchFromAPI(ip, apiKey);
        if (result) {
          if (i > 0) {
            logger.info('IPRegistry: 第' + (i + 1) + '个Key成功（前' + i + '个失败）');
          }
          return result;
        }
      } catch (errorInfo) {
        // errorInfo = { permanent, reason, apiKey }
        if (errorInfo.permanent) {
          // 永久错误：禁用此Key
          await this._disableKey(apiKey, errorInfo.reason);
        }
        logger.warn('IPRegistry: Key' + (i + 1) + '失败' +
          (i < shuffled.length - 1 ? '，尝试下一个' : '，全部用完'), {
          keyPrefix: apiKey.substring(0, 15) + '...',
          reason: errorInfo.reason,
          permanent: errorInfo.permanent
        });
      }
    }

    // 全部失败
    logger.error('IPRegistry: 所有Key均失败', { keysTriedCount: shuffled.length });
    return null;
  }

  /**
   * 单次API调用（不重试）
   * 成功返回数据，失败throw { permanent, reason }
   */
  static async _fetchFromAPI(ip, apiKey) {
    try {
      const url = `${config.ipregistry.baseURL}/${ip}`;
      const response = await axios.get(url, {
        params: { key: apiKey },
        timeout: config.ipregistry.timeout,
        headers: { 'User-Agent': 'RedirectSystem/2.0' }
      });

      if (response.status === 200 && response.data) {
        // 检查API层面的错误（如额度不足，有时在200响应体内返回）
        if (response.data.code && response.data.message) {
          const code = response.data.code;
          const msg = response.data.message;
          if (code === 'INSUFFICIENT_CREDITS' || msg.includes('insufficient credits')) {
            throw { permanent: true, reason: '额度不足(' + code + ')' };
          }
          throw { permanent: false, reason: 'API错误: ' + code };
        }
        return response.data;
      }

      throw { permanent: false, reason: 'HTTP ' + response.status };

    } catch (error) {
      // 如果已经是我们的结构化错误，直接重新抛出
      if (error.permanent !== undefined) throw error;

      if (error.response) {
        const status = error.response.status;
        const data = error.response.data;
        const code = data?.code || '';
        const msg = data?.message || '';

        // 永久错误：禁用Key
        if (code === 'INSUFFICIENT_CREDITS' || msg.includes('insufficient credits')) {
          throw { permanent: true, reason: '额度不足' };
        }
        if (status === 401) {
          throw { permanent: true, reason: 'Key无效(401)' };
        }
        if (status === 403) {
          throw { permanent: true, reason: '账户被封(403)' };
        }

        // 临时错误：不禁用Key
        if (status === 429) {
          throw { permanent: false, reason: '频率限制(429)' };
        }
        throw { permanent: false, reason: 'HTTP ' + status + ': ' + (msg || code) };
      }

      if (error.code === 'ECONNABORTED') {
        throw { permanent: false, reason: '请求超时' };
      }
      if (error.code === 'ENOTFOUND' || error.code === 'EAI_AGAIN') {
        throw { permanent: false, reason: 'DNS解析失败' };
      }

      throw { permanent: false, reason: error.message };
    }
  }

  // ============================================
  // 格式化和降级
  // ============================================

  static _formatIPInfo(rawData) {
    return {
      ip: rawData.ip || '',
      location: {
        country: rawData.location?.country?.name || '',
        countryCode: rawData.location?.country?.code || '',
        region: rawData.location?.region?.name || '',
        city: rawData.location?.city || '',
        postalCode: rawData.location?.postal || '',
        latitude: rawData.location?.latitude || null,
        longitude: rawData.location?.longitude || null,
        timezone: rawData.time_zone?.id || '',
        continent: {
          code: rawData.location?.continent?.code || '',
          name: rawData.location?.continent?.name || '',
        },
      },
      country: {
        name: rawData.location?.country?.name || '',
        code: rawData.location?.country?.code || '',
        flag: rawData.location?.country?.flag?.emoji || '',
      },
      connection: {
        type: rawData.connection?.type || 'unknown',
        organization: rawData.connection?.organization || '',
        asn: rawData.connection?.asn || null,
        domain: rawData.connection?.domain || '',
      },
      security: {
        is_vpn: rawData.security?.is_vpn || false,
        is_proxy: rawData.security?.is_proxy || false,
        is_tor: rawData.security?.is_tor || false,
        is_tor_exit: rawData.security?.is_tor_exit || false,
        is_cloud_provider: rawData.security?.is_cloud_provider || false,
        is_anonymous: rawData.security?.is_anonymous || false,
        is_abuser: rawData.security?.is_abuser || false,
        is_attacker: rawData.security?.is_attacker || false,
        is_bogon: rawData.security?.is_bogon || false,
        is_relay: rawData.security?.is_relay || false,
        is_threat: rawData.security?.is_threat || false,
        is_hosting: rawData.security?.is_hosting || false,
      },
      currency: {
        code: rawData.currency?.code || '',
        name: rawData.currency?.name || '',
        symbol: rawData.currency?.symbol || '',
      },
      timeZone: {
        id: rawData.time_zone?.id || '',
        abbreviation: rawData.time_zone?.abbreviation || '',
        currentTime: rawData.time_zone?.current_time || '',
        offset: rawData.time_zone?.offset || 0,
      },
      _raw: config.debug.verbose ? rawData : null,
    };
  }

  static _getDefaultIPInfo(ip) {
    return {
      ip,
      location: {
        country: 'Unknown', countryCode: 'XX', region: '', city: '',
        postalCode: '', latitude: null, longitude: null, timezone: '',
        continent: { code: '', name: '' },
      },
      country: { name: 'Unknown', code: 'XX', flag: '' },
      connection: { type: 'unknown', organization: '', asn: null, domain: '' },
      security: {
        is_vpn: false, is_proxy: false, is_tor: false, is_tor_exit: false,
        is_cloud_provider: false, is_anonymous: false, is_abuser: false,
        is_attacker: false, is_bogon: false, is_relay: false,
        is_threat: false, is_hosting: false,
      },
      currency: { code: '', name: '', symbol: '' },
      timeZone: { id: '', abbreviation: '', currentTime: '', offset: 0 },
      _raw: null, _fallback: true,
    };
  }

  // ============================================
  // 辅助方法
  // ============================================

  static async getIPInfoBatch(ips) {
    const results = {};
    const chunkSize = 10;
    for (let i = 0; i < ips.length; i += chunkSize) {
      const chunk = ips.slice(i, i + chunkSize);
      const promises = chunk.map(ip => this.getIPInfo(ip));
      const chunkResults = await Promise.all(promises);
      chunk.forEach((ip, index) => { results[ip] = chunkResults[index]; });
    }
    return results;
  }

  static async clearCache(ip = null) {
    try {
      if (ip) {
        await Cache.del(`ip_info:${ip}`);
      } else {
        await Cache.delPattern('ip_info:*');
      }
      return true;
    } catch (error) {
      logger.error('清除IP缓存失败', { error: error.message });
      return false;
    }
  }

  static async getCacheStats() {
    try {
      const redis = Cache.getClient();
      const keys = await redis.keys(config.redis.keyPrefix + 'ip_info:*');
      return { totalCached: keys.length, keyPrefix: config.redis.keyPrefix + 'ip_info:' };
    } catch (error) {
      return { totalCached: 0, keyPrefix: '' };
    }
  }

  static async testAPIConnection() {
    try {
      const testIP = '8.8.8.8';
      const availableKeys = await this._getAvailableKeys();
      if (availableKeys.length === 0) {
        return { success: false, message: '没有可用的API Key' };
      }
      const startTime = Date.now();
      const result = await this._fetchWithKeyRotation(testIP, availableKeys);
      const duration = Date.now() - startTime;
      if (result) {
        return {
          success: true, duration,
          message: 'API连接正常',
          country: result.location?.country?.code,
        };
      }
      return { success: false, message: 'API返回空数据或全部Key失败' };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }
}

module.exports = IPRegistryService;
