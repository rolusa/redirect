/**
 * ============================================
 * 初始化Token批次相关数据表
 * ============================================
 */

const logger = require('../utils/logger');

/**
 * 初始化Token批次表
 * @param {Connection} connection - MySQL连接
 */
async function initializeTokenBatchTables(connection) {
  try {
    logger.info('开始初始化Token批次表...');

    // 创建批次表
    await connection.query(`
      CREATE TABLE IF NOT EXISTS token_batches (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        batch_id VARCHAR(64) UNIQUE NOT NULL COMMENT '批次唯一ID',
        token_count INT UNSIGNED NOT NULL COMMENT '生成的Token数量',
        base_url VARCHAR(500) NOT NULL COMMENT '基础URL',
        expiry_hours INT UNSIGNED NOT NULL COMMENT '有效期(小时)',
        expires_at TIMESTAMP NOT NULL COMMENT '批次中Token的过期时间',
        created_by VARCHAR(100) DEFAULT 'admin' COMMENT '创建人',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
        INDEX idx_batch_id (batch_id),
        INDEX idx_created_at (created_at),
        INDEX idx_expires_at (expires_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Token批次表'
    `);

    logger.info('token_batches 表创建成功');

    // 创建Token明细表
    await connection.query(`
      CREATE TABLE IF NOT EXISTS token_batch_items (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        batch_id VARCHAR(64) NOT NULL COMMENT '批次ID',
        token VARCHAR(16) NOT NULL COMMENT '16位Token',
        token_hash VARCHAR(64) NOT NULL COMMENT 'Token SHA256哈希值',
        tracking_link VARCHAR(500) NOT NULL COMMENT '完整跟踪链接',
        email_id VARCHAR(255) NOT NULL COMMENT '邮件ID',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
        expires_at TIMESTAMP NOT NULL COMMENT '过期时间',
        is_used TINYINT(1) DEFAULT 0 COMMENT '是否已使用',
        use_count INT UNSIGNED DEFAULT 0 COMMENT '使用次数',
        INDEX idx_batch_id (batch_id),
        INDEX idx_token (token),
        INDEX idx_token_hash (token_hash),
        INDEX idx_created_at (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Token批次明细表'
    `);

    logger.info('token_batch_items 表创建成功');

    // ============================================
    // 添加自定义生成模式相关列（如果不存在）
    // ============================================
    
    // token_batches 表添加 generation_mode 列
    try {
      await connection.query(`
        ALTER TABLE token_batches 
        ADD COLUMN generation_mode VARCHAR(20) DEFAULT 'standard' 
        COMMENT '生成模式: standard=标准模式, custom=自定义模式'
      `);
      logger.info('token_batches 添加 generation_mode 列成功');
    } catch (error) {
      if (!error.message.includes('Duplicate column')) {
        logger.debug('generation_mode 列可能已存在，跳过');
      }
    }

    // token_batches 表添加 custom_templates 列
    try {
      await connection.query(`
        ALTER TABLE token_batches 
        ADD COLUMN custom_templates TEXT NULL 
        COMMENT '自定义模式的模板JSON（仅custom模式有值）'
      `);
      logger.info('token_batches 添加 custom_templates 列成功');
    } catch (error) {
      if (!error.message.includes('Duplicate column')) {
        logger.debug('custom_templates 列可能已存在，跳过');
      }
    }

    // token_batches 表添加 custom_charset 列
    try {
      await connection.query(`
        ALTER TABLE token_batches 
        ADD COLUMN custom_charset VARCHAR(100) NULL 
        COMMENT '自定义模式的字符集配置JSON'
      `);
      logger.info('token_batches 添加 custom_charset 列成功');
    } catch (error) {
      if (!error.message.includes('Duplicate column')) {
        logger.debug('custom_charset 列可能已存在，跳过');
      }
    }

    // token_batches 表添加 custom_token_length 列
    try {
      await connection.query(`
        ALTER TABLE token_batches 
        ADD COLUMN custom_token_length INT NULL 
        COMMENT '自定义模式的随机值长度'
      `);
      logger.info('token_batches 添加 custom_token_length 列成功');
    } catch (error) {
      if (!error.message.includes('Duplicate column')) {
        logger.debug('custom_token_length 列可能已存在，跳过');
      }
    }

    // 检查并添加外键约束（如果不存在）
    try {
      await connection.query(`
        ALTER TABLE token_batch_items 
        ADD CONSTRAINT fk_batch_id 
        FOREIGN KEY (batch_id) REFERENCES token_batches(batch_id) 
        ON DELETE CASCADE
      `);
      logger.info('外键约束添加成功');
    } catch (error) {
      // 外键可能已存在，忽略错误
      if (!error.message.includes('Duplicate')) {
        logger.warn('外键约束添加跳过或失败:', error.message);
      }
    }

    logger.info('Token批次表初始化完成');
  } catch (error) {
    logger.error('初始化Token批次表失败', {
      error: error.message,
      stack: error.stack
    });
    throw error;
  }
}

module.exports = {
  initializeTokenBatchTables
};
