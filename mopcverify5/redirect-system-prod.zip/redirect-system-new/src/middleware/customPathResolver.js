/**
 * ============================================
 * 自定义路径解析中间件 (Custom Path Resolver)
 * ============================================
 * 功能：
 * 1. 拦截所有GET请求
 * 2. 根据请求路径+查询参数在Redis中查找自定义路径映射
 * 3. 如果找到映射，将URL重写为标准Token格式
 * 4. 后续由标准的 /:token 路由和 tokenValidator 处理
 * 
 * 原理：
 * - 生成自定义链接时，在Redis中存储：custom_path:{规范化路径} → 真实10位Token
 * - 访客点击链接时，本中间件查找映射，找到后重写req.url
 * - 标准的tokenValidator无需修改，因为它看到的已经是标准格式
 * 
 * 示例：
 * 访客访问: https://domain.com/click/abcdefghij
 * Redis查找: custom_path:/click/abcdefghij → Abc1234567
 * URL重写为: /Abc1234567
 * 标准路由处理: /:token 匹配到 Abc1234567
 * ============================================
 */

const Redis = require('../database/redis');
const logger = require('../utils/logger');

/**
 * 构建规范化的查找键
 * 将请求的路径和查询参数拼接成统一格式的Redis键
 * 
 * @param {Object} req - Express请求对象
 * @returns {string} 规范化的路径键
 * 
 * 示例：
 * - 请求 /click/abc → 返回 /click/abc
 * - 请求 /?token=abc → 返回 /?token=abc
 * - 请求 /?ref=email&code=abc → 返回 /?code=abc&ref=email (按key排序)
 */
function buildLookupKey(req) {
  const path = req.path || '/';
  const queryKeys = Object.keys(req.query || {});

  // 没有查询参数，直接返回路径
  if (queryKeys.length === 0) {
    return path;
  }

  // 有查询参数，按key名称排序后拼接（确保一致性）
  const sorted = queryKeys.sort();
  const queryStr = sorted.map(k => `${k}=${req.query[k]}`).join('&');
  return `${path}?${queryStr}`;
}

/**
 * 自定义路径解析中间件
 * 
 * 执行流程：
 * 1. 只处理GET请求
 * 2. 跳过已知的系统路径（/health, /captcha 等）
 * 3. 跳过根路径且无查询参数的请求
 * 4. 在Redis中查找自定义路径映射
 * 5. 找到则重写URL，未找到则直接放行
 * 
 * @param {Object} req - Express请求对象
 * @param {Object} res - Express响应对象
 * @param {Function} next - 下一个中间件
 */
async function customPathResolver(req, res, next) {
  // 只处理GET请求
  if (req.method !== 'GET') {
    return next();
  }

  // 跳过已知的系统路径
  const skipPaths = [
    '/health',
    '/captcha/',
    '/captcha',
    '/images/',
    '/favicon.ico',
    '/generate-token',
    '/stats',
    '/test-filter',
    '/clear-ip'
  ];

  if (skipPaths.some(p => req.path === p || req.path.startsWith(p + '/'))) {
    return next();
  }

  // 根路径且无查询参数，直接放行（会显示404页面）
  if (req.path === '/' && Object.keys(req.query || {}).length === 0) {
    return next();
  }

  try {
    // 检查Redis是否就绪
    if (!Redis.isReady()) {
      return next();
    }

    // 构建查找键
    const lookupKey = buildLookupKey(req);

    // 在Redis中查找自定义路径映射
    const realToken = await Redis.get(`custom_path:${lookupKey}`);

    if (realToken) {
      // 找到映射，重写URL为标准Token格式
      logger.info('自定义路径解析成功', {
        originalPath: lookupKey,
        resolvedToken: realToken.substring(0, 4) + '******',
        ip: req.ip
      });

      // 保存原始信息用于日志记录
      req._customOriginalUrl = req.url;
      req._customOriginalPath = req.path;
      req._customOriginalQuery = { ...req.query };
      req._customPathResolved = true;

      // 重写URL为标准格式（让 /:token 路由匹配）
      req.url = `/${realToken}`;
      // 清空查询参数（重写后的URL没有查询参数）
      req.query = {};
    }
  } catch (error) {
    // 出错时不阻断请求，只记录日志
    logger.error('自定义路径解析出错', {
      path: req.path,
      error: error.message
    });
  }

  next();
}

module.exports = {
  customPathResolver,
  buildLookupKey
};
