/**
 * ============================================
 * Token生成工具（短Token版本）
 * ============================================
 * 功能：
 * 1. 生成16位随机短Token
 * 2. 数据存储在Redis中
 * 3. Token只作为ID使用
 * 4. 支持过期时间控制
 * ============================================
 */

const crypto = require('crypto');
const { config } = require('../config');
const logger = require('./logger');
const Redis = require('../database/redis');

/**
 * Token生成器类
 */
class TokenGenerator {
  /**
   * 生成16位随机短Token
   * @returns {string} 16位Token
   * @private
   */
  static _generateShortToken() {
    // 使用crypto生成安全的随机字符串
    // 生成12字节 -> Base64编码后移除特殊字符 -> 截取16位
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let token = '';
    
    // 生成16位随机字符
    for (let i = 0; i < 16; i++) {
      const randomByte = crypto.randomBytes(1)[0];
      token += chars[randomByte % chars.length];
    }
    
    return token;
  }

  /**
   * 生成Token（主方法）
   * @param {Object} payload - Token载荷
   * @param {string} payload.emailId - 邮件ID（必需）
   * @param {string} payload.recipientEmail - 收件人邮箱（可选）
   * @param {Object} payload.metadata - 其他元数据（可选）
   * @returns {Promise<Object>} { token, emailId, expiresAt }
   */
  static async generate(payload) {
    try {
      // 验证必需参数
      if (!payload.emailId) {
        throw new Error('emailId is required');
      }

      const now = Date.now();
      
      // 生成16位短Token
      const token = this._generateShortToken();
      
      // Token过期时间（从配置读取，默认48小时）
      const expiryHours = config.token.expiryHours || 48;
      const expiresIn = expiryHours * 60 * 60 * 1000;
      const expiresAt = now + expiresIn;

      // 准备存储到Redis的数据
      const tokenData = {
        eid: payload.emailId,
        email: payload.recipientEmail || null,
        ts: now,
        exp: expiresAt,
        rnd: this._generateRandomString(16),
        createdAt: new Date(now).toISOString(),
        expiresAt: new Date(expiresAt).toISOString()
      };

      // 可选：添加收件人邮箱哈希
      if (payload.recipientEmail) {
        tokenData.reh = this._hashEmail(payload.recipientEmail);
      }

      // 可选：添加其他元数据
      if (payload.metadata) {
        tokenData.meta = payload.metadata;
      }

      // 存储到Redis（key = token:xxx, value = JSON数据）
      // TTL设置为过期时间（秒）
      const ttlSeconds = Math.floor(expiresIn / 1000);
      const redisKey = `token:${token}`;
      
      await Redis.setWithExpiry(
        redisKey,
        JSON.stringify(tokenData),
        ttlSeconds
      );

      logger.debug('Token已生成', {
        token: token,
        emailId: payload.emailId,
        expiresAt: new Date(expiresAt).toISOString()
      });

      return {
        token,
        emailId: payload.emailId,
        expiresAt: new Date(expiresAt).toISOString()
      };

    } catch (error) {
      logger.error('Token生成失败', {
        error: error.message,
        payload,
      });
      throw error;
    }
  }

  /**
   * 验证Token
   * @param {string} token - 要验证的Token
   * @returns {Promise<Object>} - { valid, reason, data }
   */
  static async verify(token) {
    try {
      // 1. 检查Token格式（必须是16位）
      if (!token || typeof token !== 'string' || token.length !== 16) {
        return { valid: false, reason: 'invalid_format' };
      }

      // 2. 从Redis获取Token数据
      const redisKey = `token:${token}`;
      const tokenDataStr = await Redis.get(redisKey);

      if (!tokenDataStr) {
        logger.warn('Token不存在或已过期', { 
          token: token.substring(0, 4) + '****'
        });
        return { valid: false, reason: 'not_found_or_expired' };
      }

      // 3. 解析Token数据
      let tokenData;
      try {
        tokenData = JSON.parse(tokenDataStr);
      } catch (parseError) {
        logger.error('Token数据解析失败', {
          error: parseError.message
        });
        return { valid: false, reason: 'invalid_data' };
      }

      // 4. 检查过期时间（双重验证）
      if (Date.now() > tokenData.exp) {
        logger.info('Token已过期', {
          emailId: tokenData.eid,
          expiredAt: new Date(tokenData.exp).toISOString()
        });
        
        // 删除已过期的Token
        await Redis.del(redisKey);
        
        return { valid: false, reason: 'expired', data: tokenData };
      }

      // 5. Token有效
      return { valid: true, data: tokenData };

    } catch (error) {
      logger.error('Token验证失败', { error: error.message });
      return { valid: false, reason: 'verification_error' };
    }
  }

  /**
   * 解析Token（不验证，仅获取数据）
   * @param {string} token - Token
   * @returns {Promise<Object|null>} - Token数据
   */
  static async parse(token) {
    try {
      if (!token || token.length !== 16) {
        return null;
      }

      const redisKey = `token:${token}`;
      const tokenDataStr = await Redis.get(redisKey);
      
      if (!tokenDataStr) {
        return null;
      }

      return JSON.parse(tokenDataStr);
    } catch (error) {
      return null;
    }
  }

  /**
   * 删除Token（主动失效）
   * @param {string} token - Token
   * @returns {Promise<boolean>}
   */
  static async revoke(token) {
    try {
      if (!token || token.length !== 16) {
        return false;
      }

      const redisKey = `token:${token}`;
      await Redis.del(redisKey);
      
      logger.info('Token已撤销', { 
        token: token.substring(0, 4) + '****'
      });
      
      return true;
    } catch (error) {
      logger.error('Token撤销失败', { error: error.message });
      return false;
    }
  }

  /**
   * 生成随机字符串
   * @param {number} length - 长度
   * @returns {string} - 随机字符串
   * @private
   */
  static _generateRandomString(length) {
    return crypto.randomBytes(length).toString('base64url').substring(0, length);
  }

  /**
   * 哈希邮箱地址
   * @param {string} email - 邮箱地址
   * @returns {string} - 哈希值
   * @private
   */
  static _hashEmail(email) {
    return crypto
      .createHash('sha256')
      .update(email.toLowerCase())
      .digest('base64url')
      .substring(0, 16);
  }

  /**
   * 批量生成Token
   * @param {Array} payloads - Token载荷数组
   * @returns {Promise<Array>} - Token数组
   */
  static async generateBatch(payloads) {
    const results = [];
    
    for (const payload of payloads) {
      try {
        const result = await this.generate(payload);
        results.push({
          success: true,
          token: result.token,
          emailId: payload.emailId,
          expiresAt: result.expiresAt
        });
      } catch (error) {
        results.push({
          success: false,
          error: error.message,
          emailId: payload.emailId,
        });
      }
    }
    
    return results;
  }

  /**
   * 获取Token剩余有效时间
   * @param {string} token - Token
   * @returns {Promise<number|null>} - 剩余秒数，null表示无效
   */
  static async getTimeToLive(token) {
    try {
      if (!token || token.length !== 16) {
        return null;
      }

      const redisKey = `token:${token}`;
      const ttl = await Redis.ttl(redisKey);
      
      // ttl返回-1表示没有过期时间，-2表示键不存在
      if (ttl < 0) {
        return null;
      }
      
      return ttl;
    } catch (error) {
      logger.error('获取Token TTL失败', { error: error.message });
      return null;
    }
  }

  /**
   * 检查Token是否存在
   * @param {string} token - Token
   * @returns {Promise<boolean>}
   */
  static async exists(token) {
    try {
      if (!token || token.length !== 16) {
        return false;
      }

      const redisKey = `token:${token}`;
      return await Redis.exists(redisKey);
    } catch (error) {
      logger.error('检查Token存在失败', { error: error.message });
      return false;
    }
  }
}

module.exports = TokenGenerator;
