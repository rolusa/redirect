/**
 * ============================================
 * 日志查询API路由
 * ============================================
 */

const express = require('express');
const router = express.Router();
const Database = require('../../database/mysql');
const { asyncHandler } = require('../middleware/errorHandler');

/**
 * GET /api/logs/access
 * 查询访问日志
 */
router.get('/access', asyncHandler(async (req, res) => {
  const {
    page = 1,
    pageSize = 20,
    ip,
    country,
    decision,
    dateFrom,
    dateTo,
    token
  } = req.query;

  let sql = 'SELECT * FROM access_logs WHERE 1=1';
  const params = [];

  // 构建查询条件
  if (ip) {
    sql += ' AND ip LIKE ?';
    params.push(`%${ip}%`);
  }

  if (country) {
    sql += ' AND country_code = ?';
    params.push(country);
  }

  if (decision) {
    sql += ' AND filter_decision = ?';
    params.push(decision);
  }

  if (dateFrom) {
    sql += ' AND created_at >= ?';
    params.push(dateFrom);
  }

  if (dateTo) {
    sql += ' AND created_at <= ?';
    params.push(dateTo);
  }

  if (token) {
    sql += ' AND token_hash = ?';
    params.push(token);
  }

  // 计算总数
  const countSql = sql.replace('SELECT *', 'SELECT COUNT(*) as total');
  const [countResult] = await Database.query(countSql, params);
  const total = countResult.total;

  // 分页查询
  sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  const offset = (parseInt(page) - 1) * parseInt(pageSize);
  params.push(parseInt(pageSize), offset);

  const logs = await Database.query(sql, params);

  res.json({
    success: true,
    data: {
      logs,
      pagination: {
        page: parseInt(page),
        pageSize: parseInt(pageSize),
        total,
        totalPages: Math.ceil(total / parseInt(pageSize))
      }
    }
  });
}));

/**
 * GET /api/logs/admin
 * 查询管理员操作日志
 */
router.get('/admin', asyncHandler(async (req, res) => {
  const {
    page = 1,
    pageSize = 20,
    username,
    action,
    dateFrom,
    dateTo
  } = req.query;

  let sql = 'SELECT * FROM admin_logs WHERE 1=1';
  const params = [];

  if (username) {
    sql += ' AND username = ?';
    params.push(username);
  }

  if (action) {
    sql += ' AND action = ?';
    params.push(action);
  }

  if (dateFrom) {
    sql += ' AND created_at >= ?';
    params.push(dateFrom);
  }

  if (dateTo) {
    sql += ' AND created_at <= ?';
    params.push(dateTo);
  }

  // 计算总数
  const countSql = sql.replace('SELECT *', 'SELECT COUNT(*) as total');
  const [countResult] = await Database.query(countSql, params);
  const total = countResult.total;

  // 分页查询
  sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  const offset = (parseInt(page) - 1) * parseInt(pageSize);
  params.push(parseInt(pageSize), offset);

  const logs = await Database.query(sql, params);

  res.json({
    success: true,
    data: {
      logs,
      pagination: {
        page: parseInt(page),
        pageSize: parseInt(pageSize),
        total,
        totalPages: Math.ceil(total / parseInt(pageSize))
      }
    }
  });
}));

/**
 * GET /api/logs/detail/:id
 * 获取日志详情
 */
router.get('/detail/:id', asyncHandler(async (req, res) => {
  const { id } = req.params;

  const log = await Database.queryOne(
    'SELECT * FROM access_logs WHERE id = ?',
    [id]
  );

  if (!log) {
    return res.status(404).json({
      success: false,
      message: '日志不存在'
    });
  }

  // 解析JSON字段
  if (log.filter_results) {
    try {
      log.filter_results = JSON.parse(log.filter_results);
    } catch (e) {
      // 保持原样
    }
  }

  res.json({
    success: true,
    data: log
  });
}));

module.exports = router;
