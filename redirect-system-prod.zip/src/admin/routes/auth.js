/**
 * ============================================
 * 认证API路由
 * ============================================
 */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const Database = require('../../database/mysql');
const logger = require('../../utils/logger');
const { generateToken, authMiddleware } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

/**
 * POST /api/auth/login
 * 管理员登录
 */
router.post('/login', asyncHandler(async (req, res) => {
  const { username, password } = req.body;
  const ip = req.ip || req.connection.remoteAddress;

  // 参数验证
  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: '用户名和密码不能为空'
    });
  }

  // 查询用户
  const user = await Database.queryOne(
    'SELECT * FROM admin_users WHERE username = ? AND is_active = 1',
    [username]
  );

  if (!user) {
    // 记录失败日志
    await Database.insert('admin_logs', {
      username,
      action: 'login_failed',
      details: '用户不存在',
      ip_address: ip,
      status: 'failed'
    });

    return res.status(401).json({
      success: false,
      message: '用户名或密码错误'
    });
  }

  // 检查账户是否被锁定
  if (user.locked_until && new Date(user.locked_until) > new Date()) {
    return res.status(423).json({
      success: false,
      message: '账户已被锁定，请稍后再试',
      locked_until: user.locked_until
    });
  }

  // 验证密码
  const passwordMatch = await bcrypt.compare(password, user.password_hash);

  if (!passwordMatch) {
    // 更新失败次数
    const attempts = user.login_attempts + 1;
    const updateData = { login_attempts: attempts };

    // 10次失败后锁定15分钟
    if (attempts >= 10) {
      const lockedUntil = new Date(Date.now() + 15 * 60 * 1000);
      updateData.locked_until = lockedUntil;
      
      await Database.update('admin_users', updateData, { id: user.id });

      // 记录锁定日志
      await Database.insert('admin_logs', {
        username,
        action: 'account_locked',
        details: `连续${attempts}次登录失败，账户被锁定15分钟`,
        ip_address: ip,
        status: 'success'
      });

      return res.status(423).json({
        success: false,
        message: '登录失败次数过多，账户已被锁定15分钟',
        locked_until: lockedUntil
      });
    }

    await Database.update('admin_users', updateData, { id: user.id });

    // 记录失败日志
    await Database.insert('admin_logs', {
      username,
      action: 'login_failed',
      details: `密码错误，剩余尝试次数: ${5 - attempts}`,
      ip_address: ip,
      status: 'failed'
    });

    return res.status(401).json({
      success: false,
      message: `用户名或密码错误，剩余尝试次数: ${10 - attempts}`
    });
  }

  // 登录成功，重置失败次数
  await Database.update('admin_users', {
    login_attempts: 0,
    locked_until: null,
    last_login_at: new Date(),
    last_login_ip: ip
  }, { id: user.id });

  // 生成JWT Token
  const token = generateToken({
    id: user.id,
    username: user.username,
    role: user.role
  });

  // 记录成功日志
  await Database.insert('admin_logs', {
    username,
    action: 'login_success',
    details: '登录成功',
    ip_address: ip,
    status: 'success'
  });

  logger.info('管理员登录成功', { username, ip });

  res.json({
    success: true,
    message: '登录成功',
    data: {
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    }
  });
}));

/**
 * POST /api/auth/logout
 * 管理员登出
 */
router.post('/logout', authMiddleware, asyncHandler(async (req, res) => {
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  // 记录登出日志
  await Database.insert('admin_logs', {
    username,
    action: 'logout',
    details: '登出系统',
    ip_address: ip,
    status: 'success'
  });

  logger.info('管理员登出', { username, ip });

  res.json({
    success: true,
    message: '登出成功'
  });
}));

/**
 * GET /api/auth/profile
 * 获取当前用户信息
 */
router.get('/profile', authMiddleware, asyncHandler(async (req, res) => {
  const user = await Database.queryOne(
    'SELECT id, username, email, role, last_login_at, last_login_ip, created_at FROM admin_users WHERE id = ?',
    [req.user.id]
  );

  if (!user) {
    return res.status(404).json({
      success: false,
      message: '用户不存在'
    });
  }

  res.json({
    success: true,
    data: user
  });
}));

/**
 * PUT /api/auth/password
 * 修改密码
 */
router.put('/password', authMiddleware, asyncHandler(async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  const { username, id } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  // 参数验证
  if (!oldPassword || !newPassword) {
    return res.status(400).json({
      success: false,
      message: '旧密码和新密码不能为空'
    });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({
      success: false,
      message: '新密码长度至少6位'
    });
  }

  // 查询用户
  const user = await Database.queryOne(
    'SELECT password_hash FROM admin_users WHERE id = ?',
    [id]
  );

  // 验证旧密码
  const passwordMatch = await bcrypt.compare(oldPassword, user.password_hash);
  
  if (!passwordMatch) {
    return res.status(401).json({
      success: false,
      message: '旧密码错误'
    });
  }

  // 加密新密码
  const newPasswordHash = await bcrypt.hash(newPassword, 10);

  // 更新密码
  await Database.update('admin_users', {
    password_hash: newPasswordHash
  }, { id });

  // 记录日志
  await Database.insert('admin_logs', {
    username,
    action: 'password_changed',
    details: '修改密码',
    ip_address: ip,
    status: 'success'
  });

  logger.info('管理员修改密码', { username, ip });

  res.json({
    success: true,
    message: '密码修改成功，请重新登录'
  });
}));

module.exports = router;
