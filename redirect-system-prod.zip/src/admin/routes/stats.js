/**
 * ============================================
 * 统计API路由
 * ============================================
 */

const express = require('express');
const router = express.Router();
const Database = require('../../database/mysql');
const Redis = require('../../database/redis');
const { asyncHandler } = require('../middleware/errorHandler');

/**
 * GET /api/stats/overview
 * 获取仪表板概览数据
 */
router.get('/overview', asyncHandler(async (req, res) => {
  // 系统运行时间
  const uptime = process.uptime();

  // 今日访问统计
  const todayStats = await Database.queryOne(`
    SELECT 
      COUNT(*) as total,
      COUNT(CASE WHEN filter_decision = 'allow' THEN 1 END) as allowed,
      COUNT(CASE WHEN filter_decision = 'reject' THEN 1 END) as rejected,
      AVG(process_time_ms) as avg_process_time
    FROM access_logs
    WHERE DATE(created_at) = CURDATE()
  `);

  // 国家分布（今日）
  const countryStats = await Database.query(`
    SELECT 
      country_code,
      country_name,
      COUNT(*) as count
    FROM access_logs
    WHERE DATE(created_at) = CURDATE() AND country_code IS NOT NULL
    GROUP BY country_code, country_name
    ORDER BY count DESC
    LIMIT 10
  `);

  // Token统计
  const tokenStats = await Database.queryOne(`
    SELECT 
      COUNT(*) as total_tokens,
      COUNT(CASE WHEN is_expired = 0 THEN 1 END) as active_tokens,
      COUNT(CASE WHEN is_expired = 1 THEN 1 END) as expired_tokens
    FROM token_usage
  `);

  // Redis信息
  let redisStatus = 'disconnected';
  let redisInfo = null;
  try {
    // 如果Redis未初始化，先初始化
    if (!Redis.isReady()) {
      try {
        await Redis.init();
      } catch (initError) {
        // 初始化失败，记录但不抛出错误
        console.log('Redis初始化失败:', initError.message);
      }
    }
    
    // 检查连接状态并ping
    if (Redis.isReady()) {
      await Redis.ping();
      redisStatus = 'connected';
      // 这里可以获取更多Redis信息
    }
  } catch (error) {
    redisStatus = 'disconnected';
  }

  // MySQL信息
  let mysqlStatus = 'unknown';
  try {
    await Database.query('SELECT 1');
    mysqlStatus = 'connected';
  } catch (error) {
    mysqlStatus = 'disconnected';
  }

  res.json({
    success: true,
    data: {
      system: {
        uptime,
        redisStatus,
        mysqlStatus,
        nodeVersion: process.version,
        platform: process.platform
      },
      today: {
        ...todayStats,
        allowRate: todayStats.total > 0 ? (todayStats.allowed / todayStats.total * 100).toFixed(2) : 0,
        rejectRate: todayStats.total > 0 ? (todayStats.rejected / todayStats.total * 100).toFixed(2) : 0
      },
      countries: countryStats,
      tokens: tokenStats
    }
  });
}));

/**
 * GET /api/stats/chart
 * 获取图表数据
 */
router.get('/chart/:type', asyncHandler(async (req, res) => {
  const { type } = req.params;
  const { days = 7 } = req.query;

  let data = [];

  switch (type) {
    case 'daily':
      // 每日访问趋势
      data = await Database.query(`
        SELECT 
          DATE(created_at) as date,
          COUNT(*) as total,
          COUNT(CASE WHEN filter_decision = 'allow' THEN 1 END) as allowed,
          COUNT(CASE WHEN filter_decision = 'reject' THEN 1 END) as rejected
        FROM access_logs
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
        GROUP BY DATE(created_at)
        ORDER BY date ASC
      `, [parseInt(days)]);
      break;

    case 'hourly':
      // 今日每小时访问
      data = await Database.query(`
        SELECT 
          HOUR(created_at) as hour,
          COUNT(*) as total,
          COUNT(CASE WHEN filter_decision = 'allow' THEN 1 END) as allowed,
          COUNT(CASE WHEN filter_decision = 'reject' THEN 1 END) as rejected
        FROM access_logs
        WHERE DATE(created_at) = CURDATE()
        GROUP BY HOUR(created_at)
        ORDER BY hour ASC
      `);
      break;

    case 'country':
      // 国家分布
      data = await Database.query(`
        SELECT 
          country_code,
          country_name,
          COUNT(*) as count,
          COUNT(CASE WHEN filter_decision = 'allow' THEN 1 END) as allowed,
          COUNT(CASE WHEN filter_decision = 'reject' THEN 1 END) as rejected
        FROM access_logs
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
          AND country_code IS NOT NULL
        GROUP BY country_code, country_name
        ORDER BY count DESC
        LIMIT 20
      `, [parseInt(days)]);
      break;

    default:
      return res.status(400).json({
        success: false,
        message: '不支持的图表类型'
      });
  }

  res.json({
    success: true,
    data
  });
}));

/**
 * GET /api/stats/realtime
 * 获取实时访问数据
 */
router.get('/realtime', asyncHandler(async (req, res) => {
  const { limit = 20 } = req.query;

  // 最近的访问记录
  const recentAccess = await Database.query(`
    SELECT 
      id,
      created_at,
      ip,
      country_code,
      country_name,
      filter_decision,
      rejection_reason,
      process_time_ms
    FROM access_logs
    ORDER BY created_at DESC
    LIMIT ?
  `, [parseInt(limit)]);

  // 最近1分钟的访问量
  const lastMinuteCount = await Database.queryOne(`
    SELECT COUNT(*) as count
    FROM access_logs
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)
  `);

  res.json({
    success: true,
    data: {
      recentAccess,
      lastMinuteCount: lastMinuteCount.count
    }
  });
}));

module.exports = router;
