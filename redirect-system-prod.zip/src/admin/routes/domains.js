/**
 * 重定向域名管理 API
 * 路径: src/admin/routes/domains.js
 */

const express = require('express');
const router = express.Router();
const Database = require('../../database/mysql');
const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const util = require('util');
const execPromise = util.promisify(exec);

/**
 * 获取所有重定向域名列表
 */
router.get('/list', async (req, res) => {
    try {
        const domains = await Database.query(`
            SELECT 
                id,
                domain_name,
                domain_type,
                ssl_enabled,
                ssl_provider,
                ssl_issued_date,
                ssl_expiry_date,
                days_left,
                is_active,
                is_cloudflare,
                use_for_links,
                notes,
                created_at
            FROM redirect_domains
            ORDER BY created_at DESC
        `);

        // 计算剩余天数
        for (const domain of domains) {
            if (domain.ssl_expiry_date) {
                const daysLeft = Math.floor((new Date(domain.ssl_expiry_date) - Date.now()) / (1000 * 60 * 60 * 24));
                domain.days_left = daysLeft;
                
                // 更新数据库中的days_left
                await Database.update('redirect_domains', 
                    { days_left: daysLeft }, 
                    { id: domain.id }
                );
            }
        }

        res.json({
            success: true,
            domains
        });
    } catch (error) {
        console.error('获取域名列表失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 添加新域名
 */
router.post('/add', async (req, res) => {
    try {
        const {
            domain_name,
            domain_type,
            is_cloudflare,
            cloudflare_zone_id,
            notes
        } = req.body;

        // 验证域名格式
        if (!domain_name || domain_name.trim() === '') {
            return res.json({ success: false, message: '域名不能为空' });
        }

        // 检查域名是否已存在
        const existing = await Database.queryOne(
            'SELECT id FROM redirect_domains WHERE domain_name = ?',
            [domain_name]
        );

        if (existing) {
            return res.json({ success: false, message: '域名已存在' });
        }

        // 插入新域名
        const insertId = await Database.insert('redirect_domains', {
            domain_name: domain_name,
            domain_type: domain_type || 'main',
            is_cloudflare: is_cloudflare || false,
            cloudflare_zone_id: cloudflare_zone_id || null,
            notes: notes || ''
        });

        res.json({
            success: true,
            message: '域名添加成功',
            id: insertId
        });

    } catch (error) {
        console.error('添加域名失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 删除域名 - 完整版
 * 彻底清理所有相关资源：配置文件、软链接、数据库记录
 * 即使nginx_config_path为空，也会根据域名生成标准路径进行清理
 */
router.delete('/delete/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { deleteSSL } = req.query; // 可选：是否删除SSL证书

        // 获取域名信息
        const domain = await Database.queryOne(
            'SELECT domain_name, nginx_config_path, cert_path, key_path FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        const domainName = domain.domain_name;
        const deletedItems = [];
        const failedItems = [];
        const warnings = [];

        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`🗑️  开始删除域名: ${domainName}`);
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

        // 生成标准的配置文件路径（即使数据库中没有记录）
        const configFileName = domainName.replace(/\*/g, 'wildcard').replace(/\./g, '_') + '.conf';
        const availablePath = `/etc/nginx/sites-available/${configFileName}`;
        const enabledPath = `/etc/nginx/sites-enabled/${configFileName}`;

        // 如果数据库中有记录的路径，也尝试删除
        const pathsToClean = new Set();
        if (domain.nginx_config_path) {
            pathsToClean.add(domain.nginx_config_path);
            const dbFileName = domain.nginx_config_path.split('/').pop();
            pathsToClean.add(`/etc/nginx/sites-enabled/${dbFileName}`);
        }
        // 添加标准路径
        pathsToClean.add(availablePath);
        pathsToClean.add(enabledPath);

        console.log(`📋 待清理路径列表:`);
        pathsToClean.forEach(path => console.log(`   - ${path}`));

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 第1步：删除所有可能的软链接和配置文件
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        console.log(`\n🔧 步骤1: 清理Nginx配置文件`);
        
        for (const filePath of pathsToClean) {
            try {
                // 检查文件是否存在
                const checkResult = await execPromise(`sudo test -e ${filePath} && echo "exists" || echo "not_exists"`);
                
                if (checkResult.stdout.trim() === 'exists') {
                    // 文件存在，删除它
                    await execPromise(`sudo rm -f ${filePath}`);
                    deletedItems.push(filePath);
                    console.log(`   ✅ 已删除: ${filePath}`);
                } else {
                    console.log(`   ⏭️  不存在: ${filePath}`);
                }
            } catch (error) {
                // 删除失败
                failedItems.push(`${filePath}: ${error.message}`);
                console.error(`   ❌ 删除失败: ${filePath}`);
                console.error(`      原因: ${error.message}`);
            }
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 第2步：额外检查 - 查找并删除可能遗漏的断链
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        console.log(`\n🔍 步骤2: 检查并清理断链`);
        
        try {
            // 查找sites-enabled中所有的断链
            const findBrokenLinks = await execPromise(
                `find /etc/nginx/sites-enabled/ -xtype l 2>/dev/null || echo ""`
            );
            
            if (findBrokenLinks.stdout.trim()) {
                const brokenLinks = findBrokenLinks.stdout.trim().split('\n');
                console.log(`   ⚠️  发现 ${brokenLinks.length} 个断链:`);
                
                for (const brokenLink of brokenLinks) {
                    if (brokenLink) {
                        try {
                            await execPromise(`sudo rm -f ${brokenLink}`);
                            deletedItems.push(`断链: ${brokenLink}`);
                            console.log(`   ✅ 已清理断链: ${brokenLink}`);
                            warnings.push(`清理了断链: ${brokenLink}`);
                        } catch (error) {
                            console.error(`   ❌ 清理断链失败: ${brokenLink}`);
                        }
                    }
                }
            } else {
                console.log(`   ✅ 没有发现断链`);
            }
        } catch (error) {
            console.warn(`   ⚠️  检查断链时出错: ${error.message}`);
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 第3步：测试Nginx配置
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        console.log(`\n🧪 步骤3: 测试Nginx配置`);
        
        let nginxTestPassed = false;
        let nginxTestOutput = '';
        
        try {
            const testResult = await execPromise('sudo nginx -t 2>&1');
            nginxTestOutput = testResult.stdout + testResult.stderr;
            
            if (nginxTestOutput.includes('syntax is ok') && nginxTestOutput.includes('test is successful')) {
                nginxTestPassed = true;
                console.log(`   ✅ Nginx配置测试通过`);
                deletedItems.push(`Nginx配置测试通过`);
            } else {
                console.warn(`   ⚠️  Nginx配置测试有警告`);
                console.warn(nginxTestOutput);
            }
        } catch (error) {
            nginxTestOutput = error.stdout + error.stderr + error.message;
            console.error(`   ❌ Nginx配置测试失败`);
            console.error(nginxTestOutput);
            failedItems.push(`Nginx配置测试失败: ${nginxTestOutput.substring(0, 200)}`);
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 第4步：重载Nginx服务
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        console.log(`\n🔄 步骤4: 重载Nginx服务`);
        
        if (nginxTestPassed) {
            try {
                await execPromise('sudo systemctl reload nginx');
                deletedItems.push(`Nginx服务已重载`);
                console.log(`   ✅ Nginx服务重载成功`);
            } catch (error) {
                // 重载失败，尝试重启
                console.warn(`   ⚠️  重载失败，尝试重启...`);
                try {
                    await execPromise('sudo systemctl restart nginx');
                    deletedItems.push(`Nginx服务已重启`);
                    console.log(`   ✅ Nginx服务重启成功`);
                } catch (restartError) {
                    failedItems.push(`Nginx重启失败: ${restartError.message}`);
                    console.error(`   ❌ Nginx重启失败`);
                    console.error(`      原因: ${restartError.message}`);
                }
            }
        } else {
            console.warn(`   ⚠️  跳过重载（配置测试未通过）`);
            warnings.push('Nginx配置测试未通过，已跳过服务重载');
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 第5步：可选删除SSL证书
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        console.log(`\n🔒 步骤5: SSL证书处理`);
        
        if (deleteSSL === 'true') {
            const certDomain = domainName.replace('*.', '');
            
            try {
                // 检查证书是否存在
                const certExists = await execPromise(
                    `sudo test -d /etc/letsencrypt/live/${certDomain} && echo "exists" || echo "not_exists"`
                );
                
                if (certExists.stdout.trim() === 'exists') {
                    // 使用 certbot delete 删除证书
                    await execPromise(`sudo certbot delete --cert-name ${certDomain} --non-interactive`);
                    deletedItems.push(`SSL证书: ${certDomain}`);
                    console.log(`   ✅ 已删除SSL证书: ${certDomain}`);
                } else {
                    console.log(`   ⏭️  SSL证书不存在: ${certDomain}`);
                }
            } catch (error) {
                failedItems.push(`SSL证书删除失败: ${error.message}`);
                console.error(`   ❌ 删除SSL证书失败`);
                console.error(`      原因: ${error.message}`);
            }
        } else {
            console.log(`   ℹ️  SSL证书已保留（可供将来使用）`);
            if (domain.cert_path) {
                warnings.push(`SSL证书已保留，如需删除请在删除时勾选"删除SSL证书"选项`);
            }
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 第6步：从数据库删除
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        console.log(`\n🗄️  步骤6: 删除数据库记录`);
        
        try {
            await Database.delete('redirect_domains', { id: id });
            deletedItems.push(`数据库记录: ${domainName}`);
            console.log(`   ✅ 已从数据库删除: ${domainName}`);
        } catch (error) {
            failedItems.push(`数据库删除失败: ${error.message}`);
            console.error(`   ❌ 数据库删除失败`);
            console.error(`      原因: ${error.message}`);
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 完成总结
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`🎯 删除完成: ${domainName}`);
        console.log(`   ✅ 成功项: ${deletedItems.length}`);
        console.log(`   ❌ 失败项: ${failedItems.length}`);
        console.log(`   ⚠️  警告: ${warnings.length}`);
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

        // 返回详细结果
        const response = {
            success: failedItems.length === 0,
            message: failedItems.length === 0 
                ? `✅ 域名 ${domainName} 已完全删除` 
                : `⚠️ 域名 ${domainName} 部分删除成功，但有${failedItems.length}项失败`,
            details: {
                domain: domainName,
                deleted: deletedItems,
                failed: failedItems.length > 0 ? failedItems : null,
                warnings: warnings.length > 0 ? warnings : null,
                summary: {
                    totalDeleted: deletedItems.length,
                    totalFailed: failedItems.length,
                    nginxStatus: nginxTestPassed ? 'OK' : 'Failed',
                    sslRetained: !deleteSSL && domain.cert_path
                }
            }
        };

        res.json(response);

    } catch (error) {
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.error('❌ 删除域名时发生严重错误:');
        console.error(error);
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        
        res.json({
            success: false,
            message: `删除域名失败: ${error.message}`,
            error: error.toString()
        });
    }
});

/**
 * 生成Nginx配置 - 改进版
 * 智能检测SSL证书状态，根据情况生成不同的配置
 */
router.post('/generate-nginx-config/:id', async (req, res) => {
    try {
        const { id } = req.params;

        // ========================================
        // 步骤0：清理断链（防止nginx -t失败）
        // ========================================
        try {
            console.log('🧹 检查并清理断链...');
            const cleanupResult = await cleanBrokenSymlinks();
            if (cleanupResult.removed.length > 0) {
                console.log(`✅ 清理了 ${cleanupResult.removed.length} 个断链:`, cleanupResult.removed);
            }
        } catch (cleanupError) {
            console.warn('⚠️ 清理断链时出错:', cleanupError.message);
            // 继续执行，不阻断主流程
        }

        // 获取域名信息（包括SSL证书路径）
        const domain = await Database.queryOne(
            'SELECT domain_name, domain_type, ssl_enabled, cert_path, key_path FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        const domainName = domain.domain_name;
        const certDomain = domainName.replace('*.', '');
        
        // 检查SSL证书是否存在
        let sslCertExists = false;
        let certPath = domain.cert_path || `/etc/letsencrypt/live/${certDomain}/fullchain.pem`;
        let keyPath = domain.key_path || `/etc/letsencrypt/live/${certDomain}/privkey.pem`;
        
        try {
            // 尝试检查证书文件是否存在
            await execPromise(`sudo test -f ${certPath} && sudo test -f ${keyPath}`);
            sslCertExists = true;
            console.log(`✅ SSL证书存在: ${domainName}`);
        } catch (error) {
            sslCertExists = false;
            console.log(`⚠️ SSL证书不存在: ${domainName}`);
        }

        // 根据SSL证书状态生成不同的配置
        const configContent = generateNginxConfig(domainName, domain.domain_type, sslCertExists);
        
        // 配置文件路径
        const configFileName = domainName.replace(/\*/g, 'wildcard').replace(/\./g, '_');
        const configPath = `/etc/nginx/sites-available/${configFileName}.conf`;
        const enabledPath = `/etc/nginx/sites-enabled/${configFileName}.conf`;

        // 如果SSL证书不存在，提醒用户先申请证书
        if (!sslCertExists) {
            return res.json({
                success: true,
                needSSLFirst: true,
                message: '⚠️ 检测到SSL证书未申请',
                warning: '建议先申请SSL证书，然后再生成Nginx配置',
                suggestion: '点击"🔒 申请SSL"按钮申请证书后，再生成配置',
                canContinue: true,
                configContent,
                suggestedPath: configPath,
                note: '也可以先生成仅HTTP的配置，等证书申请后再更新配置'
            });
        }

        // 保存配置文件（需要sudo权限）
        const tempPath = `/tmp/${configFileName}.conf`;
        await fs.writeFile(tempPath, configContent);

        // 移动到nginx目录（需要sudo）
        try {
            // 1. 移动配置文件到 sites-available
            await execPromise(`sudo mv ${tempPath} ${configPath}`);
            console.log(`✅ 配置文件已保存: ${configPath}`);
            
            // 2. 创建软链接到 sites-enabled（如果已存在会被覆盖）
            await execPromise(`sudo ln -sf ${configPath} ${enabledPath}`);
            console.log(`✅ 软链接已创建: ${enabledPath}`);
            
            // 3. 测试Nginx配置
            let nginxTestResult;
            try {
                // 不使用2>&1，分别捕获stdout和stderr
                nginxTestResult = await execPromise('sudo nginx -t');
            } catch (testError) {
                // nginx -t 失败，回滚更改
                console.error('❌ Nginx配置测试失败');
                console.error('错误详情:', testError);
                
                // 删除刚创建的软链接
                try {
                    await execPromise(`sudo rm -f ${enabledPath}`);
                    console.log(`🔄 已回滚：删除软链接 ${enabledPath}`);
                } catch (rollbackError) {
                    console.warn('回滚失败:', rollbackError.message);
                }
                
                // 组合所有可能的错误输出
                let errorOutput = '';
                
                // 尝试获取完整的错误信息
                if (testError.stdout) {
                    errorOutput += 'STDOUT:\n' + testError.stdout + '\n\n';
                }
                if (testError.stderr) {
                    errorOutput += 'STDERR:\n' + testError.stderr + '\n\n';
                }
                if (testError.message && !errorOutput) {
                    errorOutput = testError.message;
                }
                
                // 如果还是没有错误信息，使用通用提示
                if (!errorOutput || errorOutput.trim() === '') {
                    errorOutput = 'Nginx配置测试失败，但未能获取详细错误信息。\n请手动执行 sudo nginx -t 查看详细错误。';
                }
                
                console.log('捕获的错误输出:', errorOutput);
                
                return res.json({
                    success: false,
                    needManualSetup: true,
                    message: '❌ Nginx配置测试失败',
                    error: errorOutput,
                    configContent,
                    suggestedPath: configPath,
                    troubleshooting: [
                        '1. 手动执行查看详细错误: sudo nginx -t',
                        '2. 检查是否有其他Nginx配置文件存在冲突',
                        '3. 确认SSL证书路径是否正确: sudo ls -la /etc/letsencrypt/live/' + certDomain + '/',
                        '4. 查看Nginx错误日志: sudo tail -f /var/log/nginx/error.log',
                        '5. 检查端口80和443是否被占用: sudo netstat -tlnp | grep -E ":(80|443)"',
                        '6. 检查是否有重复的listen指令（多个配置监听同一端口）'
                    ],
                    suggestion: '请根据错误信息修复问题后重试，或手动配置Nginx'
                });
            }
            
            const testOutput = nginxTestResult.stdout + nginxTestResult.stderr;
            if (!testOutput.includes('syntax is ok') || !testOutput.includes('test is successful')) {
                throw new Error('Nginx配置测试未通过: ' + testOutput);
            }
            
            console.log('✅ Nginx配置测试通过');

            // 4. 重载Nginx
            await execPromise('sudo systemctl reload nginx');
            console.log('✅ Nginx已重载');

            // 5. 更新数据库
            await Database.update('redirect_domains',
                { nginx_config_path: configPath },
                { id: id }
            );

            res.json({
                success: true,
                message: '✅ Nginx配置生成并应用成功',
                configPath,
                enabledPath,
                configContent,
                details: {
                    domainName,
                    sslEnabled: sslCertExists,
                    certPath: sslCertExists ? certPath : null,
                    nginxReloaded: true
                }
            });

        } catch (error) {
            // 捕获其他错误（如sudo权限问题等）
            console.error('生成Nginx配置时出错:', error);
            
            // 清理可能创建的临时文件
            try {
                await fs.unlink(tempPath);
            } catch (cleanupError) {
                // 忽略清理错误
            }
            
            res.json({
                success: false,
                needManualSetup: true,
                message: '⚠️ 自动配置失败，需要手动操作',
                reason: error.message,
                configContent,
                suggestedPath: configPath,
                manualSteps: [
                    `sudo nano ${configPath}`,
                    '粘贴上面的配置内容并保存',
                    `sudo ln -sf ${configPath} ${enabledPath}`,
                    'sudo nginx -t',
                    'sudo systemctl reload nginx'
                ]
            });
        }

    } catch (error) {
        console.error('生成Nginx配置失败:', error);
        res.json({
            success: false,
            message: '❌ 生成配置失败: ' + error.message
        });
    }
});

/**
 * 申请SSL证书 - 改进版本
 * 使用更可靠的证书申请策略：
 * 1. 优先使用 webroot 方式（不依赖Nginx配置）
 * 2. 如果失败，降级到 standalone 方式（自动处理Nginx）
 * 3. 自动处理配置冲突问题
 */
router.post('/apply-ssl/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { email, useCloudflare } = req.body;

        // 检测操作系统
        const isWindows = process.platform === 'win32';
        
        if (isWindows) {
            return res.json({
                success: false,
                isWindows: true,
                message: '❌ SSL证书申请功能仅在Linux服务器上可用',
                details: 'Windows环境不支持Certbot和Nginx，请在Ubuntu 22.04服务器上使用此功能。',
                requirements: [
                    '✅ Ubuntu 22.04 或更高版本',
                    '✅ 已安装 Nginx',
                    '✅ 已安装 Certbot',
                    '✅ 域名已解析到服务器IP',
                    '✅ 端口 80 和 443 已开放'
                ]
            });
        }

        // 获取域名信息
        const domain = await Database.queryOne(
            'SELECT domain_name, domain_type, is_cloudflare FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        const domainName = domain.domain_name;
        const isWildcard = domain.domain_type === 'wildcard';
        const isCloudflare = useCloudflare || domain.is_cloudflare;
        const emailAddress = email || `admin@${domainName.replace('*.', '')}`;

        // 通配符证书需要DNS验证
        if (isWildcard) {
            let certbotCommand;
            
            if (isCloudflare) {
                // 使用CloudFlare DNS验证
                certbotCommand = `sudo certbot certonly --dns-cloudflare --dns-cloudflare-credentials /root/.secrets/cloudflare.ini -d "${domainName}" --non-interactive --agree-tos --email ${emailAddress}`;
            } else {
                // 手动DNS验证
                return res.json({
                    success: false,
                    needManualDNS: true,
                    message: '通配符证书需要DNS验证',
                    instructions: `
通配符证书（*.${domainName.replace('*.', '')}）需要手动DNS验证：

1. SSH连接到服务器
2. 运行命令：
   sudo certbot certonly --manual --preferred-challenges dns -d "${domainName}" --agree-tos --email ${emailAddress}

3. 按照提示添加DNS TXT记录
4. 等待DNS生效后按回车完成验证

或者启用Cloudflare DNS验证功能。
                    `.trim()
                });
            }

            try {
                console.log('执行Certbot命令 (通配符):', certbotCommand);
                const { stdout, stderr } = await execPromise(certbotCommand, { timeout: 120000 });
                
                console.log('Certbot输出:', stdout);
                if (stderr) console.log('Certbot stderr:', stderr);

                // 证书申请成功，更新证书信息并获取返回值
                const certInfo = await updateCertificateInfo(domainName, id, isCloudflare);
                
                res.json({
                    success: true,
                    message: 'SSL证书申请成功（通配符证书）',
                    provider: isCloudflare ? 'cloudflare' : 'letsencrypt',
                    expiryDate: certInfo.expiryDate,
                    daysLeft: certInfo.daysLeft,
                    certPath: certInfo.certPath
                });

            } catch (error) {
                console.error('通配符证书申请失败:', error);
                throw error;
            }
            
            return;
        }

        // ============================================
        // 主域名证书申请 - 使用智能策略
        // ============================================

        console.log(`开始为域名 ${domainName} 申请SSL证书`);

        // 策略1: 尝试 Webroot 方式（推荐，不依赖Nginx配置）
        try {
            console.log('策略1: 尝试 Webroot 方式...');
            
            // 确保webroot目录存在
            await execPromise('sudo mkdir -p /var/www/html/.well-known/acme-challenge');
            
            const webrootCommand = `sudo certbot certonly --webroot -w /var/www/html -d "${domainName}" --non-interactive --agree-tos --email ${emailAddress} --force-renewal`;
            
            console.log('执行命令:', webrootCommand);
            const { stdout, stderr } = await execPromise(webrootCommand, { timeout: 120000 });
            
            console.log('Webroot方式成功!');
            console.log('输出:', stdout);
            if (stderr) console.log('stderr:', stderr);

            // 更新证书信息并获取返回值
            const certInfo = await updateCertificateInfo(domainName, id, isCloudflare);
            
            return res.json({
                success: true,
                message: 'SSL证书申请成功（Webroot方式）',
                method: 'webroot',
                expiryDate: certInfo.expiryDate,
                daysLeft: certInfo.daysLeft,
                certPath: certInfo.certPath
            });

        } catch (webrootError) {
            console.log('Webroot方式失败:', webrootError.message);
            console.log('尝试策略2...');
        }

        // 策略2: 使用 Standalone 方式（最可靠，但需要临时停止Nginx）
        try {
            console.log('策略2: 尝试 Standalone 方式...');
            
            // 检查80端口是否被占用
            const portCheck = await execPromise('sudo netstat -tlnp | grep ":80 " || sudo ss -tlnp | grep ":80 " || echo "ok"').catch(() => ({ stdout: 'ok' }));
            const isPort80Used = !portCheck.stdout.includes('ok');
            
            let needRestartNginx = false;
            
            if (isPort80Used) {
                console.log('端口80被占用，临时停止Nginx...');
                await execPromise('sudo systemctl stop nginx');
                needRestartNginx = true;
                
                // 等待端口释放
                await new Promise(resolve => setTimeout(resolve, 2000));
            }

            try {
                const standaloneCommand = `sudo certbot certonly --standalone -d "${domainName}" --non-interactive --agree-tos --email ${emailAddress} --force-renewal`;
                
                console.log('执行命令:', standaloneCommand);
                const { stdout, stderr } = await execPromise(standaloneCommand, { timeout: 120000 });
                
                console.log('Standalone方式成功!');
                console.log('输出:', stdout);
                if (stderr) console.log('stderr:', stderr);

                // 更新证书信息并获取返回值
                const certInfo = await updateCertificateInfo(domainName, id, isCloudflare);
                
                return res.json({
                    success: true,
                    message: 'SSL证书申请成功（Standalone方式）',
                    method: 'standalone',
                    expiryDate: certInfo.expiryDate,
                    daysLeft: certInfo.daysLeft,
                    certPath: certInfo.certPath
                });

            } finally {
                // 无论成功失败，都要重启Nginx
                if (needRestartNginx) {
                    console.log('重启Nginx...');
                    await execPromise('sudo systemctl start nginx').catch(err => {
                        console.error('重启Nginx失败:', err);
                    });
                }
            }

        } catch (standaloneError) {
            console.error('Standalone方式也失败:', standaloneError.message);
            
            // 两种方式都失败了，返回详细错误信息
            const errorMsg = standaloneError.stderr || standaloneError.message || standaloneError.toString();
            
            // 分析错误原因
            let troubleshooting = [];
            
            if (errorMsg.includes('DNS') || errorMsg.includes('domain')) {
                troubleshooting.push('❌ 域名解析问题：请确认域名已正确解析到服务器IP');
            }
            
            if (errorMsg.includes('port') || errorMsg.includes('80')) {
                troubleshooting.push('❌ 端口80被占用或无法访问：检查防火墙和安全组');
            }
            
            if (errorMsg.includes('timeout') || errorMsg.includes('connection')) {
                troubleshooting.push('❌ 网络连接问题：确保服务器可以访问Let\'s Encrypt服务器');
            }
            
            if (errorMsg.includes('rate limit')) {
                troubleshooting.push('❌ 请求频率限制：Let\'s Encrypt有申请频率限制，请稍后再试');
            }
            
            if (troubleshooting.length === 0) {
                troubleshooting.push('请检查服务器日志：sudo tail -50 /var/log/letsencrypt/letsencrypt.log');
            }

            return res.json({
                success: false,
                message: 'SSL证书申请失败',
                error: errorMsg.split('\n').slice(0, 5).join('\n'), // 只返回前5行错误
                troubleshooting
            });
        }

    } catch (error) {
        console.error('申请SSL证书失败:', error);
        
        return res.json({
            success: false,
            message: error.message || 'SSL证书申请失败',
            error: error.toString()
        });
    }
});

/**
 * 更新证书信息到数据库
 */
async function updateCertificateInfo(domainName, domainId, isCloudflare) {
    try {
        const certPath = `/etc/letsencrypt/live/${domainName.replace('*.', '')}/fullchain.pem`;
        const keyPath = `/etc/letsencrypt/live/${domainName.replace('*.', '')}/privkey.pem`;

        // 获取证书过期时间
        const { stdout: certInfo } = await execPromise(`sudo openssl x509 -in ${certPath} -noout -enddate`);
        const expiryMatch = certInfo.match(/notAfter=(.+)/);
        const expiryDate = expiryMatch ? new Date(expiryMatch[1]) : null;
        const daysLeft = expiryDate ? Math.floor((expiryDate - Date.now()) / (1000 * 60 * 60 * 24)) : null;

        // 更新数据库
        await Database.query(`
            UPDATE redirect_domains 
            SET ssl_enabled = TRUE,
                ssl_provider = ?,
                ssl_issued_date = NOW(),
                ssl_expiry_date = ?,
                days_left = ?,
                cert_path = ?,
                key_path = ?
            WHERE id = ?
        `, [
            isCloudflare ? 'cloudflare' : 'letsencrypt',
            expiryDate,
            daysLeft,
            certPath,
            keyPath,
            domainId
        ]);

        console.log(`证书信息已更新到数据库: ${domainName}, 过期时间: ${expiryDate}, 剩余天数: ${daysLeft}`);
        
        return {
            certPath,
            keyPath,
            expiryDate,
            daysLeft
        };
        
    } catch (error) {
        console.error('更新证书信息失败:', error);
        throw error;
    }
}

/**
 * 检查SSL证书状态
 */
router.get('/check-ssl/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const domain = await Database.queryOne(
            'SELECT domain_name, cert_path FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain || !domain.cert_path) {
            return res.json({ success: false, message: '未找到证书' });
        }

        // 检查证书过期时间
        const { stdout } = await execPromise(`sudo openssl x509 -in ${domain.cert_path} -noout -enddate`);
        const expiryMatch = stdout.match(/notAfter=(.+)/);
        const expiryDate = expiryMatch ? new Date(expiryMatch[1]) : null;
        const daysLeft = expiryDate ? Math.floor((expiryDate - Date.now()) / (1000 * 60 * 60 * 24)) : null;

        // 更新数据库
        await Database.update('redirect_domains',
            { ssl_expiry_date: expiryDate, days_left: daysLeft },
            { id: id }
        );

        res.json({
            success: true,
            domain: domain.domain_name,
            expiryDate,
            daysLeft,
            status: daysLeft > 30 ? 'healthy' : daysLeft > 7 ? 'warning' : 'critical'
        });

    } catch (error) {
        console.error('检查SSL证书失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 切换域名激活状态
 */
router.post('/toggle/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const domain = await Database.queryOne(
            'SELECT is_active FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        const newStatus = !domain.is_active;
        await Database.update('redirect_domains',
            { is_active: newStatus },
            { id: id }
        );

        res.json({
            success: true,
            message: `域名已${newStatus ? '激活' : '停用'}`,
            is_active: newStatus
        });

    } catch (error) {
        console.error('切换域名状态失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 生成Nginx配置内容 - 改进版
 * @param {string} domainName - 域名
 * @param {string} domainType - 域名类型 (main/wildcard)
 * @param {boolean} sslEnabled - 是否启用SSL（证书是否存在）
 */
function generateNginxConfig(domainName, domainType, sslEnabled = true) {
    const serverName = domainName;
    const certDomain = domainName.replace('*.', '');
    
    if (sslEnabled) {
        // 完整的HTTP + HTTPS配置（证书存在时）
        return `# Nginx配置 - ${domainName}
# 自动生成时间: ${new Date().toISOString()}
# 配置类型: HTTP + HTTPS (SSL证书已存在)

# HTTP to HTTPS 重定向
server {
    listen 80;
    listen [::]:80;
    server_name ${serverName};
    
    # Let's Encrypt 验证
    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }
    
    # 重定向到HTTPS
    location / {
        return 301 https://$host$request_uri;
    }
}

# HTTPS 服务
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name ${serverName};
    
    # SSL 证书配置
    ssl_certificate /etc/letsencrypt/live/${certDomain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${certDomain}/privkey.pem;
    
    # SSL 安全配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # 反向代理到Node.js服务
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # 超时设置
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # 日志
    access_log /var/log/nginx/${certDomain}_access.log;
    error_log /var/log/nginx/${certDomain}_error.log;
}
`;
    } else {
        // 仅HTTP配置（证书不存在时）
        return `# Nginx配置 - ${domainName}
# 自动生成时间: ${new Date().toISOString()}
# 配置类型: 仅HTTP (等待SSL证书申请)
# ⚠️ 注意: 此配置仅支持HTTP访问，申请SSL证书后请重新生成配置

# HTTP 服务（临时配置）
server {
    listen 80;
    listen [::]:80;
    server_name ${serverName};
    
    # Let's Encrypt 验证目录（用于申请SSL证书）
    location /.well-known/acme-challenge/ {
        root /var/www/html;
        allow all;
    }
    
    # 反向代理到Node.js服务
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # 超时设置
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # 日志
    access_log /var/log/nginx/${certDomain}_access.log;
    error_log /var/log/nginx/${certDomain}_error.log;
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 📝 下一步操作提示:
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 
# 1. 确保域名 ${domainName} 已正确解析到服务器IP
# 2. 点击"🔒 申请SSL"按钮申请Let's Encrypt证书
# 3. 证书申请成功后，再次点击"📝 生成Nginx配置"更新为HTTPS配置
# 4. 当前配置可以让你先通过HTTP访问，同时支持SSL证书申请
# 
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    }
}

/**
 * 清理断链的软链接
 * 检查 /etc/nginx/sites-enabled/ 中的所有软链接
 * 删除指向不存在文件的断链
 */
async function cleanBrokenSymlinks() {
    const removed = [];
    const errors = [];
    
    try {
        // 查找所有断链（使用 find -L 命令）
        const { stdout } = await execPromise('find /etc/nginx/sites-enabled/ -xtype l 2>/dev/null || true');
        
        if (stdout && stdout.trim()) {
            const brokenLinks = stdout.trim().split('\n').filter(link => link);
            
            for (const link of brokenLinks) {
                try {
                    await execPromise(`sudo rm -f "${link}"`);
                    removed.push(link);
                    console.log(`🗑️ 已清理断链: ${link}`);
                } catch (error) {
                    errors.push({ link, error: error.message });
                    console.warn(`⚠️ 清理断链失败: ${link}`, error.message);
                }
            }
        }
        
        return { removed, errors };
    } catch (error) {
        console.error('清理断链时出错:', error);
        return { removed, errors: [{ general: error.message }] };
    }
}

/**
 * 切换域名的"用于生成链接"状态
 */
router.post('/toggle-use-for-links/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const domain = await Database.queryOne(
            'SELECT use_for_links FROM redirect_domains WHERE id = ?',
            [id]
        );

        if (!domain) {
            return res.json({ success: false, message: '域名不存在' });
        }

        const newStatus = !domain.use_for_links;
        await Database.update('redirect_domains',
            { use_for_links: newStatus },
            { id: id }
        );

        res.json({
            success: true,
            message: `域名已${newStatus ? '启用' : '禁用'}用于生成链接`,
            use_for_links: newStatus
        });

    } catch (error) {
        console.error('切换域名用于生成链接状态失败:', error);
        res.json({
            success: false,
            message: error.message
        });
    }
});

/**
 * 手动清理断链
 * 提供给管理员手动触发清理操作
 */
router.post('/cleanup-broken-links', async (req, res) => {
    try {
        console.log('🧹 开始手动清理断链...');
        
        const result = await cleanBrokenSymlinks();
        
        if (result.removed.length > 0) {
            // 清理成功后，测试nginx配置
            try {
                await execPromise('sudo nginx -t');
                console.log('✅ Nginx配置测试通过');
                
                // 如果测试通过，尝试重载nginx
                try {
                    await execPromise('sudo systemctl reload nginx');
                    console.log('✅ Nginx已重载');
                } catch (reloadError) {
                    console.warn('⚠️ Nginx重载失败:', reloadError.message);
                }
            } catch (testError) {
                console.warn('⚠️ Nginx配置测试失败:', testError.message);
            }
            
            res.json({
                success: true,
                message: `成功清理 ${result.removed.length} 个断链`,
                removed: result.removed,
                errors: result.errors.length > 0 ? result.errors : null
            });
        } else {
            res.json({
                success: true,
                message: '没有发现断链',
                removed: [],
                errors: result.errors.length > 0 ? result.errors : null
            });
        }
    } catch (error) {
        console.error('清理断链失败:', error);
        res.json({
            success: false,
            message: '清理断链失败: ' + error.message
        });
    }
});

/**
 * 获取可用于生成链接的域名列表
 */
router.get('/available-for-links', async (req, res) => {
    try {
        const domains = await Database.query(`
            SELECT 
                id,
                domain_name,
                domain_type,
                ssl_enabled,
                is_active,
                use_for_links
            FROM redirect_domains
            WHERE is_active = TRUE AND use_for_links = TRUE
            ORDER BY created_at ASC
        `);

        res.json({
            success: true,
            domains: domains.map(d => d.domain_name),
            details: domains
        });

    } catch (error) {
        console.error('获取可用域名列表失败:', error);
        res.json({
            success: false,
            message: error.message,
            domains: []
        });
    }
});

module.exports = router;
