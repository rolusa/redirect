/**
 * ============================================
 * 行为分析过滤器
 * ============================================
 * 功能：
 * 1. 访问频率限制（防止短时间内大量访问）
 * 2. 访问时间分析
 * 3. Referer检查
 * 4. 访问模式异常检测
 * ============================================
 */

const logger = require('../utils/logger');
const Cache = require('../utils/cache');
const { config } = require('../config');

/**
 * 行为分析过滤器类
 */
class BehaviorFilter {
  /**
   * 执行行为分析过滤
   * @param {Object} ipInfo - IP信息对象
   * @param {Object} request - 请求对象
   * @returns {Object} - 过滤结果
   */
  static async filter(ipInfo, request) {
    try {
      const ip = ipInfo.ip;
      const checks = [];
      let decision = 'allow';
      let reason = null;

      // 1. 访问频率检查
      const rateCheck = await this._checkRateLimit(ip);
      checks.push(rateCheck);

      if (!rateCheck.passed) {
        decision = 'reject';
        reason = rateCheck.reason;
      }

      // 2. 访问时间分析
      if (decision === 'allow') {
        const timeCheck = this._checkAccessTime(ipInfo.timeZone);
        checks.push(timeCheck);

        // 可疑时间只记录警告，不直接拒绝
        if (!timeCheck.passed) {
          logger.warn('可疑访问时间', {
            ip,
            reason: timeCheck.reason,
          });
        }
      }

      // 3. Referer检查
      if (decision === 'allow') {
        const refererCheck = this._checkReferer(request.headers.referer);
        checks.push(refererCheck);

        // Referer检查失败只记录，不直接拒绝
        if (!refererCheck.passed) {
          logger.info('Referer检查失败', {
            ip,
            referer: request.headers.referer,
            reason: refererCheck.reason,
          });
        }
      }

      // 4. 访问模式检查
      if (decision === 'allow') {
        const patternCheck = await this._checkAccessPattern(ip);
        checks.push(patternCheck);

        if (!patternCheck.passed) {
          decision = 'reject';
          reason = patternCheck.reason;
        }
      }

      const result = {
        passed: decision === 'allow',
        decision,
        reason,
        checks,
        visitCount: rateCheck.visitCount || 0,
      };

      logger.debug('行为分析过滤完成', {
        ip,
        decision,
        visitCount: result.visitCount,
      });

      return result;
    } catch (error) {
      logger.error('行为分析过滤失败', {
        ip: ipInfo?.ip,
        error: error.message,
      });

      return {
        passed: true,
        decision: 'allow',
        reason: 'Filter error - default allow',
        checks: [],
        error: error.message,
      };
    }
  }

  /**
   * 检查访问频率限制
   * @param {string} ip - IP地址
   * @returns {Promise<Object>} - 检查结果
   * @private
   */
  static async _checkRateLimit(ip) {
    const limits = config.rateLimit;
    const now = Date.now();

    try {
      // 检查各个时间窗口的限制
      for (const [window, limit] of Object.entries(limits)) {
        const key = `rate_limit:${window}:${ip}`;
        const count = await Cache.incr(key);

        // 首次访问，设置过期时间
        if (count === 1) {
          await Cache.expire(key, limit.window);
        }

        // 检查是否超限
        if (count > limit.max) {
          logger.warn('访问频率超限', {
            ip,
            window,
            count,
            limit: limit.max,
          });

          return {
            name: `Rate Limit (${window})`,
            passed: false,
            reason: `Too many requests: ${count}/${limit.max} in ${window}`,
            window,
            count,
            limit: limit.max,
            visitCount: count,
          };
        }
      }

      // 获取总访问次数（从最长时间窗口）
      const totalKey = `rate_limit:24hour:${ip}`;
      const totalCount = parseInt(await Cache.get(totalKey)) || 1;

      return {
        name: 'Rate Limit',
        passed: true,
        visitCount: totalCount,
      };
    } catch (error) {
      logger.error('频率限制检查失败', {
        ip,
        error: error.message,
      });

      return {
        name: 'Rate Limit',
        passed: true, // 出错时允许通过
        error: error.message,
      };
    }
  }

  /**
   * 检查访问时间
   * @param {Object} timezone - 时区信息
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkAccessTime(timezone) {
    const now = new Date();
    const currentHour = now.getHours();

    // 如果有时区信息，转换为IP所在地的时间
    let ipLocalHour = currentHour;
    if (timezone && timezone.offset) {
      ipLocalHour = (currentHour + timezone.offset / 3600) % 24;
    }

    // 可疑时段：凌晨0-5点
    const suspiciousHours = [0, 1, 2, 3, 4, 5];
    const isSuspicious = suspiciousHours.includes(Math.floor(ipLocalHour));

    return {
      name: 'Access Time',
      passed: !isSuspicious,
      currentHour,
      ipLocalHour: Math.floor(ipLocalHour),
      timezone: timezone?.id || 'Unknown',
      reason: isSuspicious
        ? `Suspicious access time: ${Math.floor(ipLocalHour)}:00`
        : null,
    };
  }

  /**
   * 检查Referer
   * @param {string} referer - Referer头
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkReferer(referer) {
    // 空Referer是允许的（邮件客户端）
    if (!referer) {
      return {
        name: 'Referer Check',
        passed: true,
        referer: 'empty',
        note: 'Empty referer allowed (email clients)',
      };
    }

    // 检查是否来自已知的邮件服务
    const knownEmailServices = [
      'mail.google.com',
      'outlook.live.com',
      'outlook.office.com',
      'mail.yahoo.com',
      'mail.qq.com',
      'mail.163.com',
      'mail.126.com',
    ];

    const lowerReferer = referer.toLowerCase();
    const isFromEmail = knownEmailServices.some(service =>
      lowerReferer.includes(service)
    );

    if (isFromEmail) {
      return {
        name: 'Referer Check',
        passed: true,
        referer: referer,
        source: 'email_service',
      };
    }

    // 检查是否来自我们自己的域名
    const redirectDomains = config.domains.redirectDomains || [];
    const isFromOurDomain = redirectDomains.some(domain =>
      lowerReferer.includes(domain)
    );

    if (isFromOurDomain) {
      return {
        name: 'Referer Check',
        passed: true,
        referer: referer,
        source: 'redirect_domain',
      };
    }

    // 其他来源标记为可疑（但不直接拒绝）
    return {
      name: 'Referer Check',
      passed: true,
      referer: referer,
      source: 'unknown',
      note: 'Unknown referer source',
    };
  }

  /**
   * 检查访问模式
   * @param {string} ip - IP地址
   * @returns {Promise<Object>} - 检查结果
   * @private
   */
  static async _checkAccessPattern(ip) {
    try {
      // 获取最近的访问时间戳
      const key = `access_pattern:${ip}`;
      const timestamps = await Cache.get(key) || [];

      // 添加当前时间戳
      const now = Date.now();
      timestamps.push(now);

      // 只保留最近10次访问
      const recentTimestamps = timestamps.slice(-10);

      // 保存更新后的时间戳
      await Cache.set(key, recentTimestamps, 3600); // 1小时过期

      // 如果访问次数少于3次，无法判断模式
      if (recentTimestamps.length < 3) {
        return {
          name: 'Access Pattern',
          passed: true,
          count: recentTimestamps.length,
        };
      }

      // 计算访问间隔
      const intervals = [];
      for (let i = 1; i < recentTimestamps.length; i++) {
        intervals.push(recentTimestamps[i] - recentTimestamps[i - 1]);
      }

      // 检查间隔是否过于规律（自动化特征）
      const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      const variance = intervals.reduce((sum, interval) => {
        return sum + Math.pow(interval - avgInterval, 2);
      }, 0) / intervals.length;
      const stdDev = Math.sqrt(variance);

      // 如果标准差很小，说明访问间隔非常规律（可能是脚本）
      const isRegular = stdDev < avgInterval * 0.1 && intervals.length >= 3;

      // 检查是否有短时间内的突发访问
      const recentBurst = intervals.filter(interval => interval < 1000).length;
      const hasBurst = recentBurst >= 3;

      if (isRegular) {
        return {
          name: 'Access Pattern',
          passed: false,
          reason: 'Too regular access pattern (possible bot)',
          avgInterval: Math.round(avgInterval),
          stdDev: Math.round(stdDev),
        };
      }

      if (hasBurst) {
        return {
          name: 'Access Pattern',
          passed: false,
          reason: 'Burst access detected',
          burstCount: recentBurst,
        };
      }

      return {
        name: 'Access Pattern',
        passed: true,
        count: recentTimestamps.length,
        avgInterval: Math.round(avgInterval),
      };
    } catch (error) {
      logger.error('访问模式检查失败', {
        ip,
        error: error.message,
      });

      return {
        name: 'Access Pattern',
        passed: true,
        error: error.message,
      };
    }
  }

  /**
   * 清除IP的访问记录（用于测试或重置）
   * @param {string} ip - IP地址
   * @returns {Promise<boolean>}
   */
  static async clearIPRecords(ip) {
    try {
      const patterns = [
        `rate_limit:*:${ip}`,
        `access_pattern:${ip}`,
      ];

      for (const pattern of patterns) {
        await Cache.delPattern(pattern);
      }

      logger.info('IP访问记录已清除', { ip });
      return true;
    } catch (error) {
      logger.error('清除IP记录失败', { ip, error: error.message });
      return false;
    }
  }

  /**
   * 获取IP的访问统计
   * @param {string} ip - IP地址
   * @returns {Promise<Object>}
   */
  static async getIPStats(ip) {
    try {
      const stats = {};

      // 获取各时间窗口的访问次数
      for (const window of Object.keys(config.rateLimit)) {
        const key = `rate_limit:${window}:${ip}`;
        const count = parseInt(await Cache.get(key)) || 0;
        stats[window] = count;
      }

      // 获取访问模式数据
      const patternKey = `access_pattern:${ip}`;
      const timestamps = await Cache.get(patternKey) || [];
      stats.recentAccesses = timestamps.length;

      return stats;
    } catch (error) {
      logger.error('获取IP统计失败', { ip, error: error.message });
      return {};
    }
  }

  /**
   * 获取过滤器名称
   * @returns {string}
   */
  static getName() {
    return 'BehaviorFilter';
  }

  /**
   * 检查是否启用
   * @returns {boolean}
   */
  static isEnabled() {
    return config.filters.behavior !== false;
  }
}

module.exports = BehaviorFilter;
