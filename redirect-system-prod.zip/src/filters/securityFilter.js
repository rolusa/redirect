/**
 * 安全过滤器
 * 检测和过滤潜在的安全威胁访问
 * - VPN检测
 * - 代理检测
 * - Tor网络检测
 * - 云服务商检测
 * - 攻击者/滥用者检测
 */

const logger = require('../utils/logger');

class SecurityFilter {
  constructor() {
    // 安全威胁类型定义
    this.threatTypes = {
      VPN: 'is_vpn',
      PROXY: 'is_proxy',
      TOR: 'is_tor',
      TOR_EXIT: 'is_tor_exit',
      RELAY: 'is_relay',
      HOSTING: 'is_hosting',
      CLOUD_PROVIDER: 'is_cloud_provider',
      ABUSER: 'is_abuser',
      ATTACKER: 'is_attacker',
      BOGON: 'is_bogon',
      ANONYMOUS: 'is_anonymous',
      THREAT: 'is_threat'
    };

    // 默认安全配置（高安全级别）
    this.defaultSecurityConfig = {
      blockVpn: true,
      blockProxy: true,
      blockTor: true,
      blockCloudProvider: true,
      blockAbuser: true,
      blockAttacker: true,
      blockAnonymous: true,
      blockThreat: true,
      allowHosting: false  // 是否允许IDC/数据中心IP
    };
  }

  /**
   * 执行安全过滤
   * @param {Object} ipInfo - IP信息对象
   * @param {Object} securityConfig - 安全配置（可选）
   * @returns {Object} { passed: boolean, reason: string, threats: array }
   */
  filter(ipInfo, securityConfig = null) {
    const config = securityConfig || this.defaultSecurityConfig;
    const security = ipInfo?.security || {};
    const detectedThreats = [];

    try {
      // 1. VPN检测
      if (config.blockVpn && security.is_vpn === true) {
        detectedThreats.push('VPN');
        logger.warn('Security Filter: VPN detected', {
          ip: ipInfo.ip,
          vpn: true
        });
      }

      // 2. 代理检测
      if (config.blockProxy && security.is_proxy === true) {
        detectedThreats.push('Proxy');
        logger.warn('Security Filter: Proxy detected', {
          ip: ipInfo.ip,
          proxy: true
        });
      }

      // 3. Tor网络检测
      if (config.blockTor) {
        if (security.is_tor === true) {
          detectedThreats.push('Tor Network');
        }
        if (security.is_tor_exit === true) {
          detectedThreats.push('Tor Exit Node');
        }
        if (security.is_relay === true) {
          detectedThreats.push('Tor Relay');
        }
      }

      // 4. 云服务商/IDC检测
      if (config.blockCloudProvider) {
        if (security.is_cloud_provider === true) {
          detectedThreats.push('Cloud Provider');
        }
        if (!config.allowHosting && security.is_hosting === true) {
          detectedThreats.push('Hosting/Datacenter');
        }
      }

      // 5. 滥用者检测
      if (config.blockAbuser && security.is_abuser === true) {
        detectedThreats.push('Known Abuser');
        logger.warn('Security Filter: Known abuser detected', {
          ip: ipInfo.ip,
          abuser: true
        });
      }

      // 6. 攻击者检测
      if (config.blockAttacker && security.is_attacker === true) {
        detectedThreats.push('Known Attacker');
        logger.warn('Security Filter: Known attacker detected', {
          ip: ipInfo.ip,
          attacker: true
        });
      }

      // 7. 匿名服务检测
      if (config.blockAnonymous && security.is_anonymous === true) {
        detectedThreats.push('Anonymous Service');
      }

      // 8. 威胁检测
      if (config.blockThreat && security.is_threat === true) {
        detectedThreats.push('Threat Actor');
        logger.warn('Security Filter: Threat actor detected', {
          ip: ipInfo.ip,
          threat: true
        });
      }

      // 9. Bogon IP检测（保留地址、私有地址等）
      if (security.is_bogon === true) {
        detectedThreats.push('Bogon IP');
        logger.warn('Security Filter: Bogon IP detected', {
          ip: ipInfo.ip,
          bogon: true
        });
      }

      // 判断是否通过
      const passed = detectedThreats.length === 0;

      if (!passed) {
        logger.info('Security Filter: Access blocked', {
          ip: ipInfo.ip,
          threats: detectedThreats,
          securityInfo: security
        });
      } else {
        logger.debug('Security Filter: Passed', {
          ip: ipInfo.ip
        });
      }

      return {
        passed,
        reason: passed ? 'Security check passed' : `Security threats detected: ${detectedThreats.join(', ')}`,
        threats: detectedThreats,
        details: {
          vpn: security.is_vpn,
          proxy: security.is_proxy,
          tor: security.is_tor,
          cloudProvider: security.is_cloud_provider,
          abuser: security.is_abuser,
          attacker: security.is_attacker,
          anonymous: security.is_anonymous,
          threat: security.is_threat
        }
      };

    } catch (error) {
      logger.error('Security Filter: Error during filtering', {
        error: error.message,
        ip: ipInfo?.ip
      });

      // 出错时采取保守策略：拒绝访问
      return {
        passed: false,
        reason: 'Security filter error',
        threats: ['FILTER_ERROR'],
        details: {}
      };
    }
  }

  /**
   * 根据配置对象检查多个安全属性
   * @param {Object} security - 安全信息对象
   * @param {Object} settings - 设置对象（包含各种安全开关）
   * @returns {boolean} 是否通过检查
   */
  checkSecurityAttributes(security, settings) {
    if (!security || typeof security !== 'object') {
      return false;
    }

    // 根据设置检查各个属性
    const checks = [
      { attr: 'is_abuser', enabled: settings.blockAbuser !== false },
      { attr: 'is_attacker', enabled: settings.blockAttacker !== false },
      { attr: 'is_bogon', enabled: settings.blockBogon !== false },
      { attr: 'is_cloud_provider', enabled: settings.blockCloudProvider !== false },
      { attr: 'is_proxy', enabled: settings.blockProxy !== false },
      { attr: 'is_relay', enabled: settings.blockRelay !== false },
      { attr: 'is_tor', enabled: settings.blockTor !== false },
      { attr: 'is_tor_exit', enabled: settings.blockTorExit !== false },
      { attr: 'is_vpn', enabled: settings.blockVpn !== false },
      { attr: 'is_anonymous', enabled: settings.blockAnonymous !== false },
      { attr: 'is_threat', enabled: settings.blockThreat !== false }
    ];

    for (const check of checks) {
      if (check.enabled && security[check.attr] === true) {
        logger.debug(`Security attribute check failed: ${check.attr}`, {
          attribute: check.attr,
          value: security[check.attr]
        });
        return false;
      }
    }

    return true;
  }

  /**
   * 获取安全威胁详情
   * @param {Object} security - 安全信息对象
   * @returns {Object} 威胁详情
   */
  getThreatDetails(security) {
    if (!security) return {};

    return {
      hasVpn: security.is_vpn === true,
      hasProxy: security.is_proxy === true,
      hasTor: security.is_tor === true || security.is_tor_exit === true,
      hasCloudProvider: security.is_cloud_provider === true,
      hasHosting: security.is_hosting === true,
      isAbuser: security.is_abuser === true,
      isAttacker: security.is_attacker === true,
      isAnonymous: security.is_anonymous === true,
      isThreat: security.is_threat === true,
      isBogon: security.is_bogon === true,
      riskScore: this.calculateRiskScore(security)
    };
  }

  /**
   * 计算风险评分（0-100）
   * @param {Object} security - 安全信息对象
   * @returns {number} 风险评分
   */
  calculateRiskScore(security) {
    let score = 0;

    if (security.is_attacker) score += 30;
    if (security.is_threat) score += 25;
    if (security.is_abuser) score += 20;
    if (security.is_tor || security.is_tor_exit) score += 15;
    if (security.is_vpn) score += 10;
    if (security.is_proxy) score += 10;
    if (security.is_anonymous) score += 8;
    if (security.is_cloud_provider) score += 5;
    if (security.is_bogon) score += 10;

    return Math.min(score, 100);
  }

  /**
   * 判断是否为高风险IP
   * @param {Object} security - 安全信息对象
   * @returns {boolean}
   */
  isHighRisk(security) {
    return this.calculateRiskScore(security) >= 50;
  }
}

module.exports = new SecurityFilter();
