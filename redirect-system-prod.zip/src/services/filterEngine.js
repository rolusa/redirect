/**
 * ============================================
 * 过滤引擎 - 完整修复版
 * ============================================
 * 功能：
 * 1. 整合所有过滤器
 * 2. 按顺序执行过滤检查
 * 3. 计算综合评分
 * 4. 做出最终决策
 * 5. 记录详细的过滤结果
 * ============================================
 */

const SecurityFilter = require('../filters/securityFilter');
const GeoFilter = require('../filters/geoFilter');
const DeviceFilter = require('../filters/deviceFilter');
const BehaviorFilter = require('../filters/behaviorFilter');
const FingerprintFilter = require('../filters/fingerprintFilter');
const Database = require('../database/mysql');
const logger = require('../utils/logger');
const { config } = require('../config');
const crypto = require('crypto');

/**
 * 过滤引擎类
 */
class FilterEngine {
  /**
   * 执行完整的过滤流程
   * @param {Object} ipInfo - IP信息对象
   * @param {Object} request - Express请求对象
   * @param {Object} tokenData - Token数据
   * @returns {Promise<Object>} - 过滤结果
   */
  static async filter(ipInfo, request, tokenData) {
    const startTime = Date.now();
    const ip = ipInfo.ip;

    try {
      // ============================================
      // 从数据库读取过滤器配置
      // ============================================
      const filterConfigs = await Database.query(
        'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
        ['filter_settings']
      );
      
      const dbFilters = {};
      filterConfigs.forEach(item => {
        // 确保正确转换布尔值
        dbFilters[item.key_name] = (item.value === 'true' || item.value === true);
      });
      
      // 构建过滤器设置，优先使用数据库配置
      const filterSettings = {
        security: dbFilters.hasOwnProperty('ENABLE_SECURITY_FILTER') ? dbFilters.ENABLE_SECURITY_FILTER : config.filters.security,
        geo: dbFilters.hasOwnProperty('ENABLE_GEO_FILTER') ? dbFilters.ENABLE_GEO_FILTER : config.filters.geo,
        language: dbFilters.hasOwnProperty('ENABLE_LANGUAGE_FILTER') ? dbFilters.ENABLE_LANGUAGE_FILTER : false,
        device: dbFilters.hasOwnProperty('ENABLE_DEVICE_FILTER') ? dbFilters.ENABLE_DEVICE_FILTER : config.filters.device,
        behavior: dbFilters.hasOwnProperty('ENABLE_BEHAVIOR_FILTER') ? dbFilters.ENABLE_BEHAVIOR_FILTER : config.filters.behavior,
        fingerprint: dbFilters.hasOwnProperty('ENABLE_FINGERPRINT_FILTER') ? dbFilters.ENABLE_FINGERPRINT_FILTER : config.filters.fingerprint,
      };
      
      console.log('📌 使用的过滤器配置:', filterSettings);
      // ============================================

      logger.info('开始过滤流程', {
        ip,
        country: ipInfo.country?.code,
        emailId: tokenData.eid,
        filters: filterSettings,
      });

      // 初始化结果对象
      const filterResult = {
        ip,
        tokenData,
        timestamp: new Date(),
        filters: {},
        decision: 'allow',
        reason: null,
        score: 100,
        processTime: 0,
      };

      // 1. 安全过滤
      if (filterSettings.security) {
        // 从数据库读取安全配置
        const securityConfigItems = await Database.query(
          'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
          ['security']
        );
        
        const securityConfig = {
          blockVpn: true,
          blockProxy: true,
          blockTor: true,
          blockCloudProvider: false,  // 默认不阻止云服务商
          blockAbuser: true,
          blockAttacker: true,
          blockAnonymous: true,
          blockThreat: true,
          allowHosting: false
        };
        
        securityConfigItems.forEach(item => {
          if (item.key_name === 'BLOCK_VPN') securityConfig.blockVpn = item.value === 'true';
          if (item.key_name === 'BLOCK_PROXY') securityConfig.blockProxy = item.value === 'true';
          if (item.key_name === 'BLOCK_TOR') securityConfig.blockTor = item.value === 'true';
          if (item.key_name === 'BLOCK_CLOUD_PROVIDER') securityConfig.blockCloudProvider = item.value === 'true';
        });
        
        console.log('📌 安全过滤配置:', securityConfig);
        
        const securityResult = SecurityFilter.filter(ipInfo, securityConfig);
        filterResult.filters.security = securityResult;

        if (!securityResult.passed) {
          filterResult.decision = 'reject';
          filterResult.reason = securityResult.reason;
          filterResult.score = securityResult.threats.length > 0 ? 0 : 30;
          return this._finalizeResult(filterResult, startTime, ipInfo, request);
        }

        // 更新分数
        filterResult.score = Math.min(filterResult.score, 100);
      }

      // 2. 地理位置过滤
      if (filterSettings.geo && filterResult.decision === 'allow') {
        // 从数据库读取地理位置配置
        const geoConfigItems = await Database.query(
          'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
          ['geo']
        );
        
        const geoConfig = {
          mode: 'whitelist',
          allowedCountries: [],
          blockedCountries: [],
          allowedContinents: [],
          blockedContinents: [],
        };
        
        geoConfigItems.forEach(item => {
          if (item.key_name === 'ALLOWED_COUNTRIES' && item.value) {
            geoConfig.allowedCountries = item.value.split(',').map(c => c.trim()).filter(c => c);
          } else if (item.key_name === 'BLOCKED_COUNTRIES' && item.value) {
            geoConfig.blockedCountries = item.value.split(',').map(c => c.trim()).filter(c => c);
          } else if (item.key_name === 'GEO_MODE' && item.value) {
            geoConfig.mode = item.value;
          }
        });
        
        console.log('📌 地理位置配置:', geoConfig);
        
        const geoResult = GeoFilter.filter(ipInfo, geoConfig);
        filterResult.filters.geo = geoResult;

        if (!geoResult.passed) {
          filterResult.decision = 'reject';
          filterResult.reason = geoResult.reason;
          filterResult.score = Math.min(filterResult.score, 30);
          return this._finalizeResult(filterResult, startTime, ipInfo, request);
        }
      }

      // 3. 语言过滤
      if (filterSettings.language && filterResult.decision === 'allow') {
        // 从数据库读取语言配置
        const languageConfigItems = await Database.query(
          'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
          ['language']
        );
        
        const languageConfig = {
          mode: 'whitelist',
          allowedLanguages: [],
          blockedLanguages: []
        };
        
        languageConfigItems.forEach(item => {
          if (item.key_name === 'ALLOWED_LANGUAGES' && item.value) {
            languageConfig.allowedLanguages = item.value.split(',').map(l => l.trim().toLowerCase()).filter(l => l);
          } else if (item.key_name === 'BLOCKED_LANGUAGES' && item.value) {
            languageConfig.blockedLanguages = item.value.split(',').map(l => l.trim().toLowerCase()).filter(l => l);
          } else if (item.key_name === 'LANGUAGE_MODE' && item.value) {
            languageConfig.mode = item.value;
          }
        });
        
        console.log('📌 语言过滤配置:', languageConfig);
        
        const languageResult = this._checkLanguage(request, languageConfig);
        filterResult.filters.language = languageResult;

        if (!languageResult.passed) {
          filterResult.decision = 'reject';
          filterResult.reason = languageResult.reason;
          filterResult.score = Math.min(filterResult.score, 30);
          return this._finalizeResult(filterResult, startTime, ipInfo, request);
        }
      }

      // 4. 设备指纹过滤
      if (filterSettings.device && filterResult.decision === 'allow') {
        const deviceResult = await DeviceFilter.filter(ipInfo, request);
        filterResult.filters.device = deviceResult;

        if (!deviceResult.passed) {
          filterResult.decision = 'reject';
          filterResult.reason = deviceResult.reason;
          filterResult.score = Math.min(filterResult.score, 40);
          return this._finalizeResult(filterResult, startTime, ipInfo, request);
        }
      }

      // 5. 行为分析过滤
      if (filterSettings.behavior && filterResult.decision === 'allow') {
        const behaviorResult = await BehaviorFilter.filter(ipInfo, request);
        filterResult.filters.behavior = behaviorResult;

        if (!behaviorResult.passed) {
          filterResult.decision = 'reject';
          filterResult.reason = behaviorResult.reason;
          filterResult.score = Math.min(filterResult.score, 20);
          return this._finalizeResult(filterResult, startTime, ipInfo, request);
        }
      }

      // 6. 高级指纹过滤（如果启用）
      if (filterSettings.fingerprint && filterResult.decision === 'allow') {
        // 从数据库读取高级指纹配置
        const fingerprintConfigItems = await Database.query(
          'SELECT key_name, value FROM config_items WHERE category = ? AND is_active = 1',
          ['fingerprint']
        );
        
        const fingerprintConfig = {
          threshold: 50,  // 可疑分数阈值，默认50
          checkAutomation: true,
          checkHeadless: true,
          checkBots: true,
        };
        
        fingerprintConfigItems.forEach(item => {
          if (item.key_name === 'FINGERPRINT_THRESHOLD' && item.value) {
            fingerprintConfig.threshold = parseInt(item.value, 10);
          } else if (item.key_name === 'CHECK_AUTOMATION') {
            fingerprintConfig.checkAutomation = item.value === 'true';
          } else if (item.key_name === 'CHECK_HEADLESS') {
            fingerprintConfig.checkHeadless = item.value === 'true';
          } else if (item.key_name === 'CHECK_BOTS') {
            fingerprintConfig.checkBots = item.value === 'true';
          }
        });
        
        console.log('📌 高级指纹配置:', fingerprintConfig);
        
        const fingerprintResult = FingerprintFilter.filter(ipInfo, request, fingerprintConfig);
        filterResult.filters.fingerprint = fingerprintResult;

        if (!fingerprintResult.passed) {
          filterResult.decision = 'reject';
          filterResult.reason = fingerprintResult.reason;
          filterResult.score = Math.min(filterResult.score, 10); // 重度可疑
          return this._finalizeResult(filterResult, startTime, ipInfo, request);
        }
      }

      // 7. 如果所有过滤器都通过，最终决定允许
      return this._finalizeResult(filterResult, startTime, ipInfo, request);

    } catch (error) {
      logger.error('过滤流程失败', {
        ip,
        error: error.message,
        stack: error.stack,
      });

      // 出错时的保守策略：拒绝访问
      return {
        ip,
        decision: 'reject',
        reason: 'Filter engine error',
        score: 0,
        error: error.message,
        processTime: Date.now() - startTime,
      };
    }
  }

  /**
   * 检查语言
   * @param {Object} request - Express请求对象
   * @param {Object} languageConfig - 语言配置
   * @returns {Object} - 检查结果
   * @private
   */
  static _checkLanguage(request, languageConfig) {
    const acceptLanguage = request.headers['accept-language'] || '';
    
    console.log('🔍 语言检查 - Accept-Language:', acceptLanguage);
    
    if (!acceptLanguage) {
      return {
        passed: false,
        reason: 'No accept-language header',
        detectedLanguage: null
      };
    }

    // 解析Accept-Language头
    // 格式如: "ja,en-US;q=0.9,en;q=0.8"
    const languages = acceptLanguage.split(',').map(lang => {
      const parts = lang.trim().split(';');
      return parts[0].toLowerCase();
    });

    console.log('🔍 解析后的语言列表:', languages);

    // 黑名单模式
    if (languageConfig.mode === 'blacklist') {
      if (languageConfig.blockedLanguages && languageConfig.blockedLanguages.length > 0) {
        const hasBlockedLang = languages.some(lang => 
          languageConfig.blockedLanguages.some(blocked => 
            lang.startsWith(blocked) || blocked.startsWith(lang)
          )
        );
        if (hasBlockedLang) {
          console.log('❌ 语言在黑名单中');
          return {
            passed: false,
            reason: 'Language in blacklist',
            detectedLanguage: languages[0]
          };
        }
      }
      console.log('✅ 语言不在黑名单');
      return {
        passed: true,
        reason: 'Language not in blacklist',
        detectedLanguage: languages[0]
      };
    }

    // 白名单模式（默认）
    if (languageConfig.allowedLanguages && languageConfig.allowedLanguages.length > 0) {
      const hasAllowedLang = languages.some(lang => 
        languageConfig.allowedLanguages.some(allowed => 
          lang.startsWith(allowed) || allowed.startsWith(lang)
        )
      );
      console.log('🔍 白名单检查结果:', { hasAllowedLang, languages, allowedLanguages: languageConfig.allowedLanguages });
      if (!hasAllowedLang) {
        console.log('❌ 语言不在白名单中');
        return {
          passed: false,
          reason: `Language not in whitelist (detected: ${languages[0]})`,
          detectedLanguage: languages[0]
        };
      }
      console.log('✅ 语言在白名单中');
      return {
        passed: true,
        reason: 'Language in whitelist',
        detectedLanguage: languages[0]
      };
    }

    // 未配置白名单时默认允许
    console.log('⚠️ 未配置语言白名单，默认允许');
    return {
      passed: true,
      reason: 'No language whitelist configured',
      detectedLanguage: languages[0]
    };
  }

  /**
   * 完成过滤结果并记录日志
   * @param {Object} filterResult - 过滤结果
   * @param {number} startTime - 开始时间
   * @param {Object} ipInfo - IP信息
   * @param {Object} request - 请求对象
   * @returns {Object} - 最终结果
   * @private
   */
  static async _finalizeResult(filterResult, startTime, ipInfo, request) {
    filterResult.processTime = Date.now() - startTime;

    // 决定重定向目标
    filterResult.redirectTo = await this._getRedirectURL(filterResult);

    // 记录日志
    logger.logFilter({
      ip: filterResult.ip,
      decision: filterResult.decision,
      reason: filterResult.reason,
      score: filterResult.score,
      processTime: filterResult.processTime,
      redirectTo: filterResult.redirectTo,
    });

    // 异步记录到数据库（不阻塞主流程）
    this._logToDatabase(filterResult, ipInfo, request).catch(err => {
      logger.error('记录数据库日志失败', { error: err.message });
    });

    // 异步更新IP信誉（不阻塞主流程）
    this._updateIPReputation(filterResult.ip, filterResult.decision === 'allow', ipInfo).catch(err => {
      logger.error('更新IP信誉失败', { error: err.message });
    });

    return filterResult;
  }

  /**
   * 根据过滤结果决定重定向URL
   * @param {Object} filterResult - 过滤结果
   * @returns {Promise<string>} - 重定向URL
   * @private
   */
  static async _getRedirectURL(filterResult) {
    console.log('\n========== 调试信息 ==========');
    console.log('filterResult:', JSON.stringify(filterResult, null, 2));
    
    try {
      if (filterResult.decision === 'allow') {
        // 允许访问 - 从数据库读取TARGET_URL
        const targetConfig = await Database.queryOne(
          'SELECT value FROM config_items WHERE key_name = ? AND category = ?',
          ['TARGET_URL', 'domains']
        );
        let targetURL = targetConfig ? targetConfig.value : config.domains.targetURL;

        // 支持多个目标URL（每行一个），随机选择一个
        if (targetURL && (targetURL.includes('\n') || targetURL.includes('\r'))) {
          const urls = targetURL.split(/[\r\n]+/)
            .map(url => url.trim())
            .filter(url => url.length > 0 && url.startsWith('http'));
          
          if (urls.length > 0) {
            // 随机选择一个URL
            const randomIndex = Math.floor(Math.random() * urls.length);
            targetURL = urls[randomIndex];
            console.log(`🎲 从${urls.length}个URL中随机选择第${randomIndex + 1}个: ${targetURL}`);
          }
        }
        
        console.log('✅ 决定：允许访问');
        console.log('返回URL:', targetURL);
        console.log('============================\n');
        return targetURL;
      }

      // 根据分数决定重定向到哪个伪装URL
      let fallbackKey;
      if (filterResult.score >= 30) {
        fallbackKey = 'FALLBACK_URL_LIGHT';
        console.log('⚠️ 决定：轻度可疑 (score >= 30)');
      } else if (filterResult.score >= 10) {
        fallbackKey = 'FALLBACK_URL_MEDIUM';
        console.log('⚠️ 决定：中度可疑 (score >= 10)');
      } else {
        fallbackKey = 'FALLBACK_URL_HEAVY';
        console.log('❌ 决定：重度恶意 (score < 10)');
      }
      
      // 从数据库读取Fallback URL
      const fallbackConfig = await Database.queryOne(
        'SELECT value FROM config_items WHERE key_name = ? AND category = ?',
        [fallbackKey, 'domains']
      );
      
      let redirectURL;
      if (fallbackConfig && fallbackConfig.value) {
        redirectURL = fallbackConfig.value;
      } else {
        // 从config中读取默认值
        if (fallbackKey === 'FALLBACK_URL_LIGHT') {
          redirectURL = config.domains.fallback.light;
        } else if (fallbackKey === 'FALLBACK_URL_MEDIUM') {
          redirectURL = config.domains.fallback.medium;
        } else {
          redirectURL = config.domains.fallback.heavy;
        }
      }
      
      console.log('返回URL:', redirectURL);
      console.log('============================\n');
      return redirectURL;
      
    } catch (error) {
      logger.error('获取重定向URL失败', { error: error.message });
      console.log('============================\n');
      if (filterResult.decision === 'allow') {
        return config.domains.targetURL;
      } else {
        return config.domains.fallback.medium;
      }
    }
  }

  /**
   * 记录到数据库
   * @param {Object} filterResult - 过滤结果
   * @param {Object} ipInfo - IP信息
   * @param {Object} request - 请求对象
   * @returns {Promise<void>}
   * @private
   */
  static async _logToDatabase(filterResult, ipInfo, request) {
    try {
      // 解析User-Agent
      const UAParser = require('ua-parser-js');
      const uaParser = new UAParser(request.headers['user-agent']);
      const ua = uaParser.getResult();

      // 生成Token哈希（不存储完整Token）
      // ✅ 修复：使用 request.shortToken（由tokenValidator设置）或 request.params.token
      const token = request.shortToken || request.params.token || '';
      const tokenHash = crypto
        .createHash('sha256')
        .update(token)
        .digest('hex')
        .substring(0, 64);

      // 准备日志数据
      const logData = {
        token_hash: tokenHash,
        email_id: filterResult.tokenData?.eid || null,

        // IP信息
        ip: ipInfo.ip,
        country_code: ipInfo.country?.code || null,
        country_name: ipInfo.country?.name || null,
        region: ipInfo.location?.region || null,
        city: ipInfo.location?.city || null,

        // 设备信息
        user_agent: request.headers['user-agent'] || null,
        browser: ua.browser.name || null,
        browser_version: ua.browser.version || null,
        os: ua.os.name || null,
        os_version: ua.os.version || null,
        device_type: ua.device.type || 'desktop',
        device_brand: ua.device.vendor || null,

        // 安全信息
        is_vpn: ipInfo.security?.isVPN || false,
        is_proxy: ipInfo.security?.isProxy || false,
        is_tor: ipInfo.security?.isTor || false,
        is_threat: ipInfo.security?.isThreat || false,

        // 过滤结果
        filter_decision: filterResult.decision,
        filter_results: JSON.stringify(filterResult.filters),
        rejection_reason: filterResult.reason || null,

        // 重定向信息
        redirect_to: filterResult.redirectTo,
        redirect_domain: request.hostname || null,

        // 性能信息
        process_time_ms: filterResult.processTime,
      };

      // 插入数据库
      await Database.logAccess(logData);

    } catch (error) {
      logger.error('记录数据库失败', {
        error: error.message,
        ip: ipInfo.ip,
      });
    }
  }

  /**
   * 更新IP信誉
   * @param {string} ip - IP地址
   * @param {boolean} success - 是否通过验证
   * @param {Object} ipInfo - IP信息
   * @returns {Promise<void>}
   * @private
   */
  static async _updateIPReputation(ip, success, ipInfo) {
    try {
      await Database.updateIPReputation(ip, {
        success,
        countryCode: ipInfo.country?.code || null,
      });
    } catch (error) {
      logger.error('更新IP信誉失败', {
        error: error.message,
        ip,
      });
    }
  }

  /**
   * 获取过滤统计信息
   * @returns {Promise<Object>}
   */
  static async getStats() {
    try {
      const stats = await Database.getStats();
      return stats;
    } catch (error) {
      logger.error('获取过滤统计失败', { error: error.message });
      return null;
    }
  }

  /**
   * 测试过滤器（用于开发/调试）
   * @param {Object} testData - 测试数据
   * @returns {Promise<Object>}
   */
  static async test(testData) {
    const mockRequest = {
      headers: {
        'user-agent': testData.userAgent || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'accept-language': testData.language || 'en-US,en;q=0.9',
        'referer': testData.referer || null,
      },
      ip: testData.ip || '8.8.8.8',
      hostname: testData.hostname || 'test.com',
      query: {
        token: testData.token || 'test-token',
      },
    };

    const mockIPInfo = testData.ipInfo || {
      ip: mockRequest.ip,
      country: { code: 'US', name: 'United States' },
      security: {
        isVPN: testData.isVPN || false,
        isProxy: testData.isProxy || false,
        isTor: testData.isTor || false,
      },
    };

    const mockTokenData = testData.tokenData || {
      eid: 'test-email-id',
    };

    return await this.filter(mockIPInfo, mockRequest, mockTokenData);
  }
}

module.exports = FilterEngine;
