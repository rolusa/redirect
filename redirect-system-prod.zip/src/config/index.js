/**
 * ============================================
 * 配置管理模块
 * ============================================
 * 功能：
 * 1. 加载和验证环境变量
 * 2. 提供统一的配置访问接口
 * 3. 设置默认值
 * ============================================
 */

require('dotenv').config();

/**
 * 配置对象
 * 从环境变量中读取配置，并提供默认值
 */
const config = {
  // -------------------- 服务器配置 --------------------
  server: {
    env: process.env.NODE_ENV || 'development',
    port: parseInt(process.env.PORT) || 3000,
    host: process.env.HOST || 'localhost',
  },

  // -------------------- 数据库配置 --------------------
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT) || 3306,
    name: process.env.DB_NAME || 'redirect_system_dev',
    user: process.env.DB_USER || 'redirect_user',
    password: process.env.DB_PASSWORD || '',
    connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT) || 10,
    queueLimit: parseInt(process.env.DB_QUEUE_LIMIT) || 0,
  },

  // -------------------- Redis配置 --------------------
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT) || 6379,
    password: process.env.REDIS_PASSWORD || '',
    db: parseInt(process.env.REDIS_DB) || 0,
    keyPrefix: process.env.REDIS_KEY_PREFIX || 'redirect:',
  },

  // -------------------- 缓存配置 --------------------
  cache: {
    ipInfoTTL: parseInt(process.env.CACHE_IP_INFO_TTL) || 1800, // 30分钟
    tokenTTL: parseInt(process.env.CACHE_TOKEN_TTL) || 300, // 5分钟
  },

  // -------------------- ipregistry API --------------------
  ipregistry: {
    apiKey: process.env.IPREGISTRY_API_KEY || '',
    timeout: parseInt(process.env.IPREGISTRY_TIMEOUT) || 5000,
    baseURL: 'https://api.ipregistry.co',
  },

  // -------------------- Token配置 --------------------
  token: {
    secretKey: process.env.TOKEN_SECRET_KEY || '',
    expiryHours: parseInt(process.env.TOKEN_EXPIRY_HOURS) || 48,
    maxUses: parseInt(process.env.TOKEN_MAX_USES) || 3,
  },

  // -------------------- 域名配置 --------------------
  domains: {
    targetURL: process.env.TARGET_URL || 'https://a.com',
    redirectDomains: (process.env.REDIRECT_DOMAINS || 'b.com,c.com,d.com,e.com,f.com').split(','),
    fallback: {
      light: process.env.FALLBACK_URL_LIGHT || 'https://example.com/404',
      medium: process.env.FALLBACK_URL_MEDIUM || 'https://example.com/expired',
      heavy: process.env.FALLBACK_URL_HEAVY || 'http://127.0.0.1',
    },
  },

  // -------------------- 日志配置 --------------------
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    dir: process.env.LOG_DIR || './logs',
    maxSize: process.env.LOG_MAX_SIZE || '20m',
    maxFiles: process.env.LOG_MAX_FILES || '14d',
  },

  // -------------------- 过滤器开关 --------------------
  filters: {
    token: process.env.ENABLE_TOKEN_FILTER !== 'false', // 默认启用
    security: process.env.ENABLE_SECURITY_FILTER !== 'false',
    geo: process.env.ENABLE_GEO_FILTER !== 'false',
    language: process.env.ENABLE_LANGUAGE_FILTER !== 'false',
    device: process.env.ENABLE_DEVICE_FILTER !== 'false',
    behavior: process.env.ENABLE_BEHAVIOR_FILTER !== 'false',
    fingerprint: process.env.ENABLE_FINGERPRINT_FILTER === 'true', // 默认禁用
  },

  // -------------------- 地理位置过滤配置 --------------------
  geo: {
    allowedCountries: process.env.ALLOWED_COUNTRIES
      ? process.env.ALLOWED_COUNTRIES.split(',').map(c => c.trim().toUpperCase())
      : [],
    mode: process.env.ALLOWED_COUNTRIES ? 'whitelist' : 'all', // 如果配置了国家，使用白名单模式
  },

  // -------------------- 语言过滤配置 --------------------
  language: {
    allowedLanguages: process.env.ALLOWED_LANGUAGES
      ? process.env.ALLOWED_LANGUAGES.split(',').map(l => l.trim().toLowerCase())
      : [],
    mode: process.env.ALLOWED_LANGUAGES ? 'whitelist' : 'all',
  },

  // -------------------- 访问频率限制配置 --------------------
  rateLimit: {
    '1min': parseRateLimit(process.env.RATE_LIMIT_1MIN, 60, 3),
    '1hour': parseRateLimit(process.env.RATE_LIMIT_1HOUR, 3600, 10),
    '24hour': parseRateLimit(process.env.RATE_LIMIT_24HOUR, 86400, 20),
  },

  // -------------------- 监控配置 --------------------
  monitoring: {
    metricsEnabled: process.env.METRICS_ENABLED === 'true',
    metricsPort: parseInt(process.env.METRICS_PORT) || 9090,
  },

  // -------------------- 开发调试 --------------------
  debug: {
    enabled: process.env.DEBUG_MODE === 'true',
    verbose: process.env.VERBOSE_LOGGING === 'true',
  },
};

/**
 * 解析频率限制配置
 * @param {string} value - 格式: "时间窗口秒数_最大次数"，如 "60_3"
 * @param {number} defaultWindow - 默认时间窗口（秒）
 * @param {number} defaultMax - 默认最大次数
 * @returns {Object} { window: 时间窗口, max: 最大次数 }
 */
function parseRateLimit(value, defaultWindow, defaultMax) {
  if (!value) {
    return { window: defaultWindow, max: defaultMax };
  }

  const parts = value.split('_');
  if (parts.length !== 2) {
    return { window: defaultWindow, max: defaultMax };
  }

  return {
    window: parseInt(parts[0]) || defaultWindow,
    max: parseInt(parts[1]) || defaultMax,
  };
}

/**
 * 验证必需的配置项
 * 如果缺少必需配置，抛出错误
 */
function validateConfig() {
  const errors = [];

  // 检查必需的配置
  if (!config.token.secretKey || config.token.secretKey.length < 32) {
    errors.push('TOKEN_SECRET_KEY 未设置或长度小于32字符');
  }

  if (!config.ipregistry.apiKey) {
    errors.push('IPREGISTRY_API_KEY 未设置');
  }

  if (!config.database.password && config.server.env === 'production') {
    errors.push('生产环境必须设置 DB_PASSWORD');
  }

  // 如果有错误，抛出异常
  if (errors.length > 0) {
    throw new Error(
      '配置验证失败:\n' + errors.map(e => `  - ${e}`).join('\n')
    );
  }
}

/**
 * 打印配置摘要（不包含敏感信息）
 */
function printConfigSummary() {
  console.log('\n========================================');
  console.log('配置加载成功');
  console.log('========================================');
  console.log(`环境: ${config.server.env}`);
  console.log(`端口: ${config.server.port}`);
  console.log(`数据库: ${config.database.host}:${config.database.port}/${config.database.name}`);
  console.log(`Redis: ${config.redis.host}:${config.redis.port}`);
  console.log(`目标URL: ${config.domains.targetURL}`);
  console.log(`重定向域名数量: ${config.domains.redirectDomains.length}`);
  console.log(`启用的过滤器:`);
  Object.entries(config.filters).forEach(([name, enabled]) => {
    console.log(`  - ${name}: ${enabled ? '✓' : '✗'}`);
  });
  console.log('========================================\n');
}

// 导出配置对象和验证函数
module.exports = {
  config,
  validateConfig,
  printConfigSummary,
};
