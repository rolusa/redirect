/**
 * ============================================
 * 管理后台数据库表结构
 * ============================================
 */

const logger = require('../utils/logger');

/**
 * 管理后台相关表定义
 */
const adminTables = {
  // 管理员用户表
  admin_users: `
    CREATE TABLE IF NOT EXISTS admin_users (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(50) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      email VARCHAR(100),
      role VARCHAR(20) DEFAULT 'super_admin',
      is_active BOOLEAN DEFAULT TRUE,
      last_login_at TIMESTAMP NULL,
      last_login_ip VARCHAR(45),
      login_attempts INT DEFAULT 0,
      locked_until TIMESTAMP NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      
      INDEX idx_username (username),
      INDEX idx_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,

  // 配置项表
  config_items: `
    CREATE TABLE IF NOT EXISTS config_items (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      category VARCHAR(50) NOT NULL COMMENT '配置分类',
      key_name VARCHAR(100) NOT NULL COMMENT '配置键名',
      value TEXT COMMENT '配置值',
      data_type VARCHAR(20) DEFAULT 'string' COMMENT '数据类型: string,number,boolean,json',
      description TEXT COMMENT '配置说明',
      is_sensitive BOOLEAN DEFAULT FALSE COMMENT '是否敏感信息',
      is_active BOOLEAN DEFAULT TRUE,
      updated_by VARCHAR(50),
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      
      UNIQUE KEY unique_config (category, key_name),
      INDEX idx_category (category)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,

  // 配置历史表
  config_history: `
    CREATE TABLE IF NOT EXISTS config_history (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      config_id BIGINT UNSIGNED NOT NULL,
      category VARCHAR(50) NOT NULL,
      key_name VARCHAR(100) NOT NULL,
      old_value TEXT,
      new_value TEXT,
      changed_by VARCHAR(50),
      change_reason VARCHAR(255),
      changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      
      INDEX idx_config_id (config_id),
      INDEX idx_changed_at (changed_at),
      INDEX idx_changed_by (changed_by)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,

  // 操作日志表
  admin_logs: `
    CREATE TABLE IF NOT EXISTS admin_logs (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(50) NOT NULL,
      action VARCHAR(100) NOT NULL COMMENT '操作类型',
      resource VARCHAR(100) COMMENT '操作资源',
      details TEXT COMMENT '详细信息',
      ip_address VARCHAR(45),
      user_agent TEXT,
      status VARCHAR(20) DEFAULT 'success' COMMENT 'success,failed',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      
      INDEX idx_username (username),
      INDEX idx_action (action),
      INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,

  // 系统配置快照表（用于备份恢复）
  config_snapshots: `
    CREATE TABLE IF NOT EXISTS config_snapshots (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL COMMENT '快照名称',
      description TEXT COMMENT '快照描述',
      config_data LONGTEXT NOT NULL COMMENT '配置JSON数据',
      created_by VARCHAR(50),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      
      INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `
};

/**
 * 初始化管理后台数据库表
 * @param {Object} connection - MySQL连接对象
 * @returns {Promise<void>}
 */
async function initializeAdminTables(connection) {
  try {
    logger.info('开始初始化管理后台数据库表...');

    for (const [tableName, sql] of Object.entries(adminTables)) {
      try {
        await connection.query(sql);
        logger.info(`管理表 ${tableName} 创建成功`);
      } catch (error) {
        logger.error(`管理表 ${tableName} 创建失败`, {
          error: error.message,
        });
        throw error;
      }
    }

    logger.info('管理后台数据库表初始化完成');
  } catch (error) {
    logger.error('管理后台数据库初始化失败', { error: error.message });
    throw error;
  }
}

/**
 * 插入默认管理员账户
 * @param {Object} connection - MySQL连接对象
 * @returns {Promise<void>}
 */
async function insertDefaultAdmin(connection) {
  try {
    const bcrypt = require('bcryptjs');
    
    // 检查是否已存在管理员
    const [existing] = await connection.query(
      'SELECT id FROM admin_users WHERE username = ?',
      ['admin']
    );

    if (existing.length === 0) {
      // 创建默认管理员
      const passwordHash = await bcrypt.hash('admin123', 10);
      
      await connection.query(
        `INSERT INTO admin_users (username, password_hash, email, role) 
         VALUES (?, ?, ?, ?)`,
        ['admin', passwordHash, 'admin@system.local', 'super_admin']
      );

      logger.info('默认管理员账户创建成功 (admin/admin123)');
      logger.warn('⚠️ 请立即登录后台修改默认密码！');
    } else {
      logger.info('管理员账户已存在，跳过创建');
    }
  } catch (error) {
    logger.error('创建默认管理员失败', { error: error.message });
    // 不抛出错误，允许继续运行
  }
}

/**
 * 初始化默认配置到数据库
 * @param {Object} connection - MySQL连接对象
 * @returns {Promise<void>}
 */
async function initializeDefaultConfig(connection) {
  try {
    // 检查是否已有配置
    const [existing] = await connection.query(
      'SELECT COUNT(*) as count FROM config_items'
    );

    if (existing[0].count === 0) {
      logger.info('初始化默认配置到数据库...');
      
      const { config } = require('../config');
      const configs = [
        // 服务器配置
        { category: 'server', key_name: 'NODE_ENV', value: config.server.env, data_type: 'string', description: '运行环境' },
        { category: 'server', key_name: 'PORT', value: String(config.server.port), data_type: 'number', description: '服务端口' },
        { category: 'server', key_name: 'HOST', value: config.server.host, data_type: 'string', description: '监听地址' },
        
        // 数据库配置
        { category: 'database', key_name: 'DB_HOST', value: config.database.host, data_type: 'string', description: 'MySQL主机' },
        { category: 'database', key_name: 'DB_PORT', value: String(config.database.port), data_type: 'number', description: 'MySQL端口' },
        { category: 'database', key_name: 'DB_NAME', value: config.database.name, data_type: 'string', description: '数据库名' },
        { category: 'database', key_name: 'DB_USER', value: config.database.user, data_type: 'string', description: '数据库用户' },
        { category: 'database', key_name: 'DB_PASSWORD', value: config.database.password, data_type: 'string', description: '数据库密码', is_sensitive: true },
        
        // Redis配置
        { category: 'redis', key_name: 'REDIS_HOST', value: config.redis.host, data_type: 'string', description: 'Redis主机' },
        { category: 'redis', key_name: 'REDIS_PORT', value: String(config.redis.port), data_type: 'number', description: 'Redis端口' },
        { category: 'redis', key_name: 'REDIS_PASSWORD', value: config.redis.password, data_type: 'string', description: 'Redis密码', is_sensitive: true },
        { category: 'redis', key_name: 'REDIS_DB', value: String(config.redis.db), data_type: 'number', description: 'Redis数据库编号' },
        
        // Token配置
        { category: 'token', key_name: 'TOKEN_SECRET_KEY', value: config.token.secretKey, data_type: 'string', description: 'Token加密密钥', is_sensitive: true },
        { category: 'token', key_name: 'TOKEN_EXPIRY_HOURS', value: String(config.token.expiryHours), data_type: 'number', description: 'Token有效期(小时)' },
        { category: 'token', key_name: 'TOKEN_MAX_USES', value: String(config.token.maxUses), data_type: 'number', description: 'Token最大使用次数' },
        
        // 域名配置
        { category: 'domains', key_name: 'TARGET_URL', value: config.domains.targetURL, data_type: 'string', description: '目标URL' },
        { category: 'domains', key_name: 'FALLBACK_URL_LIGHT', value: config.domains.fallback.light, data_type: 'string', description: '轻度拒绝URL' },
        { category: 'domains', key_name: 'FALLBACK_URL_MEDIUM', value: config.domains.fallback.medium, data_type: 'string', description: '中度拒绝URL' },
        { category: 'domains', key_name: 'FALLBACK_URL_HEAVY', value: config.domains.fallback.heavy, data_type: 'string', description: '重度拒绝URL' },
        
        // 过滤器配置
        { category: 'filters', key_name: 'ENABLE_TOKEN_FILTER', value: String(config.filters.token), data_type: 'boolean', description: 'Token验证过滤器' },
        { category: 'filters', key_name: 'ENABLE_SECURITY_FILTER', value: String(config.filters.security), data_type: 'boolean', description: '安全检测过滤器' },
        { category: 'filters', key_name: 'ENABLE_GEO_FILTER', value: String(config.filters.geo), data_type: 'boolean', description: '地理位置过滤器' },
        { category: 'filters', key_name: 'ENABLE_LANGUAGE_FILTER', value: String(config.filters.language), data_type: 'boolean', description: '语言过滤器' },
        { category: 'filters', key_name: 'ENABLE_DEVICE_FILTER', value: String(config.filters.device), data_type: 'boolean', description: '设备指纹过滤器' },
        { category: 'filters', key_name: 'ENABLE_BEHAVIOR_FILTER', value: String(config.filters.behavior), data_type: 'boolean', description: '行为分析过滤器' },
        { category: 'filters', key_name: 'ENABLE_FINGERPRINT_FILTER', value: String(config.filters.fingerprint), data_type: 'boolean', description: '高级指纹过滤器' },
        
        // 地理位置配置
        { category: 'geo', key_name: 'ALLOWED_COUNTRIES', value: config.geo.allowedCountries.join(','), data_type: 'string', description: '允许的国家列表' },
        
        // API配置
        { category: 'api', key_name: 'IPREGISTRY_API_KEY', value: config.ipregistry.apiKey, data_type: 'string', description: 'ipregistry API密钥', is_sensitive: true },
      ];

      for (const cfg of configs) {
        await connection.query(
          `INSERT INTO config_items (category, key_name, value, data_type, description, is_sensitive) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [cfg.category, cfg.key_name, cfg.value, cfg.data_type, cfg.description, cfg.is_sensitive || false]
        );
      }

      logger.info('默认配置初始化完成');
    } else {
      logger.info('配置已存在，跳过初始化');
    }
  } catch (error) {
    logger.error('初始化默认配置失败', { error: error.message });
    // 不抛出错误，允许继续运行
  }
}

module.exports = {
  adminTables,
  initializeAdminTables,
  insertDefaultAdmin,
  initializeDefaultConfig,
};
