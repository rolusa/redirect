@echo off
chcp 65001 >nul
echo ==================================
echo 反检测重定向系统 - 快速启动
echo ==================================
echo.

REM 检查是否安装了依赖
if not exist "node_modules\" (
    echo 📦 首次运行，正在安装依赖...
    call npm install
    echo.
)

REM 检查.env文件
if not exist ".env" (
    echo ⚠️  警告：未找到.env文件
    echo 请根据 .env.example 创建 .env 文件并配置数据库信息
    echo.
    set /p continue="是否继续？(y/n): "
    if /i not "%continue%"=="y" exit /b
)

echo 🚀 启动选项：
echo 1. 启动主服务 (端口3000^)
echo 2. 启动管理后台 (端口3001^)
echo 3. 同时启动两个服务
echo.
set /p choice="请选择 (1-3): "

if "%choice%"=="1" (
    echo 🚀 启动主服务...
    npm start
) else if "%choice%"=="2" (
    echo 🚀 启动管理后台...
    npm run admin
) else if "%choice%"=="3" (
    echo 🚀 同时启动主服务和管理后台...
    npm run dev:all
) else (
    echo ❌ 无效的选择
    pause
    exit /b
)
