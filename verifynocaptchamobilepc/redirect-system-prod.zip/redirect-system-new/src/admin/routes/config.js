/**
 * ============================================
 * 配置管理API路由
 * ============================================
 */

const express = require('express');
const router = express.Router();
const Database = require('../../database/mysql');
const Redis = require('../../database/redis');
const logger = require('../../utils/logger');
const { asyncHandler } = require('../middleware/errorHandler');
const fs = require('fs').promises;
const path = require('path');

/**
 * GET /api/config/all
 * 获取所有配置
 */
router.get('/all', asyncHandler(async (req, res) => {
  const { showSensitive } = req.query;
  
  const configs = await Database.query(
    'SELECT id, category, key_name, value, data_type, description, is_sensitive, updated_at FROM config_items WHERE is_active = 1 ORDER BY category, key_name'
  );

  // 按分类组织配置
  const grouped = configs.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    
    // 如果不要求显示敏感信息，则脱敏
    if (showSensitive !== 'true' && item.is_sensitive && item.value) {
      item.value = '••••••••';
    }
    
    acc[item.category].push(item);
    return acc;
  }, {});

  res.json({
    success: true,
    data: grouped
  });
}));

/**
 * GET /api/config/:category
 * 获取某个分类的配置
 */
router.get('/:category', asyncHandler(async (req, res) => {
  const { category } = req.params;
  const { showSensitive } = req.query;

  const configs = await Database.query(
    'SELECT * FROM config_items WHERE category = ? AND is_active = 1 ORDER BY key_name',
    [category]
  );

  // 如果不要求显示敏感信息，则脱敏
  if (showSensitive !== 'true') {
    configs.forEach(item => {
      if (item.is_sensitive && item.value) {
        item.value = '••••••••';
      }
    });
  }

  res.json({
    success: true,
    data: configs
  });
}));

/**
 * PUT /api/config/:category/:key
 * 更新单个配置项
 */
router.put('/:category/:key', asyncHandler(async (req, res) => {
  const { category, key } = req.params;
  const { value } = req.body;
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  if (value === undefined) {
    return res.status(400).json({
      success: false,
      message: '配置值不能为空'
    });
  }

  // 查询当前配置
  const config = await Database.queryOne(
    'SELECT * FROM config_items WHERE category = ? AND key_name = ?',
    [category, key]
  );

  if (!config) {
    return res.status(404).json({
      success: false,
      message: '配置项不存在'
    });
  }

  const oldValue = config.value;

  // 更新配置
  await Database.update('config_items', {
    value: String(value),
    updated_by: username,
    updated_at: new Date()
  }, { id: config.id });

  // 尝试记录历史（如果表结构不匹配则跳过）
  try {
    await Database.insert('config_history', {
      config_id: config.id,
      category,
      key_name: key,
      old_value: oldValue,
      new_value: String(value),
      changed_by: username
    });
  } catch (historyError) {
    logger.warn('记录配置历史失败（已跳过）', { error: historyError.message });
  }

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_update',
    resource: `${category}.${key}`,
    details: `修改配置: ${key}`,
    ip_address: ip,
    status: 'success'
  });

  logger.info('配置已更新', { category, key, username });

  res.json({
    success: true,
    message: '配置更新成功'
  });
}));

/**
 * POST /api/config/batch
 * 批量更新配置
 */
router.post('/batch', asyncHandler(async (req, res) => {
  const { configs } = req.body;
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  if (!Array.isArray(configs) || configs.length === 0) {
    return res.status(400).json({
      success: false,
      message: '配置列表不能为空'
    });
  }

  let updatedCount = 0;

  for (const item of configs) {
    const { category, key, value } = item;

    // 查询配置
    const config = await Database.queryOne(
      'SELECT * FROM config_items WHERE category = ? AND key_name = ?',
      [category, key]
    );

    if (config) {
      const oldValue = config.value;

      // 更新配置
      await Database.update('config_items', {
        value: String(value),
        updated_by: username,
        updated_at: new Date()
      }, { id: config.id });

      // 尝试记录历史（如果表结构不匹配则跳过）
      try {
        await Database.insert('config_history', {
          config_id: config.id,
          category,
          key_name: key,
          old_value: oldValue,
          new_value: String(value),
          changed_by: username
        });
      } catch (historyError) {
        logger.warn('记录配置历史失败（已跳过）', { error: historyError.message });
      }

      updatedCount++;
    }
  }

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_batch_update',
    details: `批量更新${updatedCount}个配置项`,
    ip_address: ip,
    status: 'success'
  });

  logger.info('批量配置已更新', { count: updatedCount, username });

  res.json({
    success: true,
    message: `成功更新${updatedCount}个配置项`
  });
}));

/**
 * POST /api/config/test-database
 * 测试数据库连接
 */
router.post('/test-database', asyncHandler(async (req, res) => {
  const { host, port, database, user, password } = req.body;

  try {
    const mysql = require('mysql2/promise');
    
    const connection = await mysql.createConnection({
      host,
      port: parseInt(port),
      database,
      user,
      password,
      connectTimeout: 5000
    });

    const [rows] = await connection.query('SELECT VERSION() as version');
    const version = rows[0].version;

    await connection.end();

    res.json({
      success: true,
      message: '数据库连接成功',
      data: {
        version,
        status: 'connected'
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: '数据库连接失败',
      error: error.message
    });
  }
}));

/**
 * POST /api/config/test-redis
 * 测试Redis连接
 */
router.post('/test-redis', asyncHandler(async (req, res) => {
  const { host, port, password, db } = req.body;

  try {
    const redis = require('redis');
    
    const clientConfig = {
      socket: {
        host: host || '127.0.0.1',
        port: parseInt(port) || 6379,
        connectTimeout: 5000
      }
    };

    if (password) {
      clientConfig.password = password;
    }

    if (db !== undefined) {
      clientConfig.database = parseInt(db);
    }

    const testClient = redis.createClient(clientConfig);

    await testClient.connect();

    const info = await testClient.info('server');
    const version = info.match(/redis_version:([^\r\n]+)/)?.[1] || 'unknown';

    await testClient.quit();

    res.json({
      success: true,
      message: 'Redis连接成功',
      data: {
        version,
        status: 'connected'
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Redis连接失败',
      error: error.message
    });
  }
}));

/**
 * POST /api/config/reload
 * 热重载配置（重启主服务）
 */
router.post('/reload', asyncHandler(async (req, res) => {
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_reload',
    details: '触发配置热重载',
    ip_address: ip,
    status: 'success'
  });

  logger.info('配置热重载请求', { username });

  // 发送重载信号（这里简单返回，实际需要PM2或其他工具配合）
  res.json({
    success: true,
    message: '配置重载请求已发送，系统将在几秒内生效',
    note: '如使用PM2，请执行: pm2 restart redirect-system'
  });

  // 可以在这里触发主服务重载
  // 例如: 向主进程发送信号，或通过Redis发布消息
}));

/**
 * GET /api/config/history
 * 获取配置修改历史
 */
router.get('/history/:category?/:key?', asyncHandler(async (req, res) => {
  const { category, key } = req.params;
  const { limit = 50, offset = 0 } = req.query;

  let sql = `
    SELECT ch.*, ci.description
    FROM config_history ch
    LEFT JOIN config_items ci ON ch.config_id = ci.id
    WHERE 1=1
  `;
  const params = [];

  if (category) {
    sql += ' AND ch.category = ?';
    params.push(category);
  }

  if (key) {
    sql += ' AND ch.key_name = ?';
    params.push(key);
  }

  sql += ' ORDER BY ch.changed_at DESC LIMIT ? OFFSET ?';
  params.push(parseInt(limit), parseInt(offset));

  const history = await Database.query(sql, params);

  res.json({
    success: true,
    data: history
  });
}));

/**
 * POST /api/config/export
 * 导出配置
 */
router.post('/export', asyncHandler(async (req, res) => {
  const { username } = req.user;

  const configs = await Database.query(
    'SELECT category, key_name, value, data_type, description FROM config_items WHERE is_active = 1'
  );

  const exportData = {
    exportedAt: new Date().toISOString(),
    exportedBy: username,
    version: '1.0',
    configs
  };

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_export',
    details: `导出${configs.length}个配置项`,
    ip_address: req.ip,
    status: 'success'
  });

  res.json({
    success: true,
    data: exportData
  });
}));

/**
 * POST /api/config/import
 * 导入配置
 */
router.post('/import', asyncHandler(async (req, res) => {
  const { configs } = req.body;
  const { username } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  if (!Array.isArray(configs)) {
    return res.status(400).json({
      success: false,
      message: '配置格式错误'
    });
  }

  let importedCount = 0;

  for (const item of configs) {
    const { category, key_name, value } = item;

    const existing = await Database.queryOne(
      'SELECT id FROM config_items WHERE category = ? AND key_name = ?',
      [category, key_name]
    );

    if (existing) {
      await Database.update('config_items', {
        value,
        updated_by: username,
        updated_at: new Date()
      }, { id: existing.id });
      importedCount++;
    }
  }

  // 记录操作日志
  await Database.insert('admin_logs', {
    username,
    action: 'config_import',
    details: `导入${importedCount}个配置项`,
    ip_address: ip,
    status: 'success'
  });

  res.json({
    success: true,
    message: `成功导入${importedCount}个配置项`
  });
}));

module.exports = router;
