-- ============================================
-- Token批量生成功能 - 数据库表结构
-- ============================================
-- 创建时间: 2025-11-17
-- 说明: 用于批量生成Token链接的数据表
-- ============================================

-- 批次表：记录每次批量生成的基本信息
CREATE TABLE IF NOT EXISTS `token_batches` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `batch_id` VARCHAR(64) UNIQUE NOT NULL COMMENT '批次唯一ID',
  `token_count` INT UNSIGNED NOT NULL COMMENT '生成的Token数量',
  `base_url` VARCHAR(500) NOT NULL COMMENT '基础URL',
  `expiry_hours` INT UNSIGNED NOT NULL COMMENT '有效期(小时)',
  `expires_at` TIMESTAMP NOT NULL COMMENT '批次中Token的过期时间',
  `created_by` VARCHAR(100) DEFAULT 'admin' COMMENT '创建人',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  INDEX `idx_batch_id` (`batch_id`),
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Token批次表';

-- Token明细表：记录每个批次中生成的所有Token
CREATE TABLE IF NOT EXISTS `token_batch_items` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `batch_id` VARCHAR(64) NOT NULL COMMENT '批次ID',
  `token` VARCHAR(16) NOT NULL COMMENT '16位Token',
  `token_hash` VARCHAR(64) NOT NULL COMMENT 'Token SHA256哈希值',
  `tracking_link` VARCHAR(500) NOT NULL COMMENT '完整跟踪链接',
  `email_id` VARCHAR(255) NOT NULL COMMENT '邮件ID',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `expires_at` TIMESTAMP NOT NULL COMMENT '过期时间',
  `is_used` TINYINT(1) DEFAULT 0 COMMENT '是否已使用',
  `use_count` INT UNSIGNED DEFAULT 0 COMMENT '使用次数',
  INDEX `idx_batch_id` (`batch_id`),
  INDEX `idx_token` (`token`),
  INDEX `idx_token_hash` (`token_hash`),
  INDEX `idx_created_at` (`created_at`),
  FOREIGN KEY (`batch_id`) REFERENCES `token_batches`(`batch_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Token批次明细表';

-- 添加注释说明
ALTER TABLE `token_batches` COMMENT = '存储批量生成Token的批次信息';
ALTER TABLE `token_batch_items` COMMENT = '存储批量生成的每个Token详情';
